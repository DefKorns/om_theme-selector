<?php get_header(); ?>
	
	<article id="post-0" class="post error404 not-found row">
		<div class="c12 end">
			<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try a search?', 'voxco' ); ?></p>
			<?php get_search_form(); ?>
		</div>
	</article>

<?php get_footer(); ?>