<?php

	if ( post_password_required() )
		return;
?>

	<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>



		<div class="c12 end">
			<h3 class="total-comment"><?php comments_number( 'No Comments', 'Comments (1)', 'Comments (%)' ); ?></h3>
		</div>	
			
		<ul class="commentlist">
			<?php
				wp_list_comments( array( 'callback' => '_s_comment' ) );
			?>
		</ul>

		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // are there comments to navigate through ?>
		<nav role="navigation" id="comment-nav-below" class="site-navigation comment-navigation c12 end">
			<div class="nav-previous accent"><?php previous_comments_link( esc_html__( '&larr; Older Comments', 'voxco' ) ); ?></div>
			<div class="nav-next accent"><?php next_comments_link( esc_html__( 'Newer Comments &rarr;', 'voxco' ) ); ?></div>
		</nav>
		<?php endif;?>
	
	<?php endif;  ?>

	<?php
		if ( ! comments_open() && '0' != get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
	?>
	
	<p class="nocomments c12 end"><?php esc_html__( 'Comments are closed.', 'voxco' ); ?></p>
	

	<?php endif; 
	
	$VoxcoTheme_commenter = wp_get_current_commenter();
	$VoxcoTheme_req = get_option( 'require_name_email' );
	$VoxcoTheme_aria_req = ( $req ? " aria-required='true'" : '' ); ?>

	<?php comment_form( 

	array( 
		'id_submit' => esc_html__('comment_submit', 'voxco'),
		'title_reply' => '<span class="c12"><span>'. esc_html__('Leave a comment', 'voxco'), 
		'title_reply_to' => esc_html__('Leave a comment %s', 'voxco'), 
		'cancel_reply_link' => esc_html__('Cancel comment', 'voxco').'</span></span>',
		'label_submit' => esc_html__('Submit', 'voxco'),
		'comment_field' => '<div class="c12"><textarea id="comment" name="comment" placeholder="' . esc_html__('Comment', 'voxco') . '" cols="45" rows="8" aria-required="true"></textarea>',	
		'fields' => apply_filters( 'comment_form_default_fields', array(
		'author' => '<div class="c4"><input id="author" name="author" type="text" placeholder="'. esc_html__('Name(Required)', 'voxco') . '" value="' . esc_attr( $VoxcoTheme_commenter['comment_author'] ) . '" size="30"' . $VoxcoTheme_aria_req . ' /></div>',
		'email' => '<div class="c4"><input id="email" name="email" type="text" placeholder="' . esc_html__('Email(Required)', 'voxco') . '" value="' . esc_attr(  $VoxcoTheme_commenter['comment_author_email'] ) . '" size="30"' . $VoxcoTheme_aria_req . ' /></div>',
		'url' => '<div class="c4 end"><input id="url" name="url" type="text" placeholder="Website" value="' . esc_attr( $VoxcoTheme_commenter['comment_author_url'] ) . '" size="30" /></div>'	
		)),
		'comment_notes_before' => '',
		'comment_notes_after' => '</div>'
		)
	);
	?>



	
</div>