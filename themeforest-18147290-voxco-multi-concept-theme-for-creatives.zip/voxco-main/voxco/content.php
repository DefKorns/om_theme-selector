		<?php global $VoxcoTheme_Options; ?>

		<?php if ( is_search() || is_archive() || is_home() ) { ?>
		
		<?php 

			  if(is_sticky($post->ID) && is_home() && ! is_paged() ){
				$VoxcoTheme_excerpt_width = $VoxcoTheme_Options['voxco_options_sticky_grid']; 
			  }
			  else{
			    $VoxcoTheme_excerpt_width = $VoxcoTheme_Options['voxco_options_blog_grid']; 
			  }
			  $VoxcoTheme_excerpt_length = $VoxcoTheme_Options['voxco_options_excerpt_length']; 
			  $VoxcoTheme_excerpt_heading_font = $VoxcoTheme_Options['voxco_options_blog_excerpt_heading_font']; ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class("masonry-item $VoxcoTheme_excerpt_width"); ?>>

				<?php $format = get_post_format( $post->ID ); 
				$VoxcoTheme_excerpt_background = get_post_meta( get_the_ID(), '_cmb_excerpt_background_color', 1 );
				$VoxcoTheme_excerpt_font = get_post_meta( get_the_ID(), '_cmb_excerpt_font_color', 1 );
				$VoxcoTheme_excerpt_heading = get_post_meta( get_the_ID(), '_cmb_excerpt_heading_color', 1 );

				if($format == 'image'){ ?>
					<div class="entry-summary <?php if ( !has_post_thumbnail()) { echo "no-post-thumbnail"; }?>">

						<?php 
						$VoxcoTheme_thumb = get_the_post_thumbnail($post->ID, 'large');
						if(!empty($VoxcoTheme_thumb)){
							$VoxcoTheme_image = $VoxcoTheme_thumb;
						}
						else {
							$VoxcoTheme_image  = '<img src="';
							$VoxcoTheme_image .= VoxcoTheme_catch_that_image();
							$VoxcoTheme_image .= '" />'; 
						} ?>
						<?php echo '<a class="recent-post-img" href="' . esc_url(get_permalink(get_the_ID())) . '" style="background-color:'. esc_attr($VoxcoTheme_excerpt_background) .';">' . $VoxcoTheme_image . '</a> '; ?>
						<div>
							<h2 class="<?php echo esc_attr($VoxcoTheme_excerpt_heading_font); ?>"><?php echo '<a style="color:'.esc_attr($VoxcoTheme_excerpt_heading).';" href="' . esc_url(get_permalink(get_the_ID())) . '" >' . get_the_title() . '</a> '; ?></h2>
							<p class="accent" style="color:<?php echo esc_attr($VoxcoTheme_excerpt_font);?>;">
								<?php echo esc_html__('By', 'voxco') ?> <a class="author" href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )); ?>"><?php echo get_the_author() ;?></a>
								<?php echo ' / '. get_the_date('j M Y'); ?>	
							</p>
						</div>	
					</div>	
				<?php } 
				
				else{ ?>
					<div class="entry-summary <?php if ( !has_post_thumbnail()) { echo "no-post-thumbnail"; }?>"> 
							
						<?php if ( has_post_thumbnail()) { ?>
							<a class="recent-post-img<?php if($VoxcoTheme_excerpt_background){ echo " has-excerpt-backgound";}?>" style="color:<?php echo esc_attr($VoxcoTheme_excerpt_background);?>;" href="<?php echo esc_url(get_permalink(get_the_ID())); ?>" ><?php echo get_the_post_thumbnail($post->ID, 'large'); ?></a>
						<?php } ?>
						<div style="background-color:<?php echo esc_attr($VoxcoTheme_excerpt_background);?>;">
							<h2 class="<?php echo esc_attr($VoxcoTheme_excerpt_heading_font); ?>" ><?php echo '<a href="' . esc_url(get_permalink(get_the_ID())) . '" style="color:'.$VoxcoTheme_excerpt_heading.';">' . get_the_title() . '</a> '; ?></h2>
							<?php 
								if ( has_excerpt() ) {
									$VoxcoTheme_the_excerpt = get_the_excerpt();
									echo "<p style='color:".$VoxcoTheme_excerpt_font.";'>$VoxcoTheme_the_excerpt</p>";
									echo '<span class="more"><a class="readmore" href="' . esc_url(get_permalink(get_the_ID())) . '" >' . esc_html__( 'More', 'voxco' ) . '</a></span> ';
								} 
								else {
									$VoxcoTheme_the_excerpt = VoxcoTheme_get_special_excerpt(3072);
									$VoxcoTheme_the_excerpt = preg_replace("~(?:\[/?)[^/\]]+/?\]~s", '', $VoxcoTheme_the_excerpt);
									$VoxcoTheme_the_excerpt = VoxcoTheme_string_limit_words($VoxcoTheme_the_excerpt, $VoxcoTheme_excerpt_length);
									echo "<p style='color:".$VoxcoTheme_excerpt_font.";'>$VoxcoTheme_the_excerpt</p>";
									echo '<span class="more"><a class="readmore" href="' . esc_url(get_permalink(get_the_ID())) . '" ><span>' . esc_html__( 'More', 'voxco' ) . '</span></a> </span>';
								}
							?>

						</div>
					</div>
				<?php } ?>
		</article>
		
		<?php }

		else { 
			$VoxcoTheme_sidebar = $VoxcoTheme_Options['voxco_options_sidebar'];

			if ($VoxcoTheme_sidebar == 'aside-standard'){
				echo '<div class="c9">';
			}
			else{
				echo '<div class="c12">';
			}
			if(get_post_meta( get_the_ID(), '_cmb_feature_display', 1 ) != 'no'){
				echo get_the_post_thumbnail($post->ID, 'full', array('class' => 'alignleft'));

			}
			the_content(); 

			?>

				<div class="entry-footer row">
					<?php wp_link_pages( array(
						'before' => '<div class="c12 end page-links">' . esc_html__( 'Pages:', 'voxco' ),
						'after'  => '</div>',
					) ); ?>
					<div class="entry-meta c12 end">
						<?php 
						$VoxcoTheme_tags_list = get_the_tag_list( '', esc_html__( ', ', 'voxco' ) );
						if ( $VoxcoTheme_tags_list ){  
							echo '<span class="tags-links li_tag"><i class="fa fa-tag"></i>';
							printf( esc_html__( 'Tagged: %1$s', 'voxco' ), $VoxcoTheme_tags_list ); 
							echo '</span>';
						}
						?>

					</div>
					<div class="share-wrap c12 end">
						<span class="share-border-left"><span></span></span>
						<div class="share">
							<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink($post->ID); ?>"  target="_blank"><i class="fa fa-facebook"></i></a>
							<a href="https://plus.google.com/share?url=<?php echo get_permalink($post->ID); ?>" target="_blank"><i class="fa fa-google-plus"></i></a>
							<a href="https://twitter.com/home?status=<?php echo get_permalink($post->ID); ?>" target="_blank"><i class="fa fa-twitter"></i></a>
							<?php 
							$image_id = get_post_thumbnail_id($post->ID);
							$image_url = wp_get_attachment_image_src($image_id);
							?>
							<a href="https://pinterest.com/pin/create/button/?url=<?php echo get_permalink($post->ID); ?>&media=<?php echo esc_url($image_url[0]); ?>&description=" target="_blank"><i class="fa fa-pinterest"></i></a>
						</div>
						<span class="share-border-right"><span><span></span>
					</div>

					<div class="post-nav">
						<?php

							echo '<div class="post-prev c6"> ';
							echo '<span class="accent">'. esc_html__( 'Previous Post', 'voxco' ) . '</span>';
							next_post_link('%link', '<h3>%title</h3>'); 
							echo '</div>';

							echo '<div class="post-next c6 end">';
							echo '<span class="accent">' .  esc_html__( 'Next Post', 'voxco' ) . '</span>';
							previous_post_link('%link', '<h3>%title</h3>'); 				
							echo '</div>';
						?>
					</div>
					
					<?php
						if ( comments_open() || '0' != get_comments_number() )
						comments_template( '', true );
					?>
				</div>
			</div>
			<?php
			if ($VoxcoTheme_sidebar == 'aside-standard'){ ?>
				<div class="c3 end"> <?php get_sidebar(); ?> </div>
			<?php } else if($VoxcoTheme_sidebar == 'aside-offcanvas'){ ?>
				<div class="aside-offcanvas">
					<span class="aside-close"></span>
					<?php get_sidebar(); ?>
				</div>
				<div class="aside-overlay"></div>
			<?php }
					
		} ?>
		     
			

