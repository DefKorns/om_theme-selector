</div>


<?php global $VoxcoTheme_Options; 

$voxco_site_layout = $VoxcoTheme_Options['voxco_options_site_layout']; 
$voxco_site_width = $VoxcoTheme_Options['voxco_options_site_width'];

if ( is_home() || is_page_template() ) {
	$VoxcoTheme_footer = get_post_meta( get_queried_object_id(), '_cmb_display_footer', true );
}

else {
	$VoxcoTheme_footer = get_post_meta( get_the_ID(), '_cmb_display_footer', true ); 
}


if($VoxcoTheme_footer == 'footer-on' || is_home() || is_search() || is_archive() || is_404()) { 
	
	if($VoxcoTheme_Options['voxco_options_footer_width'] && $VoxcoTheme_Options['voxco_options_site_width'] && $VoxcoTheme_Options['voxco_options_site_layout'] == 'layout-standard-header'){
		echo '<footer class="footer footer-full">';
	}
	else{
		echo '<footer class="footer footer-boxed">';
	} ?>
			<div class="footer-wrap">
				<div id="footer-sidebar" class="footer-inner">
			
					<a href="<?php echo esc_url(get_home_url('/')); ?>" class="footer-logo">
						<img id="footerLogo" alt="" src="<?php echo esc_url($VoxcoTheme_Options['footer_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['footer_retina_logo']['url']); ?>"/>
					</a>
					<?php 
					if($VoxcoTheme_Options['voxco_options_social_footer'] && shortcode_exists( 'social_networks' ) ){
				    	echo do_shortcode('[social_networks]');
				    } 
					?>
					<?php
						if(is_active_sidebar('footer-sidebar')){
							dynamic_sidebar('footer-sidebar');
						}
					?>
					<?php if($VoxcoTheme_Options['footer_copyright']){
						echo "<span class='copyright'>&copy; ". wp_kses($VoxcoTheme_Options['footer_copyright'], array( 'a' => array( 'href' => array(), 'target' => array()  )) ) ."</span>";
					} ?>

				</div>
			</div>
					
		</footer>

<?php  } ?>


</main>


<div class="border-top"></div>
<div class="border-bottom"></div>
<div class="border-right"></div>
<div class="border-left"></div>
<?php wp_footer(); ?>
</body>
</html>

