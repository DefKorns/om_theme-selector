<?php

if ( ! function_exists( 'VoxcoTheme_setup' ) ) :

if ( ! isset( $content_width ) ) $content_width = 1170;



function VoxcoTheme_setup() {


    load_theme_textdomain( 'voxco', get_template_directory() . '/languages' );

    require( get_template_directory() . '/inc/template-tags.php' );

    require_once (get_template_directory() . '/inc/class-tgm-plugin-activation.php');

    require_once (get_template_directory() . '/inc/metabox-functions.php');

    require_once (get_template_directory() . '/options.php');

    add_theme_support( 'automatic-feed-links' );

    add_theme_support( 'post-thumbnails' );

    add_theme_support( 'title-tag' );

    add_theme_support( 'post-formats', array(
        'image',
    ) );

    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'voxco' ),
    ) );

   
}

endif; 
add_action( 'after_setup_theme', 'VoxcoTheme_setup' );


function VoxcoTheme_widgets_init() {
    register_sidebar( array(
        'name' => esc_html__( 'Sidebar', 'voxco' ),
        'id' => 'sidebar-1',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h6 class="widget-title">',
        'after_title' => '</h6>',
    ) );
    register_sidebar( array(
        'name' => esc_html__('Footer Sidebar', 'voxco' ),
        'id' => 'footer-sidebar',
        'description' => esc_html__('Appears in the footer area', 'voxco' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
}
add_action( 'widgets_init', 'VoxcoTheme_widgets_init' );


function VoxcoTheme_wbc_extended( $demo_active_import , $demo_directory_path ) {

    reset( $demo_active_import );
    $current_key = key( $demo_active_import );

    if ( class_exists( 'RevSlider' ) ) {
        $wbc_sliders_array = array(
            'demo3' => 'voxco_demo3_home.zip', 
            'demo4' => 'voxco_demo4_home.zip', 
        );

        if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_sliders_array ) ) {
            $wbc_slider_import = $wbc_sliders_array[$demo_active_import[$current_key]['directory']];
            if ( file_exists( $demo_directory_path.$wbc_slider_import ) ) {
                $slider = new RevSlider();
                $slider->importSliderFromPost( true, true, $demo_directory_path.$wbc_slider_import );
            }
        }
    }
    
    $wbc_menu_array = array( 
        'demo1' => 'Menu 1', 
        'demo2' => 'Menu 2', 
        'demo3' => 'Menu 3',  
        'demo4' => 'Menu 4',  
        'demo5' => 'Menu 5', 
        'demo6' => 'Menu 6', 
    );
    if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_menu_array) ) {
        $top_menu  = get_term_by( 'name', $wbc_menu_array[$demo_active_import[$current_key]['directory']] , 'nav_menu' );
        if ( isset( $top_menu->term_id ) ) {
            set_theme_mod( 'nav_menu_locations', array(
                    'primary' => $top_menu->term_id,
                )
            );
        }
    }

    $wbc_home_pages = array(
        'demo1' => 'Portfolio',
        'demo2' => 'Home',
        'demo3' => 'Home',
        'demo4' => 'Home',
        'demo5' => 'Home',
        'demo6' => 'Home',

    );
    $wbc_post_pages = array(
        'demo1' => 'Blog',
        'demo2' => 'Blog',
        'demo3' => 'Blog',
        'demo4' => 'Latest Posts',
        'demo5' => 'Our latest posts',
        'demo6' => 'Our latest posts',

    );
    if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_home_pages ) ) {
        $page = get_page_by_title( $wbc_home_pages[$demo_active_import[$current_key]['directory']] );
        $blog = get_page_by_title( $wbc_post_pages[$demo_active_import[$current_key]['directory']] );
        if ( isset( $page->ID ) ) {
            update_option( 'page_on_front', $page->ID );
            update_option( 'page_for_posts', $blog->ID );
            update_option( 'show_on_front', 'page' );

        }
    }
}
    
add_action( 'wbc_importer_after_content_import', 'VoxcoTheme_wbc_extended', 10, 2 );



function VoxcoTheme_body_classes( $classes ) {
    global $VoxcoTheme_Options;

    $voxco_site_layout = $VoxcoTheme_Options['voxco_options_site_layout'];
    $voxco_menu_style = 'menu-full';
    $voxco_content_boxed = '';

    if($VoxcoTheme_Options['voxco_options_menu_bar_width']){
        $voxco_menu_style = 'menu-boxed';
    }
    if($VoxcoTheme_Options['voxco_options_site_width']){
        $voxco_content_boxed = 'content-boxed';
    }
    if($voxco_site_layout == 'layout-side-header'){
        $voxco_menu_layout = $VoxcoTheme_Options['voxco_options_menu_style'];
    }
    else{
        $voxco_menu_layout = $VoxcoTheme_Options['voxco_options_standard_menu_style'];
    }
   
    return array_merge( $classes, array( $voxco_menu_layout, $voxco_site_layout, $voxco_menu_style, $voxco_content_boxed  ) );
}

add_filter( 'body_class','VoxcoTheme_body_classes');




function VoxcoTheme_style() { 
    
    global $VoxcoTheme_Options;
    
    wp_enqueue_style( 'normalize', get_template_directory_uri() . '/css/normalize.css' );    
    wp_enqueue_style( 'font-awesome',  get_template_directory_uri() . '/css/font-awesome/css/font-awesome.min.css'  ); 
    wp_enqueue_style( 'VoxcoTheme-style', get_stylesheet_uri(), array( 'normalize' )); 
    if ( !class_exists( 'ReduxFramework') ){
        wp_enqueue_style( 'VoxcoTheme-defaults', get_template_directory_uri() . '/css/redux-defaults.css' , array( 'normalize' ) );   
    }
    else{ 
        ob_start();
        $side_menu_width = $VoxcoTheme_Options['voxco_options_siderbar_width'];
        $page_border_width = $VoxcoTheme_Options['voxco_options_page_border_width'];
        $main_width = 100 - $side_menu_width;
        $border_on_sidebar = $VoxcoTheme_Options['voxco_options_border_sidebar'];
        $half_padding = 0;
        $voxco_blog_grid_spacing = $VoxcoTheme_Options['voxco_options_blog_grid_spacing'];
        $voxco_portfolio_grid_spacing = $VoxcoTheme_Options['voxco_options_portfolio_grid_spacing'];
        $voxco_site_layout = $VoxcoTheme_Options['voxco_options_site_layout']; 
        $voxco_menu_layout = $VoxcoTheme_Options['voxco_options_menu_style']; 
        $voxco_site_width = $VoxcoTheme_Options['voxco_options_site_width'];
        $voxco_menu_outer_offset = $VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-left'] + $VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-right'];
        if($border_on_sidebar){
            $half_padding = $page_border_width / 2;
        }
        if($voxco_site_layout == 'layout-side-header'){ ?>
            #main, #primary{
                padding:<?php echo esc_html($page_border_width); ?>px;
                padding-left:<?php echo esc_html($half_padding); ?>px;
                width:<?php echo esc_html($main_width); ?>%;
                left: <?php echo esc_html($side_menu_width); ?>%;
            }
            
        <?php 
        } 
        else{ ?>
            #main, #primary{
                padding:<?php echo esc_html($page_border_width); ?>px; 
            }
            .vc_row[data-vc-stretch-content|=true]{
                padding-left: <?php echo esc_html($page_border_width); ?>px;
                padding-right: <?php echo esc_html($page_border_width); ?>px;
            }
            <?php if($voxco_site_width){ ?>
                .content, .boxed-content-wrapper, .post-header.row-full-boxed > div:not(.voxco-parallax), .footer-boxed .footer-wrap, .footer-full, .footer-full .footer-inner{max-width:<?php echo esc_html($voxco_site_width); ?>px;}
                .layout-standard-header #main,  .layout-standard-header.single-post #main,  .layout-standard-header.blog #main, .layout-standard-header.archive #main, .layout-standard-header.error404 #main, .layout-standard-header.search-no-results #main{
                    background-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_boxed_body_background']['background-color']); ?>;
                    background-image:url(<?php echo esc_html($VoxcoTheme_Options['voxco_options_boxed_body_background']['background-image']); ?>);
                    background-repeat:<?php echo esc_html($VoxcoTheme_Options['voxco_options_boxed_body_background']['background-repeat']); ?>;
                    background-position:<?php echo esc_html($VoxcoTheme_Options['voxco_options_boxed_body_background']['background-position']); ?>;
                    background-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_boxed_body_background']['background-size']); ?>;
                    background-attachment:<?php echo esc_html($VoxcoTheme_Options['voxco_options_boxed_body_background']['background-attachment']); ?>;
                }
            <?php } 
        } ?>

        .portfolioinner{ margin: <?php echo '-' . esc_html($voxco_portfolio_grid_spacing) / 2 . 'px';?>; } 

        <?php if($VoxcoTheme_Options['voxco_options_menu_bar_width']){ ?>

            .layout-standard-header .nav-top{
                top:<?php  echo esc_html($page_border_width)  + esc_html($VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-top']);  ?>px;
                left:50%;
                width:calc(100% - <?php echo esc_html($page_border_width) * 2 + $voxco_menu_outer_offset; ?>px);
                max-width:<?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_bar_width']) ; ?>px;
            }
            .admin-bar.layout-standard-header .nav-top{
                 top:<?php  echo esc_html($page_border_width)  + esc_html($VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-top']) + 32;  ?>px;
            }
        <?php } else { ?>
            .layout-standard-header .nav-top{
                top:<?php echo esc_html($page_border_width)  + esc_html($VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-top']); ?>px;
                left:<?php echo esc_html($page_border_width) + $VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-left']; ?>px;
                width:calc(100% - <?php echo esc_html($page_border_width) * 2  + $voxco_menu_outer_offset; ?>px);
            }
            .admin-bar.layout-standard-header .nav-top{
                top:<?php echo esc_html($page_border_width)  + esc_html($VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-top']) + 32; ?>px;
            }
        <?php }?>

        .layout-standard-header .nav-top-inner{
            max-width:<?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_inner_width']) ; ?>px;
            margin:0 auto;
        }

        <?php if($VoxcoTheme_Options['voxco_options_nav_fixed'] == true){ ?>
            .layout-standard-header .nav-top{
                position:fixed;
                -webkit-transition: height 0.2s ease-out; 
                transition: height 0.2s ease-out;
            }
        <?php } ?>
        <?php if($VoxcoTheme_Options['voxco_options_nav_fixed'] == false && $VoxcoTheme_Options['voxco_options_nav_button_four_fixed'] == true){ ?>
            .l4 .nav-trigger{position:fixed;}
        <?php } 
            if($VoxcoTheme_Options['voxco_options_nav_fixed'] == false && $VoxcoTheme_Options['voxco_options_nav_button_four_fixed'] == false){ ?>
            .filter-btn{display:block !important;}
        <?php } ?>

        .layout-standard-header .nav-top{height:<?php echo esc_html($VoxcoTheme_Options['voxco_options_nav_height']); ?>px;}
        .layout-standard-header .mainnav.scrolled{ height: <?php echo esc_html($VoxcoTheme_Options['voxco_options_nav_scrolled_height']); ?>px; }
        #main.min-width{
          padding-left:<?php echo esc_html($half_padding) + 260; ?>px;
        }
        #primary-header{
            width:<?php echo esc_html($side_menu_width); ?>%;
            padding:<?php echo esc_html($page_border_width); ?>px;
            padding-right:<?php echo esc_html($half_padding); ?>px;
        }
        .content, .layout-standard-header .content-boxed{
                padding-top:<?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-top']); ?>;
                padding-right:<?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-right']); ?>;
                padding-bottom:<?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-bottom']); ?>;
                padding-left:<?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-left']); ?>;
        }
        .footer-boxed .footer-wrap, .footer-full{
            padding-left:<?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-left']); ?>;
            padding-right:<?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-right']); ?>;
            padding-bottom:<?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-bottom']); ?>;

        } 
        .blog .footer, .archive .footer, .search-results .footer{
            margin-top:<?php echo esc_html($voxco_blog_grid_spacing) / 2 . 'px'; ?>;
        }
        .page-template-portfolio-template .footer{
            margin-top: <?php echo esc_html($voxco_portfolio_grid_spacing) / 2 . 'px';?>; 
        }
        .content .vc_row.wpb_row .vc_column_container > .vc_column-inner, .post-header, .row-default{
            padding-left: <?php echo esc_html($VoxcoTheme_Options['voxco_options_column_padding']['padding-left']); ?>;
            padding-right: <?php echo esc_html($VoxcoTheme_Options['voxco_options_column_padding']['padding-right']); ?>;
            padding-top: <?php echo esc_html($VoxcoTheme_Options['voxco_options_column_padding']['padding-top']); ?>;
            padding-bottom: <?php echo esc_html($VoxcoTheme_Options['voxco_options_column_padding']['padding-bottom']); ?>;
        }
        .footer-inner{
            padding-left: <?php echo esc_html($VoxcoTheme_Options['voxco_options_column_padding']['padding-left']); ?>;
            padding-right: <?php echo esc_html($VoxcoTheme_Options['voxco_options_column_padding']['padding-right']); ?>;
        }
        .content-boxed .post-header.row-full-boxed .vocxo-content-wrapper{
            padding-left: <?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-left']); ?>;
            padding-right: <?php echo esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-right']); ?>;
        }
        .aside-offcanvas{
            min-height:calc(100% - <?php echo esc_html($page_border_width); ?>px);
            top:<?php echo esc_html($page_border_width); ?>px;
            right: <?php echo esc_html($page_border_width); ?>px;
        }
        .aside-trigger{
            top:<?php echo esc_html($page_border_width) + esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-top']) + 15; ?>px;
            right:<?php echo esc_html($page_border_width) + esc_html($VoxcoTheme_Options['voxco_options_page_padding']['padding-right'] + 15); ?>px;
        }
        <?php if(!$border_on_sidebar){ ?>
            #primary-header:after{display:none;}
        <?php } ?>

        #masonry-container article{
            padding:<?php echo esc_html($voxco_blog_grid_spacing) / 2 . 'px';?>;
        }
        #masonry-container{ 
            <?php $voxco_container_margin = '-' . $voxco_blog_grid_spacing / 2 . 'px'; ?>
            margin: <?php echo esc_html($voxco_container_margin) . ' ' . esc_html($voxco_container_margin) . ' ' . '0px' ;?>;
        }
        .portfolioinner li:not(.no-thumbnail){
            padding:<?php echo esc_html($voxco_portfolio_grid_spacing) / 2 . 'px';?>;
        }
        .portfolioinner .no-thumbnail figcaption{
            top:<?php echo esc_html($voxco_portfolio_grid_spacing) / 2 . 'px';?>;
            right:<?php echo esc_html($voxco_portfolio_grid_spacing) / 2 . 'px';?>;
            bottom:<?php echo esc_html($voxco_portfolio_grid_spacing) / 2 . 'px';?>;
            left:<?php echo esc_html($voxco_portfolio_grid_spacing) / 2 . 'px';?>;
        }
        .border-top, .border-bottom{
            height:<?php echo esc_html($page_border_width); ?>px;
        }
        .border-left, .border-right, #primary-header:after{
            width:<?php echo esc_html($page_border_width); ?>px;
        }
        #primary-header:after{
            right:-<?php echo esc_html($half_padding); ?>px;
        }
        .border-top, .border-bottom, .border-left, .border-right, #primary-header:after{
            background-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_page_border_color']); ?>;
        }
        .content, #main, .footer-boxed .footer-wrap, .footer-full{
            background-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_main_background_color']); ?>;
        }
        .blog .content, .blog #main, .archive .content, .archive #main, .error404 .content, .error404 #main, .search-no-results .content, .search-no-results #main, .search-results .content, .search-results #main {
            background-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_archive_bg']); ?>;
        }
        <?php if($VoxcoTheme_Options['voxco_options_single_post_bg_apply'] == 'content'){ ?>
            .single-post article{
                background-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_single_post_bg']); ?>
            }

        <?php } 
        else { ?>
            .single-post .content, .single-post #main{
                background-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_single_post_bg']); ?>
            }
        <?php } ?>
        html, body, .loaderOverlay{
            background-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_loading_background_color']); ?>;
        }
        .entry-summary div{
            background-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_blog_excerpt_background_color']); ?>;
        }
        .has-post-thumbnail .recent-post-img:after{
            border-bottom:8px solid <?php echo esc_html($VoxcoTheme_Options['voxco_options_blog_excerpt_background_color']); ?>;
        }
        .masonry-item h2 a{
            color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_blog_excerpt_heading_color']); ?>;
        }
        .masonry-item p, a.readmore, a:visited.readmore, a:hover.readmore {
            color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_blog_excerpt_font_color']); ?>;
        }
        .nav-trigger span, .nav-trigger span:before, .nav-trigger span:after, .nav-trigger.is-active span:before, .nav-trigger.is-active span:after {
            background: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_button_color']); ?>;
        }
        .nav-trigger:before, .nav-trigger.is-active:before, .filter-btn {
            border-color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_button_color']); ?>;
        }
        .filter-btn{
            color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_button_color']); ?>;
        }


        .nav-trigger.is-active:before{
            border-color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_button_active_color']); ?>;
        }
        .nav-trigger.is-active span:before, .nav-trigger.is-active span:after {
            background: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_button_active_color']); ?>;
        }



        .mainnav a, .mainnav a:visited, .portfolio-nav li, .filter-title{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_link_color']['regular']); ?>;
        }
        .filter-above li:after{border-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_link_color']['regular']); ?>;}

        .mainnav li:hover > a, .portfolio-nav li:hover{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_link_color']['hover']); ?>;
        }
        .mainnav a:active, .mainnav .current-menu-item  > a, .mainnav .current-menu-parent  > a, .portfolio-nav li.checked {
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_link_color']['active']); ?>;
        }
        .portfolio-nav li, .filter-title{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_filter_link_color']['regular']); ?>;
        }
        .portfolio-nav li:hover{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_filter_link_color']['hover']); ?>;
        }
        .portfolio-nav li.checked {
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_filter_link_color']['active']); ?>;
        }        
        .mainnav .current-menu-item > a, .mainnav .current-menu-parent > a{
            background: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_link_background_color']); ?>;
        }
        <?php if(!$VoxcoTheme_Options['voxco_options_menu_link_background_color']){ ?>
            .layout-standard-header .nav-top-inner li:last-child{
                padding-right: 0px;
            } 
        <?php }?>
        <?php if(! empty($VoxcoTheme_Options['voxco_options_menu_background_color']['rgba'])){ ?>
            .l1 .header-inner, .l2 .header-inner, .l3 .header-inner, .l4 .mainnav, .l5 .mainnav, .l5 .sub-menu{
                background: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_background_color']['rgba']); ?>;
            }
        <?php } 
        if(! empty($VoxcoTheme_Options['voxco_options_menu_popup_background_color']['rgba'])){ ?>
            .l1 .mainnav, .l3 .mainnav, .l4 .nav-top-inner > div:last-child, .filter-menu{
                background: <?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_popup_background_color']['rgba']); ?>;
            }
        <?php } ?> 
        .l4 .nav-top-inner > div:last-child{
            height:calc(100% -  <?php echo esc_html($page_border_width) * 2 . 'px'; ?>);
            top: <?php echo esc_html($page_border_width); ?>px;
            right: <?php echo esc_html($page_border_width); ?>px;
            bottom: <?php echo esc_html($page_border_width); ?>px;
            left: <?php echo esc_html($page_border_width); ?>px; 
        }
        <?php if ($VoxcoTheme_Options['voxco_options_logo']['height'] < 44 ){
            $voxco_logo_height = 44;
        }
        else if ($VoxcoTheme_Options['voxco_options_logo']['height'] > 100) {
            $voxco_logo_height = 100;
        }
        else{
            $voxco_logo_height = $VoxcoTheme_Options['voxco_options_logo']['height'];
        } ?>
        
        .l3 .header-content{ 
            height:calc(100% - <?php echo esc_html($voxco_logo_height) + 60; ?>px);
            top: <?php echo esc_html($voxco_logo_height) + 60; ?>px; 
        } 
        .l3 .headbox{ height: <?php echo esc_html($voxco_logo_height); ?>px; }
        .l3 .header-box{
            margin-top:-<?php echo (esc_html($voxco_logo_height) + 60 ) / 2; ?>px;
            padding-top:<?php echo (esc_html($voxco_logo_height) + 60 ) / 2; ?>px;
        }
        .layout-standard-header .nav-top-inner .nav-top-logo{width:<?php echo esc_html($VoxcoTheme_Options['voxco_options_logo']['width']); ?>px;}
        .l3 .header-logo img{
            width:<?php echo esc_html($VoxcoTheme_Options['voxco_options_logo']['width']); ?>px;
            height:<?php echo esc_html($VoxcoTheme_Options['voxco_options_logo']['height']); ?>px;
        }
        a, a:visited{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_link_color']['regular']); ?>;
        }
        .mainnav .social-networks li{
            border-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_link_color']['regular']); ?>;
        }
        a:hover{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_link_color']['hover']); ?>;
        }
        a:active{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_link_color']['active']); ?>;
        }
        ::selection{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_highlight_font']); ?>; 
            background: <?php echo esc_html($VoxcoTheme_Options['voxco_options_highlight_background']); ?>;
        }
        ::-moz-selection{
            color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_highlight_font']); ?>; 
            background: <?php echo esc_html($VoxcoTheme_Options['voxco_options_highlight_background']); ?>;
        }
        .drop-cap-flat > p:first-child:first-letter, .drop-cap-outline > p:first-child:first-letter, .drop-cap-minimal > p:first-child:first-letter, .drop-cap:first-letter{
            font-size: <?php echo esc_html($VoxcoTheme_Options['voxco_options_dropcap_styles']['font-size']); ?>;
            font-family: <?php echo esc_html($VoxcoTheme_Options['voxco_options_dropcap_styles']['font-family']); ?>;
            font-style: <?php echo esc_html($VoxcoTheme_Options['voxco_options_dropcap_styles']['font-style']); ?>;
        }
        .drop-cap-flat > p:first-child:first-letter{
          background:<?php echo esc_html($VoxcoTheme_Options['voxco_options_dropcap_styles']['color']); ?>;
        }
        .drop-cap-outline > p:first-child:first-letter{
          border:2px solid <?php echo esc_html($VoxcoTheme_Options['voxco_options_dropcap_styles']['color']); ?>;
          color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_dropcap_styles']['color']); ?>;
        }
        .drop-cap-minimal > p:first-child:first-letter{
          color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_dropcap_styles']['color']); ?>;
        }
        button[class*=' vc_btn'],button[class^='vc_btn'],a[class*=' vc_btn'],a[class^='vc_btn']{
            font-family: <?php echo esc_html($VoxcoTheme_Options['heading-six-styles']['font-family']); ?>;
        }
        #loader{
            border-color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_preloader_bg_color']); ?>;
        }
        #loader:before{
            border-top-color: <?php echo esc_html($VoxcoTheme_Options['voxco_options_preloader_prog_color']); ?>;
        }
        .footer-boxed .footer-inner, .footer-full .footer-wrap{
            background:<?php echo esc_html($VoxcoTheme_Options['voxco_options_footer_bg']); ?>;
        }
        .footer-inner *{
            color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_footer_text']); ?>;
        }
        .footer-inner a, .footer-inner a i{
            color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_footer_link_color']); ?>;
        }
        .footer-inner .social-networks li{
            border-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_footer_link_color']); ?>;
        }
        <?php if($VoxcoTheme_Options['voxco_options_contact_form_style'] == 'boxed'){ ?>
            .wpcf7 input[type="text"], .wpcf7 input[type="email"]{ height:40px; }
            .wpcf7-form-control-wrap:after{ display:none; }
            span.wpcf7-form-control-wrap{margin-bottom:15px;}
            .wpcf7-submit{margin-top:15px;}                
            .wpcf7 textarea{max-height:none;}
            .wpcf7 input[type="text"], .wpcf7 input[type="email"], .wpcf7 textarea{
                border-style:solid;
                border-width:1px;
                padding:10px;
            }
            .wpcf7 input[type="text"]:focus, .wpcf7 input[type="email"]:focus, .wpcf7 textarea:focus{
                border-bottom:1px solid <?php echo esc_html($VoxcoTheme_Options['voxco_options_contact_form_color']['rgba']); ?>;
            }
        <?php } ?>

        <?php if($voxco_site_layout == 'layout-side-header'){ ?>
            @media only screen and (max-width: <?php echo 260*(100/esc_html($side_menu_width)); ?>px) {
                #main {
                    width: 100%;
                    padding-left: <?php echo 260 + esc_html($half_padding) ?>px;
                    left: 0;
                }
                
            }
        <?php } ?>
        @media only screen and (max-width: 1024px){
            #masonry-container.c9{
                width:calc(100% + <?php echo esc_html($voxco_blog_grid_spacing); ?>px) !important;
            }
        }

        @media only screen and (max-width: 782px) {
            #wpadminbar{position: fixed;}
            .admin-bar.layout-standard-header .nav-top {
                top:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']) + esc_html($VoxcoTheme_Options['voxco_options_mobile_menu_offset']['padding-top']) + 46; ?>px;
            }    
        }
        @media only screen and (max-width: 768px){

            .admin-bar.l1 .header-panel, .admin-bar.l2 #primary-header, .admin-bar.l3 .header-panel {
                top:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']) + esc_html($VoxcoTheme_Options['voxco_options_mobile_menu_offset']['padding-top']) + 46; ?>px;
            } 
            .content .vc_row.wpb_row .vc_column_container > .vc_column-inner, .post-header, .row-default{
                padding-top: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-top']); ?>;
                padding-right: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-right']); ?>;
                padding-bottom: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-bottom']); ?>;
                padding-left: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-left']); ?>;
            }
            .footer-inner{
                padding-left: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-left']); ?>;
                padding-right: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-right']); ?>;
            }
            .content, .layout-standard-header .content-boxed{
                padding-top:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_padding']['padding-top']); ?>;
                padding-right:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_padding']['padding-right']); ?>;
                padding-bottom:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_padding']['padding-bottom']); ?>;
                padding-left:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_padding']['padding-left']); ?>;
            }
            .footer-boxed .footer-wrap, .footer-full{
                padding-left:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_padding']['padding-left']); ?>;
                padding-right:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_padding']['padding-right']); ?>;
            }

            <?php if($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-left'] > 15){ ?>
                .layout-standard-header.single-post article{ padding-left: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-left']) - 15; ?>px; }
            <?php } 
                else{ ?>
                    .layout-standard-header.single-post article{padding-left:0;}
            <?php } ?>

            <?php if($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-right'] > 15){ ?>
                .layout-standard-header.single-post article{ padding-right: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-right']) - 15; ?>px; }
            <?php } 
                else{ ?>
                    .layout-standard-header.single-post article{padding-right:0;}
            <?php } ?>
            
            .post-header.row-full-boxed .vocxo-content-wrapper{
                padding-left: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-left']) + esc_html($VoxcoTheme_Options['voxco_options_mobile_page_padding']['padding-left']); ?>px;
                padding-right: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_column_padding']['padding-right']) + esc_html($VoxcoTheme_Options['voxco_options_mobile_page_padding']['padding-right']); ?>px;
            }

            #main, #primary{padding:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;}

            .border-left, .border-right{
                width:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
            }
            .border-top, .border-bottom{
                height:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
            }
            .layout-standard-header .nav-top, .l1 .header-panel, .l2 #primary-header , .l3 .header-panel {
                top:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']) + esc_html($VoxcoTheme_Options['voxco_options_mobile_menu_offset']['padding-top']); ?>px;
                left:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']) + esc_html($VoxcoTheme_Options['voxco_options_mobile_menu_offset']['padding-left']); ?>px;
                max-width:calc(100% - <?php echo (esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']) * 2) + (esc_html($VoxcoTheme_Options['voxco_options_mobile_menu_offset']['padding-left']) + esc_html($VoxcoTheme_Options['voxco_options_mobile_menu_offset']['padding-right'])); ?>px);
            }
            .layout-standard-header .nav-top{height:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_nav_height']); ?>px;}
            .l3 #primary-header{height:calc(100% - <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px);}
            <?php if($VoxcoTheme_Options['voxco_options_mobile_logo']['url']){ ?>
                .l3 .header-logo img{
                    width:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_logo']['width']); ?>px;
                    height:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_logo']['height']); ?>px;
                }
            <?php } ?>
            .l4 .nav-top-inner > div:last-child{
                height:calc(100% -  <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']) * 2 . 'px'; ?>);
                top:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
                right:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
                bottom:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
                left:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
            }
            .aside-offcanvas{
                min-height:calc(100% - <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px);
                top:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
                right: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
            }
            body .content, body .header-content{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_body_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_body_font_spacing']); ?>px;
            }
            .content h1, .content .alpha, .header-content h1, .header-content .alpha{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_one_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_one_font_spacing']); ?>px;
            }
            .content h2, .content .beta, .header-content h2, .header-content .beta{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_two_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_two_font_spacing']); ?>px;
            }
            .content h3, .content .gamma, .header-content h3, .header-content .gamma{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_three_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_three_font_spacing']); ?>px;
            }
            .content h4, .content .delta, .header-content h4, .header-content .delta{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_four_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_four_font_spacing']); ?>px;
            }
            .content h5, .content .epsilon, .header-content h5, .header-content .epsilon{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_five_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_five_font_spacing']); ?>px;
            }
            .content h6, .content .zeta, .header-content h6, .header-content .zeta{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_six_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_h_six_font_spacing']); ?>px;
            }
            .content .mega, .header-content .mega{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_mega_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_mega_font_spacing']); ?>px;
            }
            .content .accent, .header-content .accent{
                font-size:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_accent_font']); ?>px;
                letter-spacing:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_accent_font_spacing']); ?>px;
            }
            .scrollContainer, .l3 .header-content{
                width:calc(100% - <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']) * 2; ?>px);
                left:<?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_page_border_width']); ?>px;
            }
            .header-panel, .l2 .header-inner, .l4 .mainnav, .l5 .mainnav, .l5 .nav-top-inner > div:last-child > ul{
                background: <?php echo esc_html($VoxcoTheme_Options['voxco_options_mobile_menu_background']); ?>;
            }
            .l2 .mainnav{ 
                background: transparent;
            }
            .l5 .menu li a, .l2 .nav-inner nav{
                border-color:<?php echo esc_html($VoxcoTheme_Options['voxco_options_menu_link_color']['regular']); ?>;
            }



        }
        

        <?php 
        echo esc_html($VoxcoTheme_Options['voxco_options_custom_css']); 
        $contents = ob_get_contents();
        $custom_css = preg_replace('/\s+/S', " ", $contents);
        ob_end_clean();
        
        wp_add_inline_style( 'VoxcoTheme-style', htmlspecialchars_decode($custom_css, ENT_QUOTES) ); 
    }
       
}

function VoxcoTheme_scripts() {
    global $VoxcoTheme_Options;
    wp_enqueue_script( 'modernizer', get_template_directory_uri() . '/js/modernizr-2.6.2.min.js');
    wp_enqueue_script( 'tweenmax', get_template_directory_uri() . '/js/TweenMax.min.js', false );
    wp_enqueue_script( 'VoxcoTheme-plugins', get_template_directory_uri() . '/js/plugins.js', array( 'jquery', 'tweenmax'), 'version', true );
    wp_enqueue_script( 'VoxcoTheme-script', get_template_directory_uri() . '/js/script.js', array( 'jquery' , 'VoxcoTheme-plugins' ), 'version', true );
    if($VoxcoTheme_Options['voxco_options_load_retina_js']){
        wp_enqueue_script( 'retina-js', get_template_directory_uri() . '/js/retinajs.js', array( 'jquery' , 'VoxcoTheme-plugins' ), 'version', true );
    }
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply',array( 'jquery' , 'VoxcoTheme-plugins' ), 'version', true);
    }
    if($VoxcoTheme_Options['voxco_options_slider_speed']){
        $VoxcoTheme_slider_speed = $VoxcoTheme_Options['voxco_options_slider_speed'];
    }
    else{
        $VoxcoTheme_slider_speed = 50;
    } 
    wp_add_inline_script( 'VoxcoTheme-plugins', 'var sliderSpeed = '. $VoxcoTheme_slider_speed . ';', $position = 'before' );
         
}


function VoxcoTheme_html5_scripts() {
      if (preg_match('/(?i)msie [1-8]/',$_SERVER['HTTP_USER_AGENT'])){
        wp_enqueue_script( 'html5shim', get_template_directory_uri() . '/js/html5.js"' );
    }      
}

add_action( 'wp_enqueue_scripts', 'VoxcoTheme_style' );
add_action( 'wp_enqueue_scripts', 'VoxcoTheme_scripts', 0 );
add_action( 'wp_enqueue_scripts', 'VoxcoTheme_html5_scripts', 0 );


if (!function_exists('VoxcoTheme_string_limit_words')) {    
    function VoxcoTheme_string_limit_words($string, $word_limit){
      $words = explode(' ', $string, ($word_limit + 1));
      if(count($words) > $word_limit)
      array_pop($words);
      return implode(' ', $words);
    }
}    

if (!function_exists('VoxcoTheme_get_special_excerpt')) {
    function VoxcoTheme_get_special_excerpt($count){
        $excerpt = get_the_content();
        $excerpt = preg_replace(" (\[.*?\])",'',$excerpt);
        $excerpt = strip_tags($excerpt, '<br>');
        $excerpt = substr($excerpt, 0, $count);
        $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
        $excerpt = trim(preg_replace( '/\s+/', ' ', $excerpt));
        return $excerpt;
    }
}

if (!function_exists('VoxcoTheme_catch_that_image')) {
    function VoxcoTheme_catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        if(preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches)){
            $first_img = $matches [1] [0];
            return $first_img;
        }

    }
}



if ( !class_exists( 'ReduxFramework') ){


    function VoxcoTheme_default_fonts(){
        $protocol = is_ssl() ? 'https' : 'http';
        wp_enqueue_style( 'VoxcoTheme-fonts', "$protocol://fonts.googleapis.com/css?family=Montserrat|Open+Sans|PT+Serif" );
    }
    add_action( 'wp_enqueue_scripts', 'VoxcoTheme_default_fonts' );
    
    global $VoxcoTheme_Options;

    $VoxcoTheme_Options  = array(
        'voxco_options_favicon' => array( 'url'=> get_template_directory_uri().'/images/favicon.ico'),
        'voxco_options_logo' => array( 
            'url'=> get_template_directory_uri().'/images/logo.png',
            'width' => '92',
            'height' => '108'
        ),
        'voxco_options_retina_logo' => array( 'url'=> get_template_directory_uri().'/images/logo@2x.png'),
        'voxco_options_mobile_logo' => array( 'url'=> ''),
        'voxco_options_menu_style' => 'l1' ,
        'voxco_options_site_layout' => 'layout-side-header',
        'voxco_options_excerpt_length' => '18',
        'voxco_options_blog_header' => 'no',
        'voxco_options_masonary_grid' => 'halfs',
        'voxco_options_slider_speed' => '70',
        'voxco_options_menu_bar_width' => '',
        'voxco_options_site_width' => '',
        'voxco_options_display_preloader' => false,
        'voxco_options_load_retina_js' => false,
        'voxco_options_siderbar_slides' => '',
        'voxco_options_menu_button_style' => 'round',
        'voxco_options_sidebar_content' => '',
        'voxco_options_sidebar_content_color' => '',
        'voxco_options_social_header' => false,
        'voxco_options_blog_header_image' => array( 'url'=> ''),
        'voxco_options_blog_header_color' => '#c6c6c6',
        'voxco_options_blog_header_height' => 'h2',
        'voxco_options_blog_header_mobile_height' => 'mh2',
        'voxco_options_blog_header_offset' => '0',
        'voxco_options_blog_header_width' => 'row-full',
        'voxco_options_blog_title' => 'alpha',
        'voxco_options_blog_title_align' => 'align-left',
        'voxco_options_blog_title_v_align' => 'a-center',
        'voxco_options_blog_header_margin' => '',
        'voxco_options_rev' => '',
        'voxco_options_sidebar_content_pos' => 'cen-cen',
        'voxco_options_blog_grid' => 'p4',
        'voxco_options_sticky_grid' => 'p8',
        'voxco_options_blog_excerpt_heading_font' => 'beta',
        'voxco_options_blog_title_color' => '#ffffff',
        'voxco_options_sidebar_arch' => 'aside-offcanvas',
        'voxco_options_sidebar' => 'aside-standard',
        'voxco_options_footer_width' => false,
        'footer_logo' => array( 'url'=> get_template_directory_uri().'/images/footer-logo.png'),
        'footer_retina_logo' => array( 'url'=> get_template_directory_uri().'/images/footer-logo@2x.png'),
        'voxco_options_social_footer' => false,
        'footer_copyright' => esc_html__('Copyright 2016, Example Corporation', 'voxco'),
        'excluded_cats' => '',
        'mobile_height' => '',
 
    );



}

add_action( 'tgmpa_register', 'VoxcoTheme_register_required_plugins' );
function VoxcoTheme_register_required_plugins() {
    $plugins = array(
        array(
            'name'                     => esc_html__('Voxco Framework', 'voxco' ), // The plugin name
            'slug'                     => 'voxco-framework', // The plugin slug (typically the folder name)
            'source'                   => get_template_directory() . '/inc/voxco-framework.zip', // The plugin source
            'required'                 => true, // If false, the plugin is only 'recommended' instead of required
            'version'                 => '1.0.2', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'is_automatic'            => true,            
            'force_activation'         => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'     => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'             => '', // If set, overrides default API URL and points to an external URL
        ),
        array(
            'name'          => esc_html__('WPBakery Visual Composer', 'voxco' ), // The plugin name
            'slug'          => 'js_composer', // The plugin slug (typically the folder name)
            'source'            => get_template_directory() . '/inc/js_composer.zip', // The plugin source
            'required'          => true, // If false, the plugin is only 'recommended' instead of required
            'version'           => '5.1.1', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'      => '', // If set, overrides default API URL and points to an external URL
        ),
        array(
            'name'                     => esc_html__('Slider Revolution', 'voxco' ), // The plugin name
            'slug'                     => 'revslider', // The plugin slug (typically the folder name)
            'source'                   => get_template_directory() . '/inc/revslider.zip', // The plugin source
            'required'                 => false, // If false, the plugin is only 'recommended' instead of required
            'version'                 => '5.4.3.1', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'is_automatic'            => true,        
            'force_activation'         => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'     => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'             => '', // If set, overrides default API URL and points to an external URL
        ),
        array(
            'name'         => esc_html__('Contact Form 7', 'voxco' ),
            'slug'         => 'contact-form-7',
            'required'     => false,
        ),
        array(
            'name'         => esc_html__('Intuitive Custom Post Order', 'voxco' ),
            'slug'         => 'intuitive-custom-post-order',
            'required'     => false,
        ),


    );
    
    $config = array(
        'domain'               => 'voxco',                        // Text domain - likely want to be the same as your theme.
        'default_path'         => '',                             // Default absolute path to pre-packaged plugins
        'parent_slug'          => 'themes.php',   
        'menu'                 => 'install-required-plugins',     // Menu slug
        'has_notices'          => true,                           // Show admin notices or not
        'is_automatic'        => false,                           // Automatically activate plugins after installation or not
        'message'             => '',                            // Message to output right before the plugins table

    );
    tgmpa( $plugins, $config );
}

if(function_exists('vc_disable_frontend')){
    vc_disable_frontend();
}

function VoxcoTheme_vcSetAsTheme() {
    vc_set_as_theme();
}
add_action( 'vc_before_init', 'VoxcoTheme_vcSetAsTheme' );





