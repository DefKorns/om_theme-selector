<!DOCTYPE html>
<html class="no-js voxco" <?php language_attributes(); ?>>
<head>

<?php global $VoxcoTheme_Options; ?>

<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php if ( ! ( function_exists( 'has_site_icon' ) && has_site_icon() ) ) { ?>
<link rel="shortcut icon" href="<?php echo esc_url($VoxcoTheme_Options['voxco_options_favicon']['url']); ?>" type="image/x-icon" />
<?php } ?>


<?php wp_head() ?>

</head>



<?php  

$voxco_site_layout = $VoxcoTheme_Options['voxco_options_site_layout'];
if($voxco_site_layout == 'layout-side-header'){
	$voxco_menu_layout = $VoxcoTheme_Options['voxco_options_menu_style'];
}
else{
	$voxco_menu_layout = $VoxcoTheme_Options['voxco_options_standard_menu_style'];
}

$VoxcoTheme_portfolio_filters = get_post_meta( get_the_ID(), '_cmb_portfolio_filter',true );

if(empty($VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-top'])){
	$Voxotheme_desktop_offset = 0;
}
else{
	$Voxotheme_desktop_offset = preg_replace("/[^0-9]/","", $VoxcoTheme_Options['voxco_options_menu_outer_offset']['padding-top']);
}
if(empty($VoxcoTheme_Options['voxco_options_mobile_menu_offset']['padding-top'])){
	$Voxotheme_mobile_offset = 0;
}
else{
	$Voxotheme_mobile_offset = preg_replace("/[^0-9]/","", $VoxcoTheme_Options['voxco_options_mobile_menu_offset']['padding-top']);
}

?>

<body <?php body_class();?> >	


	<?php do_action( 'VoxcoTheme_before' ); ?>
	<div class="loaderOverlay js-loader">
		<?php if($VoxcoTheme_Options['voxco_options_display_preloader']) { ?>
			<div id="loader">
				<?php 
					$VoxcoTheme_loader_size = max($VoxcoTheme_Options['voxco_options_loading_logo']['width'], $VoxcoTheme_Options['voxco_options_loading_logo']['height']);	
				?>
				<div id="loader-img" style="width:<?php echo esc_attr($VoxcoTheme_loader_size); ?>px; height:<?php echo esc_attr($VoxcoTheme_loader_size); ?>px;">
					<img alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_loading_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_retina_loading_logo']['url']);?>">
				</div>
			</div>
		<?php  } ?>
	</div>

	
	<div id="fb-root"></div>


	<?php if($voxco_site_layout == 'layout-side-header'){ ?>
	<header id="primary-header" class="<?php echo esc_attr($voxco_menu_layout);?>" >
		<div class="header-inner" data-mobile-nav-offset="<?php echo esc_attr($Voxotheme_mobile_offset); ?>">
			<div class="voxco-slider">
			<?php 
				$VoxcoTheme_sidebar_slider = $VoxcoTheme_Options['voxco_options_siderbar_slides'];
				$VoxcoTheme_sidebar_slides = explode(',', $VoxcoTheme_sidebar_slider);	
				
				if ( is_home() || is_search() || is_archive() || is_404() || is_attachment()) {
					$VoxcoTheme_post_sidebar_slider = get_post_meta( get_queried_object_id(), '_cmb_sidebar_slider', 1 );
				}
				else{
					$VoxcoTheme_post_sidebar_slider = get_post_meta( get_the_ID(), '_cmb_sidebar_slider', 1 );
				}
			
				if(empty($VoxcoTheme_post_sidebar_slider)){
					foreach ($VoxcoTheme_sidebar_slides as $slide ) {
						echo wp_get_attachment_image( $slide, 'full' );	
			
					} 
				}
				else {
					foreach ($VoxcoTheme_post_sidebar_slider as $attachment_id => $attachment_url) {
						echo wp_get_attachment_image( $attachment_id, 'full' );	
					}
				}
			?>
			</div>
			<?php if($voxco_menu_layout != 'l2'){ ?>
			<div class="header-panel">
				<?php if($voxco_menu_layout == 'l1'){ ?>
				<div class="nav-triggerwrap">
					<button class="nav-trigger <?php echo esc_attr($VoxcoTheme_Options['voxco_options_menu_button_style']); ?>" type="button">
						<span></span>
					</button>
				</div>
				<?php } ?>
				<?php if($voxco_menu_layout == 'l3'){ ?>
					<div class="headbox">
						<div class="headbox-side_right">
							<button class="nav-trigger <?php echo esc_attr($VoxcoTheme_Options['voxco_options_menu_button_style']); ?>" type="button">
								<span></span>
							</button>
						</div>
						<div class="headbox-base">
							<a href="<?php echo esc_url(get_home_url('/')); ?>" class="header-logo">
								<img id="mainLogo" width="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_logo']['width']); ?>" height="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_logo']['height']); ?>" alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_retina_logo']['url']); ?>"/>
								<?php if($VoxcoTheme_Options['voxco_options_mobile_logo']['url']){ ?>
									<img id="mobileLogo" width="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_mobile_logo']['width']); ?>" height="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_mobile_logo']['height']); ?>" alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_mobile_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_mobile_retina_logo']['url']); ?>"/>
								<?php } ?>
							</a>
						</div>
					</div>
					<?php } ?>
				</div>
				<div class="header-content">
				
					<?php
						if ( is_home() || is_search() || is_archive() || is_404() || is_attachment()) {
							$voxco_slider_content_pos = get_post_meta( get_queried_object_id(),'_cmb_slider_content_position', 1 );
						}
						else{
							$voxco_slider_content_pos = get_post_meta( get_the_ID(),'_cmb_slider_content_position', 1 );
						}
									
						if(empty($voxco_slider_content_pos) || $voxco_slider_content_pos == 'global' ){ 
							$voxco_slider_content_pos = $VoxcoTheme_Options['voxco_options_sidebar_content_pos'];
						}

						
					?>
					<div class="header-box  <?php echo esc_attr($voxco_slider_content_pos); ?>">
						<?php if($voxco_menu_layout == 'l1'){ ?>
							<div class="logoWrap menu-content">
								<a href="<?php echo esc_url(get_home_url('/')); ?>" class="header-logo">
									<img id="mainLogo" width="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_logo']['width']); ?>" height="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_logo']['height']); ?>" alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_retina_logo']['url']); ?>"/>
									<?php if($VoxcoTheme_Options['voxco_options_mobile_logo']['url']){ ?>
										<img id="mobileLogo" width="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_mobile_logo']['width']); ?>" height="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_mobile_logo']['height']); ?>"  alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_mobile_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_mobile_retina_logo']['url']); ?>"/>
									<?php } ?>	
								</a>
							</div>
						<?php } ?>
						<?php
						if( is_search() || is_archive() || is_404() || is_attachment() || ( 'posts' == get_option( 'show_on_front' ) && is_home() ) ){
							 $voxco_slider_content = $VoxcoTheme_Options['voxco_options_sidebar_content'];
							 $voxco_slider_content_color = $VoxcoTheme_Options['voxco_options_sidebar_content_color'];
						}
						else if ( is_home() ) {
							$voxco_slider_content = get_post_meta( get_queried_object_id(),'_cmb_slider_content', 1 );	
							$voxco_slider_content_color = get_post_meta( get_queried_object_id(),'_cmb_slider_content_color', 1 );
						} 
						else {
							$voxco_slider_content = get_post_meta( get_the_ID(),'_cmb_slider_content', 1 );
							$voxco_slider_content_color = get_post_meta( get_the_ID(),'_cmb_slider_content_color', 1 );
						}
						
						
						if(empty($voxco_slider_content_color)){ $voxco_slider_content_color = $VoxcoTheme_Options['voxco_options_sidebar_content_color'];}

						if($voxco_menu_layout == 'l3'){ ?>

							<div class="menu-content" style="color:<?php echo esc_attr($voxco_slider_content_color); ?>;">
								<?php echo do_shortcode( $voxco_slider_content );
								if ( is_page_template( 'portfolio-template.php' ) && $VoxcoTheme_portfolio_filters == 'filter-menu') {
									voxco_filters(); 
								} 
								?>
							</div>
						<?php } ?>
					</div>
					<?php
					if ( is_singular( 'portfolios' ) && $voxco_menu_layout == 'l3') {
						echo '<div class="'. get_post_meta( get_the_ID(),'_cmb_l3_navigation_style', 1 ) .'">';
						voxco_portfolio_nav(); 
						echo '</div>';
					}
					?>	 
				</div>
				
				<nav id="side-bar">
				    <div class="mainnav">
				    	<div class="scrollContainer">
				    		<nav>
				    			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); ?>
				    		</nav>
				    		<?php if ( is_page_template( 'portfolio-template.php' )  && $VoxcoTheme_portfolio_filters == 'filter-menu' && $voxco_menu_layout != 'l3') { 
				    			echo '<div class="filterBox">';
				    				voxco_filters();
				    			echo '</div>';
				    		}
				    		if($VoxcoTheme_Options['voxco_options_social_header']){
				    			echo do_shortcode('[social_networks]');
				    		} 
				    		?>
				    	</div>
					</div>
				</nav>
			<?php } else { ?>
				<div class="mainnav nav-standard">
					<button class="nav-trigger <?php echo esc_attr($VoxcoTheme_Options['voxco_options_menu_button_style']); ?>" type="button">
						<span></span>
					</button>
					<div class="nav-inner">
						<a href="<?php echo esc_url(get_home_url('/')); ?>" class="header-logo">
							<img id="mainLogo" width="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_logo']['width']); ?>" height="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_logo']['height']); ?>" alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_retina_logo']['url']); ?>"/>
							<?php if($VoxcoTheme_Options['voxco_options_mobile_logo']['url']){ ?>
								<img id="mobileLogo" width="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_mobile_logo']['width']); ?>" height="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_mobile_logo']['height']); ?>" alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_mobile_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_mobile_retina_logo']['url']); ?>"/>
							<?php } ?>
						</a>
						<nav>
						   	<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); ?>
						
						<?php
							if ( is_page_template( 'portfolio-template.php' )  && $VoxcoTheme_portfolio_filters == 'filter-menu') {
								voxco_filters();
							}
							if($VoxcoTheme_Options['voxco_options_social_header']){
								echo do_shortcode('[social_networks]');
							}
						?>
						</nav>
					</div>
				</div>
			<?php } ?>



		</div>
	</header>
<?php } 

else{ ?>

	<?php 
	if($VoxcoTheme_Options['voxco_options_nav_fixed'] == true && ($Voxotheme_desktop_offset > 1 || $Voxotheme_mobile_offset > 1 )) {  
		echo '<nav class="mainnav nav-top nav-has-offset" data-nav-offset="'.esc_attr($Voxotheme_desktop_offset).'" data-mobile-nav-offset="'.esc_attr($Voxotheme_mobile_offset).'" >';
	}
	else if($VoxcoTheme_Options['voxco_options_nav_fixed'] == false && $VoxcoTheme_Options['voxco_options_nav_button_four_fixed'] == true && ($Voxotheme_desktop_offset > 1 || $Voxotheme_mobile_offset > 1 )){
		echo '<nav class="mainnav nav-top nav-trigger-has-offset" data-nav-offset="'.esc_attr($Voxotheme_desktop_offset).'" data-mobile-nav-offset="'.esc_attr($Voxotheme_mobile_offset).'">';
	} 
	else{
		echo '<nav class="mainnav nav-top">';
	}
	?>

	<div class="nav-top-inner">
	<div class="nav-top-logo">
		<a href="<?php echo esc_url(get_home_url('/')); ?>" >
			<img id="mainLogo" width="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_logo']['width']); ?>" height="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_logo']['height']); ?>" alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_retina_logo']['url']); ?>"/>
			<?php if($VoxcoTheme_Options['voxco_options_mobile_logo']['url']){ ?>
				<img id="mobileLogo" width="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_mobile_logo']['width']); ?>" height="<?php echo esc_attr($VoxcoTheme_Options['voxco_options_mobile_logo']['height']); ?>" alt="" src="<?php echo esc_url($VoxcoTheme_Options['voxco_options_mobile_logo']['url']); ?>" data-at2x="<?php echo esc_url($VoxcoTheme_Options['voxco_options_mobile_retina_logo']['url']); ?>"/>
			<?php } ?>
		</a>
	</div>
	<?php if ( is_page_template( 'portfolio-template.php' )  && $VoxcoTheme_portfolio_filters == 'filter-menu') {
			echo "<div class='filter-menu'>";
				voxco_filters(); 
			echo "</div>";		
			echo "<span class='filter-btn " . esc_attr($VoxcoTheme_Options['voxco_options_menu_button_style']) . "'><i class='fa fa-sliders'></i></span>";
			
	}?>
		<button class="nav-trigger <?php echo esc_attr($VoxcoTheme_Options['voxco_options_menu_button_style']); ?>" type="button">
			<span></span>
		</button>
	<?php

	if($VoxcoTheme_Options['voxco_options_social_header']){
		echo do_shortcode('[social_networks]');
	} 
	wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); 
	?>


	</div>
	
</nav>


<?php } ?>
	

<main id="main" class="site-main" role="main">



<?php		
	$VoxcoTheme_header_subtitle = get_post_meta( get_the_ID(), '_cmb_single_page_subtitle', 1 );	
	$VoxcoTheme_header_subtitle_font = get_post_meta( get_the_ID(), '_cmb_single_page_subtitle_font', 1 );
	


if(is_home() || is_search() || is_archive() || is_404() || is_attachment() ){
					
	
	if('posts' == get_option( 'show_on_front' ) || is_search() || is_archive() || is_404() || is_attachment() ){

		if(is_search() || is_archive() || is_404() || is_attachment() ){
			$VoxcoTheme_display_header = 'yes';
		}
		else{
			$VoxcoTheme_display_header = $VoxcoTheme_Options['voxco_options_blog_header'];
		}
		$VoxcoTheme_header_background = $VoxcoTheme_Options['voxco_options_blog_header_image']['url'];
		$VoxcoTheme_header_background_color = $VoxcoTheme_Options['voxco_options_blog_header_color'];
		$VoxcoTheme_header_height = $VoxcoTheme_Options['voxco_options_blog_header_height'];
		$VoxcoTheme_mobile_header_height = $VoxcoTheme_Options['voxco_options_blog_header_mobile_height'];
		$VoxcoTheme_header_offset =  $VoxcoTheme_Options['voxco_options_blog_header_offset'];
		$VoxcoTheme_header_margin =  $VoxcoTheme_Options['voxco_options_blog_header_margin'];
		$VoxcoTheme_header_width = $VoxcoTheme_Options['voxco_options_blog_header_width'];
		$VoxcoTheme_header_title = $VoxcoTheme_Options['voxco_options_blog_title'];
		$VoxcoTheme_header_color = $VoxcoTheme_Options['voxco_options_blog_title_color'];
		$VoxcoTheme_header_align = $VoxcoTheme_Options['voxco_options_blog_title_align'];	
		$VoxcoTheme_header_v_align = $VoxcoTheme_Options['voxco_options_blog_title_v_align'];	
		$VoxcoTheme_rev = $VoxcoTheme_Options['voxco_options_rev'];


	}
	
	else {
		$VoxcoTheme_display_header = get_post_meta( get_queried_object_id(), '_cmb_single_page_header', 1 );
		$VoxcoTheme_header_background = get_post_meta( get_queried_object_id(), '_cmb_single_page_header_bg', 1 );	
		$VoxcoTheme_header_background_color = get_post_meta( get_queried_object_id(), '_cmb_single_page_header_color', 1 );	
		$VoxcoTheme_header_height = get_post_meta( get_queried_object_id(), '_cmb_single_page_header_height', 1 );
		$VoxcoTheme_mobile_header_height = get_post_meta( get_queried_object_id(), '_cmb_single_page_header_mobile_height', 1 );
		$VoxcoTheme_header_offset =  get_post_meta( get_queried_object_id(), '_cmb_single_page_header_offset', 1 );
		$VoxcoTheme_header_margin =  get_post_meta( get_queried_object_id(), '_cmb_single_page_header_margin_bottom', 1 );
		$VoxcoTheme_header_width = get_post_meta( get_queried_object_id(), '_cmb_single_page_header_width', 1 );	
		$VoxcoTheme_header_title = get_post_meta( get_queried_object_id(), '_cmb_single_page_title', 1 );		
		$VoxcoTheme_header_color = get_post_meta( get_queried_object_id(), '_cmb_single_page_color', 1 );	
		$VoxcoTheme_header_align = get_post_meta( get_queried_object_id(), '_cmb_single_page_align', 1 );	
		$VoxcoTheme_header_v_align = get_post_meta( get_queried_object_id(), '_cmb_single_page_v_align', 1 );	
		$VoxcoTheme_rev = get_post_meta( get_queried_object_id(), '_cmb_rev', 1 );	
		$VoxcoTheme_header_meta_color = get_post_meta( get_queried_object_id(), '_cmb_single_page_subtitle_color', 1 );
		$VoxcoTheme_header_subtitle = get_post_meta( get_queried_object_id(), '_cmb_single_page_subtitle', 1 );	
		$VoxcoTheme_header_subtitle_font = get_post_meta( get_queried_object_id(), '_cmb_single_page_subtitle_font', 1 );
	}
	

}
else if(is_page()){
	$VoxcoTheme_display_header = get_post_meta( get_the_ID(), '_cmb_single_page_header', 1 );				
	$VoxcoTheme_header_background = get_post_meta( get_the_ID(), '_cmb_single_page_header_bg', 1 );	
	$VoxcoTheme_header_background_color = get_post_meta( get_queried_object_id(), '_cmb_single_page_header_color', 1 );	
	$VoxcoTheme_header_height = get_post_meta( get_the_ID(), '_cmb_single_page_header_height', 1 );
	$VoxcoTheme_mobile_header_height = get_post_meta( get_the_ID(), '_cmb_single_page_header_mobile_height', 1 );
	$VoxcoTheme_header_offset =  get_post_meta( get_the_ID(), '_cmb_single_page_header_offset', 1 );
	$VoxcoTheme_header_margin =  get_post_meta( get_the_ID(), '_cmb_single_page_header_margin_bottom', 1 );
	$VoxcoTheme_header_width = get_post_meta( get_the_ID(), '_cmb_single_page_header_width', 1 );	
	$VoxcoTheme_header_title = get_post_meta( get_the_ID(), '_cmb_single_page_title', 1 );		
	$VoxcoTheme_header_color = get_post_meta( get_the_ID(), '_cmb_single_page_color', 1 );	
	$VoxcoTheme_header_align = get_post_meta( get_the_ID(), '_cmb_single_page_align', 1 );	
	$VoxcoTheme_header_v_align = get_post_meta( get_the_ID(), '_cmb_single_page_v_align', 1 );	
	$VoxcoTheme_rev = get_post_meta( get_the_ID(), '_cmb_rev', 1 );	
	$VoxcoTheme_header_meta_color = get_post_meta( get_the_ID(), '_cmb_single_page_subtitle_color', 1 );

}
else{
	$VoxcoTheme_display_header = get_post_meta( get_the_ID(), '_cmb_single_post_header', 1 );				
	$VoxcoTheme_header_background = get_post_meta( get_the_ID(), '_cmb_single_post_header_bg', 1 );	
	$VoxcoTheme_header_background_color = get_post_meta( get_the_ID(), '_cmb_single_post_header_color', 1 );	
	$VoxcoTheme_header_height = get_post_meta( get_the_ID(), '_cmb_single_post_header_height', 1 );	
	$VoxcoTheme_mobile_header_height = get_post_meta( get_the_ID(), '_cmb_single_post_header_mobile_height', 1 );	
	$VoxcoTheme_header_offset =  get_post_meta( get_the_ID(), '_cmb_single_post_header_offset', 1 );	
	$VoxcoTheme_header_margin =  get_post_meta( get_the_ID(), '_cmb_single_post_header_margin_bottom', 1 );
	$VoxcoTheme_header_width = get_post_meta( get_the_ID(), '_cmb_single_post_header_width', 1 );	
	$VoxcoTheme_header_title = get_post_meta( get_the_ID(), '_cmb_single_post_title', 1 );		
	$VoxcoTheme_header_meta = get_post_meta( get_the_ID(), '_cmb_single_post_meta', 1 );
	$VoxcoTheme_header_color = get_post_meta( get_the_ID(), '_cmb_single_post_color', 1 );	
	$VoxcoTheme_header_align = get_post_meta( get_the_ID(), '_cmb_single_post_align', 1 );
	$VoxcoTheme_header_v_align = get_post_meta( get_the_ID(), '_cmb_single_post_v_align', 1 );
	$VoxcoTheme_rev = get_post_meta( get_the_ID(), '_cmb_post_rev', 1 );	
	$VoxcoTheme_header_meta_color = get_post_meta( get_the_ID(), '_cmb_single_post_meta_color', 1 );
}

$voxco_site_width = $VoxcoTheme_Options['voxco_options_site_width']; 

?>


<div class="content<?php if($voxco_site_width){echo ' content-boxed';}?>" data-offset-top="<?php echo esc_attr($Voxotheme_desktop_offset); ?>" data-mobile-offset-top="<?php echo esc_attr($Voxotheme_mobile_offset); ?>" style="padding:<?php echo esc_attr( get_post_meta( get_the_ID(), '_cmb_page_padding',true ) ); ?>;">	

<?php
if(empty($VoxcoTheme_header_height)){
	$VoxcoTheme_header_height = 'h2';
} 

if($VoxcoTheme_display_header == 'yes' || $VoxcoTheme_display_header == 'parallax' || empty($VoxcoTheme_display_header) ){ ?>
		<?php echo "<header class='post-header wpb_column ". esc_attr($VoxcoTheme_header_height) . " " . esc_attr($VoxcoTheme_header_width) . " " .  esc_attr($VoxcoTheme_mobile_header_height) . "' data-header-offset='".esc_attr($VoxcoTheme_header_offset)."'";  
				if($VoxcoTheme_display_header != 'parallax'){
					echo " style='background-image:url(". esc_url($VoxcoTheme_header_background) ."); background-color:".esc_attr($VoxcoTheme_header_background_color)."; margin-bottom:".esc_attr($VoxcoTheme_header_margin)."px;' >";
				}
				else{
					echo " style='margin-bottom:".esc_attr($VoxcoTheme_header_margin)."px;'>";
				}
		?>

			<?php if($VoxcoTheme_header_title != 'none'){ ?>
			<div class="vocxo-content-wrapper">

				<div class="post-meta <?php echo esc_attr($VoxcoTheme_header_align) .' '. esc_attr($VoxcoTheme_header_v_align); if(!empty($VoxcoTheme_header_color)){ echo esc_attr(' has-color'); }?>" style="color:<?php echo esc_attr($VoxcoTheme_header_color); ?>;">
					
					<?php if(is_home()){ 
						
						if('posts' == get_option( 'show_on_front') ){ ?>
							<h1 class="<?php echo esc_attr($VoxcoTheme_header_title); ?>"><?php echo esc_html($VoxcoTheme_Options['voxco_options_blog_title_text']); ?></h1>
						<?php } 
						
						else{ ?>
							<h1 class="<?php echo esc_attr($VoxcoTheme_header_title); ?>"><?php echo apply_filters( 'the_title', get_the_title( get_option( 'page_for_posts' ) ) ); ?></h1>
						<?php } 
					}
					else if (is_archive()) {
						the_archive_title( '<h1 class="'.$VoxcoTheme_header_title.'">', '</h1>' );
					}
					else if (is_search()) { ?>
					 	<h1 class="<?php echo esc_attr($VoxcoTheme_header_title); ?>"><?php the_search_query();  ?></h1>
					
					<?php }
					else if(is_404()){ ?>
						<h1 class="mega"><?php echo esc_html__('404', 'voxco'); ?></h1>
						<p class="entry-details"><span class="accent"><?php echo esc_html__("Oops! That page can't be found.", 'voxco'); ?></span></h1>
					<?php } 


					else { ?>
						<h1 class="<?php echo esc_attr($VoxcoTheme_header_title); ?>"><?php the_title();  ?></h1>
					<?php } 
					
					

					if($VoxcoTheme_header_subtitle){

						echo '<h2 class="'. esc_attr($VoxcoTheme_header_subtitle_font) .'" style="color:'. esc_attr($VoxcoTheme_header_meta_color) .';">' . esc_html($VoxcoTheme_header_subtitle) . '</h2>';
					}
					else if( is_single() ){ ?>
						<div class="entry-details <?php echo esc_attr($VoxcoTheme_header_meta); ?>" style="color:<?php echo esc_attr($VoxcoTheme_header_meta_color); ?>;">
							<?php 
							$post_id = get_queried_object_id();
							$post_author_id = get_post_field( 'post_author', $post_id );
	
							echo esc_html__('By ', 'voxco');
							the_author_meta('display_name', $post_author_id);
							?>
							<span class="postdate"><?php echo get_the_date('j M Y'); ?></span>
						</div>
					<?php } ?>	
				</div>
			</div>
			<?php } ?>
			<?php if($VoxcoTheme_display_header == 'parallax'){
						echo "<div class='voxco-parallax' style='background-image:url(". esc_url($VoxcoTheme_header_background) .");' data-anchor-target='.post-header' data-0='top: -20%;' data-top-bottom='top: 45%;'></div>"; 
					} ?>
		</header>	
<?php }

else if($VoxcoTheme_display_header == 'rev'){ 
	echo "<div class='post-header wpb_column has-rev ". esc_attr($VoxcoTheme_header_height) . " " . esc_attr($VoxcoTheme_header_width) ."' data-header-offset='".esc_attr($VoxcoTheme_header_offset)."' style='margin-bottom:".esc_attr($VoxcoTheme_header_margin)."px;'><div class='vocxo-content-wrapper'>";
	if(shortcode_exists("rev_slider") && !empty($VoxcoTheme_rev)){
		echo do_shortcode('[rev_slider '.$VoxcoTheme_rev.']');	
	}
	echo "</div></div>";
} 




?>







			



