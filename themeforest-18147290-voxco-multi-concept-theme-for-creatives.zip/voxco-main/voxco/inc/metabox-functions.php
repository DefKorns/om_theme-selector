<?php
/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB directory)
 *
 * @category Voxco
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/webdevstudios/Custom-Metaboxes-and-Fields-for-WordPress
 */

/**
 * Get the bootstrap! If using the plugin from wordpress.org, REMOVE THIS!
 */

if ( file_exists( dirname( __FILE__ ) . '/cmb2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  CMB2_Field object $field Field object
 *
 * @return bool                     True if metabox should show
 */
function cmb2_hide_if_no_cats( $field ) {
	// Don't show this field if not in the cats category
	if ( ! has_tag( 'cats', $field->object_id ) ) {
		return false;
	}
	return true;
}



add_filter( 'cmb2_meta_boxes', 'VoxcoTheme_metaboxes' );



/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
function VoxcoTheme_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_cmb_';


	global $VoxcoTheme_Options; 
	$VoxcoTheme_masonary_grid = $VoxcoTheme_Options['voxco_options_masonary_grid'];
	$voxco_menu_layout = $VoxcoTheme_Options['voxco_options_menu_style'];
	$voxco_site_layout = $VoxcoTheme_Options['voxco_options_site_layout'];
	


	if($VoxcoTheme_masonary_grid == 'quarters'){
		$grid_sizes = array(
			'p12' => esc_html__( 'Full Width', 'voxco' ),
			'p4' => esc_html__( 'One Third', 'voxco' ),
			'p8'   => esc_html__( 'Two Thirds', 'voxco' ),
		);
	}
	else{
		$grid_sizes = array(
			'p12' => esc_html__( 'Full Width', 'voxco' ),
			'p6'   => esc_html__( 'One Half', 'voxco' ),
			'p3'     => esc_html__( 'One Quarter', 'voxco' ),
			'p9'     => esc_html__( 'Three Quarters', 'voxco' ),
		);
	}

	$meta_boxes['portfolio_metabox'] = array(
		'id'           => 'portfolio_metabox',
		'title'        => esc_html__( 'Post Options', 'voxco' ),
		'object_types' => array( 'portfolios'), // Post type
		'context'      => 'normal',
		'priority'     => 'core',
		'show_names'   => true, 
		'fields' => array(
			array(
				'name'         => esc_html__( 'Custom URL', 'voxco' ),
				'desc'         => esc_html__( 'Custom URL for portfolio thumbnail to link to ', 'voxco' ),
				'id'           => $prefix . 'custom_url',
				'type'         => 'text',
			),
			array(
				'name'    => esc_html__( 'Custom URL Target', 'voxco' ),
				'id'      => $prefix . 'custom_url_target',
				'type'    => 'select',
				'options' => array(
					'_self' => esc_html__( 'Self', 'voxco' ),
					'_blank' => esc_html__( 'Blank', 'voxco' ),
				),
				'default'  => '_self',
			),
			array(
				'name'    => esc_html__( 'Link Thumbnail', 'voxco' ),
				'id'      => $prefix . 'thumb_link',
				'type'    => 'select',
				'options' => array(
					'yes' => esc_html__( 'Yes', 'voxco' ),
					'no' => esc_html__( 'No', 'voxco' ),
				),
				'default'  => 'yes',
			),
			array(
				'name'    => esc_html__( 'Thumbnail Width', 'voxco' ),
				'id'      => $prefix . 'thumbnail_width',
				'type'    => 'select',
				'options' => $grid_sizes,

			),
	
			array(
			    'name' => esc_html__( 'Caption Background Color',  'voxco' ),
			    'id'   => $prefix . 'caption_background_single',
			    'type' => 'colorpicker',
			    'default'  => '',
			),
			array(
			    'name' => esc_html__('Caption Heading Color', 'voxco' ),
			    'id'   => $prefix . 'caption_heading_single',
			    'type' => 'colorpicker',
				    'default'  => '',
				),

			array(
			    'name' => esc_html__( 'Caption Categories Color', 'voxco' ),
			    'id'   => $prefix . 'caption_categories_single',
			    'type' => 'colorpicker',
			    'default'  => '',
			),
			array(
				'name'    => esc_html__( 'Caption Vertical Alignment', 'voxco' ),
				'id'      => $prefix . 'caption_single_v_align',
				'type'    => 'select',
				'default'   => 'caption-va-default',
				'options' => array(
					'caption-va-deafult' => esc_html__( 'Default', 'voxco' ),
					'caption-va-top' => esc_html__( 'Top', 'voxco' ),
					'caption-va-middle' => esc_html__( 'Middle', 'voxco' ),
					'caption-va-bottom' => esc_html__( 'Bottom', 'voxco' ),
				),
				
			),
			array(
				'name'    => esc_html__( 'Caption Horizontal Alignment', 'voxco' ),
				'id'      => $prefix . 'caption_single_h_align',
				'type'    => 'select',
				'default'   => 'caption-ha-default',
				'options' => array(
					'caption-ha-default' => esc_html__( 'Default', 'voxco' ),
					'caption-ha-left' => esc_html__( 'Left', 'voxco' ),
					'caption-ha-right' => esc_html__( 'Right', 'voxco' ),
					'caption-ha-center' => esc_html__( 'Center', 'voxco' ),
				),
				
			),
			array(
				'name'    => esc_html__( 'Caption Crosshair Position', 'voxco' ),
				'id'      => $prefix . 'caption_single_ch_align',
				'type'    => 'select',
				'default'   => 'caption-ch-default',
				'options' => array(
					'caption-ch-default' => esc_html__( 'Default', 'voxco' ),
					'caption-ch-top-left' => esc_html__( 'Top Left', 'voxco' ),
					'caption-ch-top-right' => esc_html__( 'Top Right', 'voxco' ),
					'caption-ch-btm-left' => esc_html__( 'Bottom Left', 'voxco' ),
					'caption-ch-btm-right' => esc_html__( 'Bottom Right', 'voxco' ),
					'caption-ch-none' => esc_html__( 'No Crosshair', 'voxco' ),
					
				),
		
			),
			array(
				'name'    => esc_html__( 'Thumbnail Style', 'voxco' ),
				'id'      => $prefix . 'thumb_style',
				'type'    => 'select',
				'options' => array(
					'standard' => esc_html__( 'Standard', 'voxco' ),
					'text-on' => esc_html__( 'Text On Image', 'voxco' ),
				),
				'default'  => 'standard',
			),

			array(
				'name' => esc_html__( 'Thumbnail Style Text On Image Text', 'voxco' ),
				'desc'         => esc_html__( 'Text content for "Text On Image" style thumbnail. Accepts the following html tags and attributes. <a href="" title=""></a>, <em></em>, <strong></strong>, <span style=""></span>', 'voxco' ),
				'id' => $prefix .'thumbnail_content',
				'type' => 'wysiwyg',
				'options' => array(
				    'textarea_rows' => get_option('default_post_edit_rows', 5), // rows="..."
				),
			),
			array(
					'name'    => esc_html__( 'Thumbnail Style Text On Image Font', 'voxco' ),
					'id'      => $prefix . 'text_on_image_font',
					'type'    => 'select',
					'default'   => 'none',
					'options' => array(
						'mega' => esc_html__( 'Mega font', 'voxco' ),
						'alpha' => esc_html__( 'Heading 1 font', 'voxco' ),
						'beta' => esc_html__( 'Heading 2 font', 'voxco' ),
						'gamma' => esc_html__( 'Heading 3 font', 'voxco' ),
						'delta' => esc_html__( 'Heading 4 font', 'voxco' ),
						'epsilon' => esc_html__( 'Heading 5 font', 'voxco' ),
						'zeta' => esc_html__( 'Heading 6 font', 'voxco' ),
						'accent' => esc_html__( 'Accent Font', 'voxco' ),

					),
					'default'  => 'alpha',
				),
			
		

		)
	);

	if($voxco_menu_layout != 'l3' or $voxco_site_layout == 'layout-standard-header'){
		$meta_boxes['portfolio_nav_metabox'] = array(
			'id'           => 'portfolio_nav_metabox',
			'title'        => esc_html__( 'Post Navigation', 'voxco' ),
			'object_types' => array( 'portfolios', ), // Post type
			'context'      => 'normal',
			'priority'     => 'core',
			'show_names'   => true, // Show field names on the left
			'fields' => array(
			
				array(
				    'name' => esc_html__('Share Background Color', 'voxco' ),
				    'id'   => $prefix . 'share_background',
				    'type' => 'colorpicker',
				    'default'  => '#1d1d1d',
				),
				array(
				    'name' => esc_html__('Share Icon Color', 'voxco' ),
				    'id'   => $prefix . 'share_icon',
				    'type' => 'colorpicker',
				    'default'  => '#ffffff',
				),
				array(
				    'name' => esc_html__('Prev/Next Post Navigtion Background Color', 'voxco' ),
				    'id'   => $prefix . 'prev_next_background',
				    'type' => 'colorpicker',
				    'default'  => '#c8c8c8',
				),
				array(
				    'name' => esc_html__('Post Navigation Feature Image', 'voxco' ),
				    'desc'    => esc_html__('Feature image for the posts previous/next link', 'voxco' ),
				    'id'   => $prefix . 'portfolio_nav_background',
				    'type' => 'file',
				    'default'  => '',
				),
	
			)
		);
	}
	
	$Voxco_taxonomy_exist = taxonomy_exists('portfolio_item_category');
	if($Voxco_taxonomy_exist){
		$meta_boxes['portfolio_page_metabox'] = array(
			'id'           => 'portfolio_page_metabox',
			'title'        => esc_html__( 'Portfolio Options', 'voxco' ),
			'object_types' => array( 'page' ), // post type
	        'show_on'      => array( 'key' => 'page-template', 'value' => 'portfolio-template.php' ),
			'context'      => 'normal',
			'priority'     => 'core',
			'show_names'   => true, // Show field names on the left
			'fields' => array(

				array(
				    'name'    => esc_html__('Categories', 'voxco' ),
				    'desc'    => esc_html__('Select portfolio categories to include', 'voxco' ),
				    'id'      => $prefix . 'portfolio_categories',
				    'type'    => 'multicheck',
				    'inline' => true,
				    'options' => VoxcoTheme_get_term_options(),
				),
				array(
					'name'    => esc_html__( 'Filter Style', 'voxco' ),
					'id'      => $prefix . 'portfolio_filter',
					'type'    => 'select',
					'default'   => 'none',
					'options' => array(
						'filter-menu' => esc_html__( 'In Main Menu', 'voxco' ),
						'filter-above' => esc_html__( 'Above Portfolio', 'voxco' ),
						'filter-none' => esc_html__( 'No Filters', 'voxco' ),


					),
					'default'  => 'filter-menu',
				),
				array(
				    'name' => esc_html__('Caption Background Color', 'voxco' ),
				    'id'   => $prefix . 'caption_background',
				    'type' => 'colorpicker',
				    'default'  => '#2a2a2a',
				),
				array(
				    'name' => esc_html__('Caption Heading Color', 'voxco' ),
				    'id'   => $prefix . 'caption_heading',
				    'type' => 'colorpicker',
				    'default'  => '#efefef',
				),
				array(
					'name'    => esc_html__( 'Caption Heading Font', 'voxco' ),
					'id'      => $prefix . 'caption_heading_font',
					'type'    => 'select',
					'default'   => 'none',
					'options' => array(
						'alpha' => esc_html__( 'Heading 1 font', 'voxco' ),
						'beta' => esc_html__( 'Heading 2 font', 'voxco' ),
						'gamma' => esc_html__( 'Heading 3 font', 'voxco' ),
						'delta' => esc_html__( 'Heading 4 font', 'voxco' ),
						'epsilon' => esc_html__( 'Heading 5 font', 'voxco' ),
						'zeta' => esc_html__( 'Heading 6 font', 'voxco' ),

					),
					'default'  => 'beta',
				),
				array(
				    'name' => esc_html__('Caption Categories Color', 'voxco' ),
				    'id'   => $prefix . 'caption_categories',
				    'type' => 'colorpicker',
				    'default'  => '#cccccc',
				),
				array(
					'name'    => esc_html__( 'Caption Categories Font', 'voxco' ),
					'id'      => $prefix . 'caption_categories_font',
					'type'    => 'select',
					'default'   => 'accent',
					'options' => array(
						'alpha' => esc_html__( 'Heading One Font', 'voxco' ),
						'beta' => esc_html__( 'Heading Two Font', 'voxco' ),
						'gamma' => esc_html__( 'Heading Three Font', 'voxco' ),
						'delta' => esc_html__( 'Heading Four Font', 'voxco' ),
						'epsilon' => esc_html__( 'Heading Five Font', 'voxco' ),
						'zeta' => esc_html__( 'Heading Six Font', 'voxco' ),
						'accent' => esc_html__( 'Accent Font', 'voxco' ),

					),
				),
				array(
					'name'    => esc_html__( 'Caption Vertical Alignment', 'voxco' ),
					'id'      => $prefix . 'caption_v_align',
					'type'    => 'select',
					'default'   => 'caption-va-bottom',
					'options' => array(
						'caption-va-top' => esc_html__( 'Top', 'voxco' ),
						'caption-va-middle' => esc_html__( 'Middle', 'voxco' ),
						'caption-va-bottom' => esc_html__( 'Bottom', 'voxco' ),

					),
					
				),
				array(
					'name'    => esc_html__( 'Caption Horizontal Alignment', 'voxco' ),
					'id'      => $prefix . 'caption_h_align',
					'type'    => 'select',
					'default'   => 'caption-ha-left',
					'options' => array(
						'caption-ha-left' => esc_html__( 'Left', 'voxco' ),
						'caption-ha-right' => esc_html__( 'Right', 'voxco' ),
						'caption-ha-center' => esc_html__( 'Center', 'voxco' ),

					),
				
				),
				array(
					'name'    => esc_html__( 'Caption Crosshair Position', 'voxco' ),
					'id'      => $prefix . 'caption_ch_align',
					'type'    => 'select',
					'default'   => 'caption-ch-top-right',
					'options' => array(
						'caption-ch-top-left' => esc_html__( 'Top Left', 'voxco' ),
						'caption-ch-top-right' => esc_html__( 'Top Right', 'voxco' ),
						'caption-ch-btm-left' => esc_html__( 'Bottom Left', 'voxco' ),
						'caption-ch-btm-right' => esc_html__( 'Bottom Right', 'voxco' ),
						'caption-ch-none' => esc_html__( 'No Crosshair', 'voxco' ),
						

					),
			
				),
				array(
					'name'    => esc_html__( 'Caption Hover Animation', 'voxco' ),
					'id'      => $prefix . 'caption_animation_style',
					'type'    => 'select',
					'options' => array(
						'hover-slide-up' => esc_html__( 'Slide Up', 'voxco' ),
						'hover-fade' => esc_html__( 'Fade In', 'voxco' ),

					),
					'default'  => 'hover-slide-up',
				),



			)
		);
	}

		$meta_boxes['post_options'] = array(
			'id'           => 'post_options',
			'title'        => esc_html__( 'Post Options', 'voxco' ),
			'object_types' => array( 'post', ), // Post type
			'context'      => 'normal',
			'priority'     => 'core',
			'show_names'   => true, // Show field names on the left
			'fields' => array(
			
				
				array(
				    'name' => esc_html__( 'Excerpt Background Color', 'voxco' ),
				    'id'   => $prefix . 'excerpt_background_color',
				    'type' => 'colorpicker',
				    'default'  => '',
				),
				array(
				    'name' => esc_html__( 'Excerpt Font Color', 'voxco' ),
				    'id'   => $prefix . 'excerpt_font_color',
				    'type' => 'colorpicker',
				    'default'  => '',
				),
				array(
				    'name' => esc_html__( 'Excerpt Heading Color', 'voxco' ),
				    'id'   => $prefix . 'excerpt_heading_color',
				    'type' => 'colorpicker',
				    'default'  => '',
				),
				array(
					'name'    => esc_html__( 'Display Feature Image In Post Content', 'voxco' ),
					'id'      => $prefix . 'feature_display',
					'type'    => 'select',
					'default'   => 'yes',
					'options' => array(
						'yes' => esc_html__( 'Yes', 'voxco' ),
						'no' => esc_html__( 'No', 'voxco' ),

					),
				),
				
	
			)
		);

	
function voxco_meta_rev() {
	if(shortcode_exists("rev_slider")){ 	 
		 $slider = new RevSlider();
		 $revolution_sliders = $slider->getArrSliders();
		 $slider_options = array();
		 foreach ( $revolution_sliders as $revolution_slider  ) {
		       $alias = $revolution_slider->getAlias();
		       $title = $revolution_slider->getTitle();
		       $slider_options[ $alias ] = $title;
		 }
		
	}
	else{
		$slider_options = array('none' => esc_html__( 'No Sliders Found', 'voxco' ));
	}
	return $slider_options; 
}



	$meta_boxes['post_metabox'] = array(
		'id'           => 'post_header',
		'title'        => esc_html__( 'Post Header', 'voxco' ),
		'object_types' => array( 'post','portfolios' ), // Post type
		'context'      => 'normal',
		'priority'     => 'core',
		'show_names'   => true, // Show field names on the left
		'fields' => array(
		
			
			array(
				'name'    => esc_html__( 'Post Header Style', 'voxco' ),
				'id'      => $prefix . 'single_post_header',
				'type'    => 'select',
				'default'   => 'yes',
				'options' => array(
					'yes' => esc_html__( 'Static Image / Solid Color Header', 'voxco' ),
					'parallax' => esc_html__( 'Parallax Image header', 'voxco' ),
					'rev' => esc_html__( 'Revolution Slider', 'voxco' ),
					'no' => esc_html__( 'No Header (can be added with visual composer)', 'voxco' ),
				),
			),
			array(
				'name'    => esc_html__( 'Revolution Slider', 'voxco' ),
				'id'      => $prefix . 'post_rev',
				'type'    => 'select',
				'desc'         => esc_html__( 'Select Revoultion Slider (Revololution slider header style must be selected)', 'voxco' ),
				'options' => voxco_meta_rev(),

			),
			array(
				'name'    => esc_html__( 'Post Header Height', 'voxco' ),
				'id'      => $prefix . 'single_post_header_height',
				'type'    => 'select',
				'default'   => 'h2',
				'desc'         => esc_html__( 'Select the height relative to header width', 'voxco' ),
				'options' => array(
					'h1' => esc_html__( 'Full (1:1)', 'voxco' ),
					'h2' => esc_html__( 'Half (2:1)', 'voxco' ),
					'h3' => esc_html__( 'Third (3:1)', 'voxco' ),
					'h4' => esc_html__( 'Quarter (4:1)', 'voxco' ),
					'hs' => esc_html__( 'Full Screen', 'voxco' ),
					'auto' => esc_html__( 'Auto', 'voxco' ),
				),
			),
			array(
				'name'    => esc_html__( 'Post Header Height On Mobile', 'voxco' ),
				'id'      => $prefix . 'single_post_header_mobile_height',
				'type'    => 'select',
				'default'   => 'mh2',
				'desc'         => esc_html__( 'Select the height relative to header width', 'voxco' ),
				'options' => array(
					'mh1' => esc_html__( 'Full (1:1)', 'voxco' ),
					'mh2' => esc_html__( 'Half (2:1)', 'voxco' ),
					'mh3' => esc_html__( 'Third (3:1)', 'voxco' ),
					'mh4' => esc_html__( 'Quarter (4:1)', 'voxco' ),
					'mhs' => esc_html__( 'Full Screen', 'voxco' ),
					'auto' => esc_html__( 'Auto', 'voxco' ),
				),
			),
			array(
				'name'         => esc_html__( 'Full Screen Header Offset Size (Pixels)', 'voxco' ),
				'desc'         => esc_html__( 'Offset Size For Full Screen Header', 'voxco' ),
				'id'           => $prefix . 'single_post_header_offset',
				'default'  => '0',
				'type'         => 'text_medium',
				'attributes' => array(
			        'type' => 'number',
			        'min'  => '0',
			    ),

				
			),
			array(
				'name'    => esc_html__( 'Post Header Stretch', 'voxco' ),
				'id'      => $prefix . 'single_post_header_width',
				'type'    => 'select',
				'default'   => 'row-full',
				'options' => array(
					'row-boxed' => esc_html__( 'Default', 'voxco' ),
					'row-full-boxed' => esc_html__( 'Stretch Header', 'voxco' ),
					'row-full' => esc_html__( 'Stretch Header And Content', 'voxco' ),
					
				),
			),
			array(
				'name'         => esc_html__( 'Post Header Margin Bottom', 'voxco' ),
				'desc'         => esc_html__( 'Margin Bottom For Post Header (Pixels)', 'voxco' ),
				'id'           => $prefix . 'single_post_header_margin_bottom',
				'default'  => '0',
				'type'         => 'text_medium',
				'attributes' => array(
			        'type' => 'number',
			        'min'  => '0',
			    ),

				
			),

			array(
				'name'    => esc_html__( 'Post Title', 'voxco' ),
				'id'      => $prefix . 'single_post_title',
				'type'    => 'select',
				'default'   => 'alpha',
				'options' => array(
					'mega' => esc_html__( 'Mega Font', 'voxco' ),
					'alpha' => esc_html__( 'Heading One Font', 'voxco' ),
					'beta' => esc_html__( 'Heading Two Font', 'voxco' ),
					'gamma' => esc_html__( 'Heading Three Font', 'voxco' ),
					'delta' => esc_html__( 'Heading Four Font', 'voxco' ),
					'epsilon' => esc_html__( 'Heading Five Font', 'voxco' ),
					'zeta' => esc_html__( 'Heading Six Font', 'voxco' ),
					'accent' => esc_html__( 'Accent Font', 'voxco' ),
					'none'     => esc_html__( 'No Title', 'voxco' ),
				),
			),
			array(
				'name'    => esc_html__( 'Post Meta', 'voxco' ),
				'id'      => $prefix . 'single_post_meta',
				'type'    => 'select',
				'default'   => 'zeta',
				'options' => array(
					'mega' => esc_html__( 'Mega Font', 'voxco' ),
					'alpha' => esc_html__( 'Heading One Font', 'voxco' ),
					'beta' => esc_html__( 'Heading Two Font', 'voxco' ),
					'gamma' => esc_html__( 'Heading Three Font', 'voxco' ),
					'delta' => esc_html__( 'Heading Four Font', 'voxco' ),
					'epsilon' => esc_html__( 'Heading Five Font', 'voxco' ),
					'zeta' => esc_html__( 'Heading Six Font', 'voxco' ),
					'accent' => esc_html__( 'Accent Font', 'voxco' ),
				),
			),
			array(
				'name' => esc_html__('Post Title Color', 'voxco' ),
				'id'   => $prefix . 'single_post_color',
				'type' => 'colorpicker',
				'default'  => '',
			),
			array(
				'name' => esc_html__('Post Meta Color', 'voxco' ),
				'id'   => $prefix . 'single_post_meta_color',
				'type' => 'colorpicker',
				'default'  => '',
			),
			array(
				'name'    => esc_html__( 'Post Title Alignment', 'voxco' ),
				'id'      => $prefix . 'single_post_align',
				'type'    => 'select',
				'default'   => 'align-left',
				'options' => array(
					'align-left' => esc_html__( 'Left', 'voxco' ),
					'align-right' => esc_html__( 'Right', 'voxco' ),
					'align-center' => esc_html__( 'Center', 'voxco' ),
				),
			),
			array(
				'name'    => esc_html__( 'Post Title Vertical Alignment', 'voxco' ),
				'id'      => $prefix . 'single_post_v_align',
				'type'    => 'select',
				'default'   => 'a-center',
				'options' => array(
					'a-center' => esc_html__( 'Center', 'voxco' ),
					'a-top' => esc_html__( 'Top', 'voxco' ),
					'a-bottom' => esc_html__( 'Bottom', 'voxco' ),
				),
			),
			array(
				'name'         => esc_html__( 'Post Header Background Image', 'voxco' ),
				'desc'         => esc_html__( 'Upload images to be displayed in the post/page header.', 'voxco' ),
				'id'           => $prefix . 'single_post_header_bg',
				'type'         => 'file',
			),
			array(
				'name' => esc_html__('Post Header Background Color','voxco' ),
				'id'   => $prefix . 'single_post_header_color',
				'type' => 'colorpicker',
				'default'  => '#dddddd',
			),

		)
	);






	$meta_boxes['page_header_metabox'] = array(
		'id'           => 'page_header',
		'title'        => __( 'Page Header', 'voxco' ),
		'object_types' => array( 'page' ), // Post type
		'context'      => 'normal',
		'priority'     => 'core',
		'show_names'   => true, // Show field names on the left
		'fields' => array(

			array(
				'name'    => esc_html__( 'Page Header Style', 'voxco' ),
				'id'      => $prefix . 'single_page_header',
				'type'    => 'select',
				'default'   => 'yes',
				'options' => array(
					'yes' => esc_html__( 'Static Image / Solid Color Header', 'voxco' ),
					'parallax' => esc_html__( 'Parallax Image header', 'voxco' ),
					'rev' => esc_html__( 'Revolution Slider', 'voxco' ),
					'no' => esc_html__( 'No Header (can be added with visual composer)', 'voxco' ),
				),
			),

			array(
				'name'    => esc_html__( 'Revolution Slider', 'voxco' ),
				'id'      => $prefix . 'rev',
				'type'    => 'select',
				'desc'         => esc_html__( 'Select Revoultion Slider (Revololution slider header style must be selected)', 'voxco' ),
				'options' => voxco_meta_rev(),

			),


			array(
				'name'    => esc_html__( 'Page Header Height', 'voxco' ),
				'id'      => $prefix . 'single_page_header_height',
				'type'    => 'select',
				'default'   => 'h2',
				'desc'         => esc_html__( 'Select the height relative to header width', 'voxco' ),
				'options' => array(
					'h1' => esc_html__( 'Full (1:1)', 'voxco' ),
					'h2' => esc_html__( 'Half (2:1)', 'voxco' ),
					'h3' => esc_html__( 'Third (3:1)', 'voxco' ),
					'h4' => esc_html__( 'Quarter (4:1)', 'voxco' ),
					'hs' => esc_html__( 'Full Screen', 'voxco' ),
					'auto' => esc_html__( 'Auto', 'voxco' ),
				),
			),
			array(
				'name'    => esc_html__( 'Post Header Height On Mobile', 'voxco' ),
				'id'      => $prefix . 'single_page_header_mobile_height',
				'type'    => 'select',
				'default'   => 'mh2',
				'desc'         => esc_html__( 'Select the height relative to header width', 'voxco' ),
				'options' => array(
					'mh1' => esc_html__( 'Full (1:1)', 'voxco' ),
					'mh2' => esc_html__( 'Half (2:1)', 'voxco' ),
					'mh3' => esc_html__( 'Third (3:1)', 'voxco' ),
					'mh4' => esc_html__( 'Quarter (4:1)', 'voxco' ),
					'mhs' => esc_html__( 'Full Screen', 'voxco' ),
					'auto' => esc_html__( 'Auto', 'voxco' ),
				),
			),
			array(
				'name'         => esc_html__( 'Full Screen Header Offset Size (Pixels)', 'voxco' ),
				'desc'         => esc_html__( 'Offset Size For Full Screen Header', 'voxco' ),
				'id'           => $prefix . 'single_page_header_offset',
				'default'  => '0',
				'type'         => 'text_medium',
				'attributes' => array(
			        'type' => 'number',
			        'min'  => '0',
			    ),
				
			),
			array(
				'name'    => esc_html__( 'Page Header Stretch', 'voxco' ),
				'id'      => $prefix . 'single_page_header_width',
				'type'    => 'select',
				'default'   => 'row-boxed',
				'options' => array(
					'row-boxed' => esc_html__( 'Default', 'voxco' ),
					'row-full-boxed' => esc_html__( 'Stretch Header', 'voxco' ),
					'row-full' => esc_html__( 'Stretch Header And Content', 'voxco' ),
				),
			),

			array(
				'name'         => esc_html__( 'Page Header Margin Bottom', 'voxco' ),
				'desc'         => esc_html__( 'Margin Bottom For Page Header (Pixels)', 'voxco' ),
				'id'           => $prefix . 'single_page_header_margin_bottom',
				'default'  => '0',
				'type'         => 'text_medium',
				'attributes' => array(
			        'type' => 'number',
			        'min'  => '0',
			    ),

				
			),

			array(
				'name'    => esc_html__( 'Page Tile', 'voxco' ),
				'id'      => $prefix . 'single_page_title',
				'type'    => 'select',
				'default'   => 'alpha',
				'options' => array(
					'mega' => esc_html__( 'Mega Font', 'voxco' ),
					'alpha' => esc_html__( 'Heading One Font', 'voxco' ),
					'beta' => esc_html__( 'Heading Two Font', 'voxco' ),
					'gamma' => esc_html__( 'Heading Three Font', 'voxco' ),
					'delta' => esc_html__( 'Heading Four Font', 'voxco' ),
					'epsilon' => esc_html__( 'Heading Five Font', 'voxco' ),
					'zeta' => esc_html__( 'Heading Six Font', 'voxco' ),
					'accent' => esc_html__( 'Accent Font', 'voxco' ),
					'none'     => esc_html__( 'No Title', 'voxco' ),
				),
			),
			array(
				'name'         => esc_html__( 'Page Subtitle', 'voxco' ),
				'id'           => $prefix . 'single_page_subtitle',
				'type'         => 'text',
				
			),
			array(
				'name'    => esc_html__( 'Page Subtitle Font', 'voxco' ),
				'id'      => $prefix . 'single_page_subtitle_font',
				'type'    => 'select',
				'default'   => 'zeta',
				'options' => array(
					'mega' => esc_html__( 'Mega Font', 'voxco' ),
					'alpha' => esc_html__( 'Heading One Font', 'voxco' ),
					'beta' => esc_html__( 'Heading Two Font', 'voxco' ),
					'gamma' => esc_html__( 'Heading Three Font', 'voxco' ),
					'delta' => esc_html__( 'Heading Four Font', 'voxco' ),
					'epsilon' => esc_html__( 'Heading Five Font', 'voxco' ),
					'zeta' => esc_html__( 'Heading Six Font', 'voxco' ),
					'accent' => esc_html__( 'Accent Font', 'voxco' ),
				),
			),
			array(
				'name' => esc_html__('Page Tile Color', 'voxco' ),
				'id'   => $prefix . 'single_page_color',
				'type' => 'colorpicker',
				'default'  => '',
			),
			array(
				'name' => esc_html__('Page Subtitle Color', 'voxco' ),
				'id'   => $prefix . 'single_page_subtitle_color',
				'type' => 'colorpicker',
				'default'  => '',
			),
			array(
				'name'    => esc_html__( 'Page Title Alignment', 'voxco' ),
				'id'      => $prefix . 'single_page_align',
				'type'    => 'select',
				'default'   => 'align-left',
				'options' => array(
					'align-left' => esc_html__( 'Left', 'voxco' ),
					'align-right' => esc_html__( 'Right', 'voxco' ),
					'align-center' => esc_html__( 'Center', 'voxco' ),
				),
			),
			array(
				'name'    => esc_html__( 'Page Title Vertical Alignment', 'voxco' ),
				'id'      => $prefix . 'single_page_v_align',
				'type'    => 'select',
				'default'   => 'a-center',
				'options' => array(
					'a-center' => esc_html__( 'Center', 'voxco' ),
					'a-top' => esc_html__( 'Top', 'voxco' ),
					'a-bottom' => esc_html__( 'Bottom', 'voxco' ),
				),
			),
			array(
				'name'         => esc_html__( 'Page Header Background Image', 'voxco' ),
				'desc'         => esc_html__( 'Upload images to be displayed in the page header.', 'voxco' ),
				'id'           => $prefix . 'single_page_header_bg',
				'type'         => 'file',
			),
			array(
				'name' => esc_html__('Page Header Background Color', 'voxco' ),
				'id'   => $prefix . 'single_page_header_color',
				'type' => 'colorpicker',
				'default'  => '#dddddd',
			),

		)
	);

	if($voxco_site_layout == 'layout-side-header'){
		$meta_boxes['sidebar_options_metabox'] = array(
			'id'           => 'sidebar_metabox',
			'title'        => esc_html__( 'Voxco Slider  Options', 'voxco' ),
			'object_types' => array( 'page','post','portfolios' ), // post type
	       // 'show_on'      => array( 'key' => 'page-template', 'value' => 'portfolio-template.php' ),
			'context'      => 'normal',
			'priority'     => 'core',
			'show_names'   => true, // Show field names on the left
			'fields' => array(

				array(
					'name'         => esc_html__( 'Side Header Slider Images', 'voxco' ),
					'desc'         => esc_html__( 'Upload images to be displayed in the project header slider.', 'voxco' ),
					'id'           => $prefix . 'sidebar_slider',
					'type'         => 'file_list',
					'preview_size' => array( 150, 150 ), // Default: array( 50, 50 )
				),

			)
		);
	}
	$meta_boxes['page_options_metabox'] = array(
		'id'           => 'page_metabox',
		'title'        => esc_html__( 'Page  Options', 'voxco' ),
		'object_types' => array( 'page','post','portfolios' ), // post type
		'context'      => 'normal',
		'priority'     => 'core',
		'show_names'   => true, // Show field names on the left
		'fields' => array(

			array(
				'name'    => esc_html__( 'Display Footer', 'voxco' ),
				'id'      => $prefix . 'display_footer',
				'type'    => 'select',
				'default'   => 'footer-off',
				'options' => array(
					'footer-on' => esc_html__( 'Yes', 'voxco' ),
					'footer-off' => esc_html__( 'No', 'voxco' ),
				),
			),

		)
	);
	$meta_boxes['media_options_metabox'] = array(
		'id'           => 'media_metabox',
		'title'        => esc_html__( 'Media Options', 'voxco' ),
		'object_types' => array( 'media_gallery' ), // post type
		'context'      => 'normal',
		'priority'     => 'core',
		'show_names'   => true, // Show field names on the left
		'fields' => array(

			array(
				'name'    => esc_html__( 'Type', 'voxco' ),
				'id'      => $prefix . 'media_type',
				'type'    => 'select',
				'default'   => 'video',
				'options' => array(
					'media-video' => esc_html__( 'Video', 'voxco' ),
					'media-audio' => esc_html__( 'Audio', 'voxco' ),
					'media-image' => esc_html__( 'Image', 'voxco' ),
				),
			),

		)
	);



	if($voxco_menu_layout == 'l3' && $voxco_site_layout == 'layout-side-header'){
		

		$meta_boxes['portfolio_sidebar_content_metabox'] = array(
			'id'           => 'sidebar__content_metabox',
			'title'        => esc_html__( 'Side Header Options', 'voxco' ),
			'object_types' => array( 'portfolios' ), // post type
			'context'      => 'normal',
			'priority'     => 'core',
			'show_names'   => true, // Show field names on the left
			'fields' => array(

				array(
				    'name' => esc_html__('Slide Header Content', 'voxco' ),
				    'desc' => esc_html__( 'Content for menu', 'voxco' ),
				    'id' => $prefix .'slider_content',
				    'type' => 'wysiwyg',
				    'options' => array(
				        'textarea_rows' => get_option('default_post_edit_rows', 5), // rows="..."
				    ),
				),
				array(
				    'name' => esc_html__('Slide Header Content color', 'voxco' ),
				    'desc' => esc_html__( 'Content color for menu layout 3 only ', 'voxco' ),
				    'id'   => $prefix .'slider_content_color',
				    'type' => 'colorpicker',
				    'default'  => '',
				),
				array(
					'name'    => esc_html__( 'Slide Header Content position', 'voxco' ),
					'id'      => $prefix . 'slider_content_position',
					'type'    => 'select',
					'default'   => 'none',
					'options' => array(
						'global'   => esc_html__( 'Theme options default', 'voxco' ),
						'cen-cen'  => esc_html__( 'Center Center', 'voxco' ),
						'cen-left' => esc_html__( 'Center Left', 'voxco' ),
						'btm-left' => esc_html__( 'Bottom Left', 'voxco' ),

					),
				),
				array(
					'name'    => esc_html__( 'Post Navigation Style', 'voxco' ),
					'id'      => $prefix . 'l3_navigation_style',
					'type'    => 'select',
					'default'   => 'single-nav-light',
					'options' => array(
						'single-nav-light' => esc_html__( 'Light', 'voxco' ),
						'single-nav-dark' => esc_html__( 'Dark', 'voxco' ),


					),
				),
			)
		);
		$meta_boxes['sidebar_content_metabox'] = array(
			'id'           => 'sidebar__content_metabox',
			'title'        => esc_html__( 'Side Header Options', 'voxco' ),
			'object_types' => array( 'page','post' ), // post type
			'context'      => 'normal',
			'priority'     => 'core',
			'show_names'   => true, // Show field names on the left
			'fields' => array(

				array(
				    'name' => esc_html__('Side Header Content', 'voxco' ),
				    'desc' => esc_html__( 'Content for menu', 'voxco' ),
				    'id' => $prefix .'slider_content',
				    'type' => 'wysiwyg',
				    'options' => array(
				        'textarea_rows' => get_option('default_post_edit_rows', 5), // rows="..."
				    ),
				),
				array(
				    'name' => esc_html__('Side Header Content color', 'voxco' ),
				    'desc' => esc_html__( 'Content color for menu layout 3 only ', 'voxco' ),
				    'id'   => $prefix .'slider_content_color',
				    'type' => 'colorpicker',
				    'default'  => '',
				),
				array(
					'name'    => esc_html__( 'Side Header Content Position', 'voxco' ),
					'id'      => $prefix . 'slider_content_position',
					'type'    => 'select',
					'default'   => 'none',
					'options' => array(
						'global'   => esc_html__( 'Theme options default', 'voxco' ),
						'cen-cen'  => esc_html__( 'Center Center', 'voxco' ),
						'cen-left' => esc_html__( 'Center Left', 'voxco' ),
						'btm-left' => esc_html__( 'Bottom Left', 'voxco' ),

					),
				),
				
			)
		);
	}



	return $meta_boxes;
}

;


function VoxcoTheme_get_term_options( $taxonomy = 'portfolio_item_category', $args = array() ) {
	
	    $args['taxonomy'] = $taxonomy;
	    // $defaults = array( 'taxonomy' => 'category' );
	    $args = wp_parse_args( $args, array( 'taxonomy' => 'portfolio_item_category' ) );

	    $taxonomy = $args['taxonomy'];

	    $terms = (array) get_terms( $taxonomy, $args );

	    // Initate an empty array
	    $term_options = array();
	    if ( ! empty( $terms ) ) {
	        foreach ( $terms as $term ) {
	        	 $term_options[ $term->term_id ] = $term->name;
	        }
	    }

	    return $term_options;
	
}





