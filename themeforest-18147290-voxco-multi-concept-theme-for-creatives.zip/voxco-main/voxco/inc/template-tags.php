<?php




if ( !function_exists( 'cmb2_output_file_list' ) ) {
	function cmb2_output_file_list( $file_list_meta_key, $img_size = 'medium' ) {

	    $files = get_post_meta( get_the_ID(), $file_list_meta_key, 1 );

	    foreach ( (array) $files as $attachment_id => $attachment_url ) {
	        echo wp_get_attachment_image( $attachment_id, $img_size );
	    }

	}
}


if ( !function_exists( 'voxco_filters' ) ) {
	function voxco_filters() {
		$Voxco_taxonomy_exist = taxonomy_exists('portfolio_item_category');
		if($Voxco_taxonomy_exist){
					global $VoxcoTheme_Options;  
					$voxco_menu_layout = $VoxcoTheme_Options['voxco_options_menu_style'];
					echo '<ul class="portfolio-nav">';
					
					echo '<li class="filter checked" data-filter="all">' . esc_html__( 'All', 'voxco' ) . '</li>';

						$VoxcoTheme_portfolio_cats = get_post_meta( get_the_ID(), '_cmb_portfolio_categories',true );
						$cat_slugs= array();
				
						if(!$VoxcoTheme_portfolio_cats){
							$VoxcoTheme_portfolio_cats = get_categories(array('taxonomy' => 'portfolio_item_category'));
							foreach ($VoxcoTheme_portfolio_cats as $cat) {

								echo '<li class="filter" data-filter="'.preg_replace('/\s+/', '', $cat->slug).'">'. $cat->name . '</li>';
							}
							
						}
						else{
							foreach ($VoxcoTheme_portfolio_cats as $cat) {
								$cat_object = get_term_by( 'id', absint( $cat ), 'portfolio_item_category' );
								$cat_name = $cat_object->name;
								$cat_slug = $cat_object->slug;
								echo '<li class="filter" data-filter="'.preg_replace('/\s+/', '', $cat_slug).'">'. $cat_name. '</li>';
								$cat_slugs[] = $cat_slug;
							}
						}
						$cat_slugs_list = join( " ,", $cat_slugs );

					echo '</ul>';

		}	
	}	
}

if ( !function_exists( 'voxco_portfolio_nav' ) ) {
	function voxco_portfolio_nav() {
		global $post;
		echo '<div class="portfolio-single-nav-min">';
		$next_post = get_adjacent_post(false,'',true);
		$prev_post = get_adjacent_post(false,'',false);
		
		if($prev_post){
			echo '<a href="'.get_the_permalink($prev_post).'"><i class="fa fa-angle-left"></i></a>';
		}
 		?>
		
		<div class="share-wrap">
			<div class="share">
				<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink($post->ID); ?>"  target="_blank"><i class="fa fa-facebook"></i></a>
			    <a href="https://plus.google.com/share?url=<?php echo get_permalink($post->ID); ?>" target="_blank"><i class="fa fa-google-plus"></i></a>
			    <a href="https://twitter.com/home?status=<?php echo get_permalink($post->ID); ?>" target="_blank"><i class="fa fa-twitter"></i></a>
			    <?php 
			    $image_id = get_post_thumbnail_id($post->ID);
			    $image_url = wp_get_attachment_image_src($image_id);
			    ?>
			    <a href="https://pinterest.com/pin/create/button/?url=<?php echo get_permalink($post->ID); ?>&media=<?php echo esc_url($image_url[0]); ?>&description=" target="_blank"><i class="fa fa-pinterest"></i></a>
		   		</div>
	   		<span><i class="fa fa-share-alt"></i></span>
	    </div>


	    <?php 
	   	if($next_post){
			echo '<a href="'.get_the_permalink($next_post).'"><i class="fa fa-angle-right"></i></a>';
		}
		echo "</div>";	
	}	
}		


if ( ! function_exists( '_s_comment' ) ) :

function _s_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
	?>
	<li class="post pingback">
		<p><?php esc_html_e( 'Pingback:', 'voxco' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( esc_html__( '(Edit)', 'voxco' ), ' ' ); ?></p>
	<?php
			break;
		default :
	?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<article id="comment-<?php comment_ID(); ?>" class="comment">
       
        	<div class="row">
            	
            	<div class="c12 end">
                	<span class="comment-avartar"> <?php echo get_avatar( $comment, 54); ?></span>
                
            	
            		<div class="comment-holder">
	                	<div class="comment-header">
	                	<?php printf( sprintf( '<h6>%s</h6>', get_comment_author_link() ) ); ?>
						<time datetime="<?php comment_time( 'c' ); ?>">
						<?php
							/* translators: 1: date, 2: time */
							printf( esc_html__( '%1$s at %2$s - ', 'voxco' ), get_comment_date(), get_comment_time() ); ?>
						</time>
						<?php edit_comment_link( esc_html__( '(Edit)', 'voxco' ), ' ' ); ?>
	                 
	                    </div>
						<div class="comment-text"><?php comment_text(); ?></div>
						   <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
	                		<?php if ( $comment->comment_approved == '0' ) : ?>
								<br/><em><?php esc_html_e( 'Your comment is awaiting moderation.', 'voxco' ); ?></em>
							<?php endif; ?>
	                	</div>

	                </div>	

            </div>

       
		</article>

	<?php
			break;
	endswitch;
}
endif; 




function _s_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'all_the_cool_cats' ) ) ) {
		$all_the_cool_cats = get_categories( array(
			'hide_empty' => 1,
		) );
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'all_the_cool_cats', $all_the_cool_cats );
	}

	if ( '1' != $all_the_cool_cats ) {
		return true;
	} else {
		return false;
	}
}

function _s_category_transient_flusher() {

	delete_transient( 'all_the_cool_cats' );
}
add_action( 'edit_category', '_s_category_transient_flusher' );
add_action( 'save_post', '_s_category_transient_flusher' );