/* 
*	Custom jQuery.
*	Other script located in the Voxco Framework Plugin. 
*	voxco-framework/js/voxco-framework-script.js 
*/
	
jQuery(document).ready(function($) {
"use strict";  




	$('body').bind('touchstart', function() {});

	if($('.footer').length){
		$('.content').css('padding-bottom', '0px');
	}

	$(".wpb_column").each(function(){
		
		if ($(this).find('.googlemap').length){
			$(this).addClass('has-gmap');
		}
		if($(this).find('.vc_inner').length ){
			$(this).addClass('has-inner');
		}
		if ($(this).find('.rev_slider_wrapper').length){
			$(this).addClass('has-rev');
		}
		if ($(this).find('.voxco-slider').length){
			$(this).addClass('has-gmap');
		}
		
		
		
	});

	$('.has-inner [data-col-height]').each(function(){
		var dataHeight = $(this).attr('data-col-height');
		$(this).find('.wpb_column').addClass(dataHeight);

	});

	$('.auto .wpb_column').addClass('auto');
	$("div[class^='vc_col-sm'],div[class*=' vc_col-sm']").not("div[class^='vc_col-xs'],div[class*=' vc_col-xs'], div[class^='vc_col-md'], div[class*=' vc_col-md'], div[class^='vc_col-lg'], div[class*=' vc_col-lg'] ").addClass('col-std');
	if($('body').hasClass('voxco-menu-on-top-of-content') && $('body').hasClass('layout-standard-header')){
		$('.post-header:not(.has-rev)').css('padding-top', $('.mainnav').height());
	}
	var navigationHeight = $('.mainnav').height();
	function boxedHeaderOffset(){
		var offsetTop = parseInt($('.content').attr('data-offset-top'));
		if(Modernizr.mq('only screen and (max-width: 768px)')){
			var offsetTop = parseInt($('.content').attr('data-mobile-offset-top'));
		}
		if($('body').hasClass('voxco-menu-above-content')){
			$('.content').css('padding-top', navigationHeight + offsetTop +'px');
		}
	}
	function columnHeight(){
		$('.wpb_column:not(.has-inner)').each(function(){
	    	var column = $(this),
	    		colWidth = $(this).outerWidth(),
	    		colHeight,
				container = $(this).find('.vocxo-content-wrapper'),
				content = container.children();

			if($('body').hasClass('layout-standard-header')){
				var mobile = Modernizr.mq('only screen and (max-width: 768px)'),
		    		desktop = Modernizr.mq('only screen and (min-width: 768px)');
			}
			else{
				var mobile = Modernizr.mq('only screen and (max-width: 1024px)'),
		    		desktop = Modernizr.mq('only screen and (min-width: 1024px)');
			}
			
			function screenHeight(){
				var parentPadding = parseInt(column.parent().css("padding-top")),
					borderWidth = $('.border-top').height() * 2,
					adminBarHeight = $('#wpadminbar').height(),
					headerOffset;
				if(column.hasClass('post-header')){
					headerOffset = parseInt(column.attr('data-header-offset'));
				}
				else{
					headerOffset = 0;
				}
				colHeight = $(window).height() - (adminBarHeight + borderWidth + parentPadding) - headerOffset;
			}

			if(column.hasClass('mh4') && mobile){
				colHeight = colWidth / 4;
			}
			else if(column.hasClass('mh2') && mobile){
				colHeight = colWidth / 2;
			}
			else if(column.hasClass('mh3') && mobile){
				colHeight = colWidth / 3;
			}
			else if($(this).hasClass('mh6') && mobile){
				colHeight = colWidth / 3 * 2;
			}
			else if(column.hasClass('mh12') && mobile){
				colHeight = colWidth / 3 * 4;
			}
			else if(column.hasClass('mh11') && mobile){
				colHeight = colWidth * 2;
			}
			else if(column.hasClass('mh1') && mobile){
				colHeight = colWidth;
			}
			else if(column.hasClass('mhauto') && mobile){
				colHeight = 1;
			}
			else if(column.hasClass('mhs') && mobile){
				screenHeight();
			}
			else if(column.hasClass('h4') ){
				colHeight = colWidth / 4;
			}
			else if(column.hasClass('h2')){
				colHeight = colWidth / 2;
			}
			else if(column.hasClass('h3')){
				colHeight = colWidth / 3;
			}
			else if(column.hasClass('h6')){
				colHeight = colWidth / 3 * 2;
			}
			else if(column.hasClass('h12')){
				colHeight = colWidth / 3 * 4;
			}
			else if(column.hasClass('h11')){
				colHeight = colWidth * 2;
			}
			else if(column.hasClass('h1')){
				colHeight = colWidth;
			}
			else if(column.hasClass('hs')){
				screenHeight();
			}
			else if(column.hasClass('auto') && desktop){
				colHeight = 1;
			}
			
			column.find('.wpb_wrapper .googlemap.full-height').not('.wpb_wrapper[data-col-height="auto"] .googlemap.full-height').css({'height' : colHeight });
			
			if(column.hasClass('post-header') && !column.hasClass('auto')){
				column.css({'height' : Math.round(colHeight) });
			}
			else{
				column.find('.vc_column-inner').css({
					'min-height' : Math.round(colHeight),
				});
			}
		});
	}

   
	function iePosition(){
		var ua = window.navigator.userAgent,
	    	msie = ua.indexOf("MSIE ");
	 	if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
	       $('body').addClass('ie');
	       $('.vc_row.vc_row-o-content-middle:not(.vc_row-o-equal-height) > .vc_column_container > .vc_column-inner').each(function(){
	      		var iePosition = $(this).height() / 2;
	       		$(this).children('.voxco-content-element').css('top', iePosition);
	       		$(this).children('.wpb_wrapper').css('top', iePosition);
	       });
	       $('.vc_row.vc_row-o-content-bottom:not(.vc_row-o-equal-height) > .vc_column_container > .vc_column-inner').each(function(){
	      		var iePosition = $(this).height();
	       		$(this).children('.voxco-content-element').css('top', iePosition);
	       		$(this).children('.wpb_wrapper').css('top', iePosition);
	       });
		}
	}

	$('.layout-side-header .vc_row[data-vc-stretch-content|=true]').removeAttr('data-vc-stretch-content');
	if(!$('.content').find('.vc_row').length ){
		$('.content').children().not('.post-header, .portfolioinner, #masonry-container, article, .row, .aside-trigger, .load-more, .portfolio-nav, .row-default').wrapAll("<div class='row-default'></div>");
	}
	function rowFull(){
		$('.layout-standard-header .row-full-boxed, .layout-standard-header .row-full, .footer-full .footer-wrap').each(function() {
	    	$(this).css('width', $(window).width() - ($('.border-left').width() * 2) );
		});

	}
	rowFull();

	$('.wpcf7-form-control').focus(function(){
		$(this).parent().addClass('is-focus');
	});
	$('.wpcf7-form-control').blur(function(){
		$(this).parent().removeClass('is-focus');
	});
	if($('.post-prev span').siblings().length < 1 ){$('.post-prev span').hide()}
	if($('.post-next span').siblings().length < 1 ){$('.post-next span').hide()}	
	if($('body').hasClass('home')){
		$('.nav-top-logo a, .footer-logo').click(function(event){
			 event.preventDefault();
			$('html, body').animate({scrollTop: 0}, 800);
		});
	}	 
/*-----------------------------------------------------------------------------------*/
/* Message Box
/*===================================================================================*/
	
	$('.message-box-close-message').click(function(){
		var msgBox = $(this).parent();
		msgBox.fadeOut( 200, function() {
		    msgBox.remove();
		});
	});


/*-----------------------------------------------------------------------------------*/
/* Navigation
/*===================================================================================*/



	function navMinWidth(){

		if (Modernizr.mq('only screen and (max-width: 768px)')) {
			$('.l1 .aside-trigger, .l3 .aside-trigger').prependTo('.header-panel');
			$('.l2 .aside-trigger').prependTo('#primary-header');
			$('.layout-standard-header.menu-boxed .mainnav').css('margin-left', '0px');
		}
		else{
			$('.l1 .aside-trigger, .l2 .aside-trigger, .l3 .aside-trigger').insertAfter('.content');
			$('.layout-standard-header.menu-boxed .mainnav').css('margin-left', '-' + $('.mainnav').width() / 2 + 'px');
		}

		if($('body').hasClass('l4') && $('.nav-trigger').css('position') == 'fixed'){
			$('.l4 .nav-trigger').css({
				'right': $('.nav-top-logo').offset().left,
				'top' : ($('.mainnav').height() / 2) + parseInt($('.border-top').css('height')) + $('#wpadminbar').height(),
			});
			$('.l4 .filter-btn, .l4 .aside-trigger').css({
				'position' : 'fixed',
				'right': $('.nav-top-logo').offset().left + 52,
				'top' : ($('.mainnav').height() / 2)  + parseInt($('.border-top').css('height')) + $('#wpadminbar').height() ,
			});

		}
	}
	navMinWidth();



	/*Sticky Navigation*/
	function stickyNav(){

		var	mainNav = $(".mainnav"),
			aboveHeight, navPosition;

		

		if($('body').hasClass('layout-standard-header') && mainNav.css('position') == 'fixed'){
			var scrollHeight = mainNav.outerHeight() / 2;
			if ($(window).scrollTop() > scrollHeight){
				mainNav.addClass('scrolled');	
			}
			else if($(window).scrollTop() < scrollHeight ) {
				mainNav.removeClass('scrolled');	
			}

		}
		else{
			mainNav.removeClass('scrolled');
		}
		if($('body').hasClass('l5') && Modernizr.mq('only screen and (min-width: 768px)') ){
			mainNav.removeAttr('style')
		}
			
		if(mainNav.hasClass('nav-has-offset')){
			if(Modernizr.mq('only screen and (max-width: 768px)')){
				aboveHeight  = parseInt($('.mainnav').attr('data-mobile-nav-offset'));
			}
			else{
				aboveHeight  = parseInt($('.mainnav').attr('data-nav-offset'));
			}
			navPosition = parseInt($('.border-top').css('height')) + parseInt($('#wpadminbar').css('height'));
			mainNav.css({
				'position':'fixed',
				'top' : navPosition
			});
			
			if ($(window).scrollTop() > aboveHeight){
				mainNav.css({
					'position':'fixed',
					'top' : navPosition
				});
			}
			else if($(window).scrollTop() < aboveHeight) {
				mainNav.css({
					'position':'absolute',
					'top' : navPosition + aboveHeight
				});
			}
		}

		else if(mainNav.hasClass('nav-trigger-has-offset') && $('body').hasClass('l4')){
			if(Modernizr.mq('only screen and (max-width: 768px)')){
				aboveHeight  = parseInt($('.mainnav').attr('data-mobile-nav-offset'));
			}
			else{
				aboveHeight  = parseInt($('.mainnav').attr('data-nav-offset'));
			}
			if ($(window).scrollTop() > aboveHeight){
				$('.nav-trigger, .filter-btn, .aside-trigger').css({
					'position' : 'fixed',
					'top' : ($('.mainnav').height() / 2) + parseInt($('.border-top').css('height')) + parseInt($('#wpadminbar').css('height')),
				});
				$('.l4 .nav-trigger').css('right', $('.nav-top-logo').offset().left );
				$('.l4 .filter-btn, .l4 .aside-trigger').css('right', $('.nav-top-logo').offset().left + 52);

			}
			else if($(window).scrollTop() < aboveHeight) {
				$('.nav-trigger').css({
					'position' :'relative',
					'top' : '50%',
					'right' : '0',
				});
				$('.filter-btn, .aside-trigger').css({
					'position' :'relative',
					'top' : '50%',
					'right' : '8px',
				});
			}
		}

		else if($('body').hasClass('layout-side-header') ){
			mainNav = $('.l2 #primary-header, .header-panel');
			aboveHeight  = parseInt($('.header-inner').attr('data-mobile-nav-offset'));
			navPosition = parseInt($('.border-top').css('height')) + parseInt($('#wpadminbar').css('height'));
			if(Modernizr.mq('only screen and (max-width: 768px)')){
				if ($(window).scrollTop() > aboveHeight){
					mainNav.css({
						'position':'fixed',
						'top' : navPosition
					});
				}
				else if($(window).scrollTop() < aboveHeight) {
					mainNav.css({
						'position':'absolute',
						'top' : navPosition + aboveHeight
					});

				}
			}
			else{
				mainNav.removeAttr('style');
			}
		}
	}
	stickyNav();
	



	/*Off Canvas Navigation*/

	$('.layout-standard-header .nav-top-inner .social-networks').appendTo('.layout-standard-header .nav-top-inner > div:last-child > ul').wrapAll('<li class="social-networks">');
	$('.nav-trigger').click(function(){
		
		var button = $(this),
			nav = $('.mainnav'),
			navPos;
		if($('body').hasClass('l2')){
			nav = $('.l2 #primary-header');
		}
		if($('body').hasClass('l4')){
			nav = $('.nav-top-inner > div:last-child');
		}
		if($('body').hasClass('l5')){
			nav = $('.nav-top-inner > div:last-child > ul');
		}
		if(button.hasClass('animating')){
			return false;
		}
		else if(button.hasClass('is-active')){
			button.addClass('animating').removeClass('is-active');
			$('.l1 .header-logo img, .cen-cen .menu-content, .portfolio-single-nav-min').velocity({ scale: "1", opacity: "1" }, { visibility: "visible", duration: 200 });
			$('.cen-left .menu-content, .btm-left .menu-content').velocity({  scale: "1", translateX: "-0%", opacity: "1" }, { visibility: "visible", duration: 200 });
			$('#side-bar').velocity({ opacity: "0" }, { display: "none", duration: 200  });
			$('#side-bar').velocity("transition.fadeOut", { duration: 100 });
			if($('body').hasClass('l4')){
				nav.velocity({ opacity: "0" }, { display: "none", duration: 300  });
				$('ul.menu > li, .menu > ul > li').velocity({ opacity: "0" }, { complete: function() { button.removeClass('animating'); } }); 
			}
			else if($('body').hasClass('l2')){
				$('.l2 .nav-inner nav').velocity({ height: "0px" });
				nav.velocity({ height: "66px", }, { complete: function() { button.removeClass('animating'); } });
			}
			else if($('body').hasClass('l5')){
				
				nav.velocity({ maxHeight: "0px", }, { complete: function() { 
					button.removeClass('animating');
					$('.mainnav').removeAttr('style'); 
				} });
			}
			else{
				nav.velocity({ 
				 	top: "50px",
				  	right: "50px",
				  	bottom: "50px",
				  	left: "50px",
				}, { complete: function() { 
						$(".scrollContainer").mCustomScrollbar("disable");
						button.removeClass('animating');
					} 
				});
			}
		}
		else{
			button.addClass('is-active animating');
			$('.l1 .header-logo img, .cen-cen .menu-content, .portfolio-single-nav-min').velocity({ scale: "0.9", opacity: "0" }, { visibility: "hidden", duration: 200 });
			$('.cen-left .menu-content, .btm-left .menu-content').velocity({ scale: "0.9", translateX: "-2.5%", opacity: "0" }, { visibility: "visible", duration: 200 });
			$('#side-bar').velocity({ opacity: "1" }, { display: "block", duration: 200 });
			$('#side-bar nav, .filterBox .portfolio-nav').velocity("transition.fadeIn", { duration: 200 });
			if (Modernizr.mq('only screen and (max-width: 768px)')) { 
				navPos = "0px"; 
			}
			else{ 
				navPos = "10px"; 
			}
			if($('body').hasClass('l4')){
				nav.velocity({ opacity: "1" }, { display: "block", duration: 300  });
				$('ul.menu > li, .menu > ul > li').velocity("transition.slideDownBigIn", { stagger: 50, duration: 400, complete: function() { button.removeClass('animating'); } });
			}
			else if($('body').hasClass('l2')){
				$('.l2 .nav-inner nav').velocity({ height: "254" });
				nav.velocity({ height: "320px", }, { complete: function() { button.removeClass('animating'); } });
			}
			else if($('body').hasClass('l5')){
				if($('.mainnav').height() > '80'){
					$('.mainnav').css('height', '80px');
				}
				nav.velocity({  maxHeight: "236" }, { complete: function() { button.removeClass('animating'); } });
			}
			else{
				nav.velocity({ 
				 	top: navPos,
				  	right: navPos,
				  	bottom: navPos,
				  	left: navPos,
				}, { complete: function() {
						$(".scrollContainer").mCustomScrollbar("update");
						button.removeClass('animating');
					} 
				});
			}
		}
	});
	

	$('.l1 .menu-item-has-children ul, .l3 .menu-item-has-children ul').before('<span class="toggle-menu"></span>');
	$('.l1 .sub-menu li, .l1 .menu .children li, .l3 .sub-menu li, .l3 .menu .children li').slideUp();
	$('.toggle-menu').click(function(){
		$(this).next().children().velocity($(this).next().children().is(':visible') ? 'slideUp' : 'slideDown', { duration:150 });
		$(this).toggleClass('toggle-menu-open');
		$(this).next().toggleClass('menu-open');
	});


	
	

	
/*-----------------------------------------------------------------------------------*/
/* Portfolio
/*===================================================================================*/

	
	function masonryPortfolio(){
		$('.portfolioinner').each(function(){
			var id = $(this).attr('data-portfolio-count'),
				portfolio = $('.portfolioinner:not(.portfolio-shortcode)'),
				filter = $('.portfolio-nav:not(.portfolio-shortcode) .filter');
			
			if($(this).attr('data-portfolio-count')){
				portfolio = $('.portfolioinner[data-portfolio-count="'+ id +'"]');
				filter = $('.portfolio-nav[data-portfolio-count="'+ id +'"] .filter');
			}
			portfolio.css('opacity','1').isotope({
				layoutMode: 'packery',
				itemSelector: '.item',
			});
			filter.on( 'click', function() {
			  	$(this).addClass('checked').siblings().removeClass('checked');
			  	var filterValue = '.' + $(this).attr('data-filter');
			  	portfolio.isotope({ filter: filterValue + ', .portfolio-filters' });
			});
		});
	}
		
	$('.filter-btn').click(function(){
		var filterBtn = $(this);
		if(filterBtn.hasClass('animating')){
			return false;
		}
		else if(filterBtn.hasClass('is-active')){
			filterBtn.addClass('animating').removeClass('is-active');
			$('.filter-menu').velocity({ opacity: "0" }, { display: "none", duration: 300  });
			$('.filter-menu .portfolio-nav li').velocity({ opacity: "0" }, {
				complete: function() { filterBtn.removeClass('animating'); }
			});
		}
		else{
			filterBtn.addClass('is-active animating');
			$('.filter-menu').velocity({ opacity: "1"}, { display: "block", duration: 300  });
			$('.filter-menu .portfolio-nav li').velocity("transition.slideDownBigIn", { 
				stagger: 50,
				duration: 400, 
				complete: function() { filterBtn.removeClass('animating'); }
			});
		}
	});
	
	$('.l1 .filter-side-menu').insertAfter('.mainnav nav > div');
	$('.l2 .filter-side-menu').insertAfter('.nav-inner nav > div');
	$('.l3 .filter-side-menu').appendTo('.menu-content');
	$('.l5 .aside-trigger, .l5 .filter-btn, .l5 .filter-menu').prependTo('.nav-top-inner');
	$('.l4 .aside-trigger, .l4 .filter-btn, .l4 .filter-menu').insertAfter('.nav-trigger');
	$('.filter-menu').slice(1).children().appendTo($('.filter-menu:first'));
	$('.filter-menu').slice(1).remove();
	$('.filter-btn').slice(1).remove();
	$('.portfolioinner li').each(function(){
		if($(this).find('img').length < 1){
			$(this).addClass('no-thumbnail');
		}
	});
	
	$.fn.visible = function(partial){
		var $t        = $(this),
		$w        = $(window),
		viewTop     = $w.scrollTop(),
		viewBottom    = viewTop + $w.height(),
		_top      = $t.offset().top,
		_bottom     = _top + $t.height(),
		compareTop    = partial === true ? _bottom : _top,
		compareBottom = partial === true ? _top : _bottom;
		return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
	};
	function showFilterButton(){
		if($('body').hasClass('layout-standard-header') && $('.portfolioinner').length ){
			$('.portfolioinner').each(function(){
				var portfolio = $(this);
				if( portfolio.visible(true) ) {
			    	$('.filter-btn').show();
			    	return false;
				}
				else{ 
					$('.filter-btn').hide(); 
				}
			});
		}
	};


	

/*-----------------------------------------------------------------------------------*/
/* Blog
/*===================================================================================*/

	function masonryBlog(){	
		$('#masonry-container').isotope({
			layoutMode: 'packery',
			itemSelector: '.masonry-item',
		});
	}

	$('.aside-trigger').click(function(){
		$('.aside-offcanvas').velocity({translateX: [ '0%', '100%' ] }, 'easeInCirc', 300);
		$('.aside-overlay').velocity('fadeIn', { duration: 400 })
 	});
 	$('.aside-close, .aside-overlay').click(function(){
		$('.aside-offcanvas').velocity({ translateX: '100%' }, 'easeOutSine', 300);
		$('.aside-overlay').velocity('fadeOut', { duration: 300 });
 	});
 	 

/*-----------------------------------------------------------------------------------*/
/* Lazy Load
/*===================================================================================*/

	var running = true;
	$('.load-more').on('click', 'a' ,function(e)  {

		e.preventDefault();
		if (running) { 
			var link = $(this).attr('href');
			$('.load-more').addClass('spin');
			$.get(link, function( data ) {
				var $response=$(data),
				 	portfolioContent = $response.find('.portfolioinner:not(.portfolio-shortcode)').children().filter('li:not(.portfolio-filters)'),
				 	nextLink = $response.find('.load-more a'),
				 	blogContent = $response.find('#masonry-container').children().filter('article');
				 	$('.load-more a').replaceWith(nextLink);
					running = true;
					$('.load-more').removeClass('spin');
				portfolioContent.each(function(){
					var elem = $(this);
					elem.imagesLoaded(function() {
						$('.portfolioinner:not(.portfolio-shortcode)').append(elem).isotope( 'appended', elem);
					});
				});
				blogContent.each(function(){
					var elem = $(this);
					elem.imagesLoaded(function() {
						$('#masonry-container').append(elem).isotope( 'appended', elem);
			
					});
				});

			});
		}		
		running = false;
	});




  	var waitForHeight = (function () {
        var timers = {};
        return function (callback, ms, uniqueId) {
            if (!uniqueId) {
        	    uniqueId = "sizeColumns";
            }
            if (timers[uniqueId]) {
            	clearTimeout (timers[uniqueId]);
            }
            timers[uniqueId] = setTimeout(callback, ms);
        };
	})();
	if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ){
	    var voxcoSkrollr = skrollr.init({
				smoothScrollingDuration:10,
				forceHeight:false
			});
	}	  

	columnHeight();
	iePosition();

	
	$(window).resize(function() {


		
		waitForHeight(function(){
		    columnHeight();
		    iePosition();
		    if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ){
		    	voxcoSkrollr.refresh();
			}

		}, 15, "sizeColumns");	 
		if($(window).width() > 786){
				$('.l2 #primary-header , .l2 .nav-inner nav, .l5.layout-standard-header .nav-top-inner > div:last-child > ul').removeAttr('style');
				$('.l2 .nav-trigger, .l5 .nav-trigger').removeClass('is-active')
		}
		
		rowFull();
		navMinWidth();
		boxedHeaderOffset();
		stickyNav();

	
	});
	$(window).scroll(function(){
		stickyNav();
		showFilterButton(); 
		

		if($('body').hasClass('page-template-portfolio-template') && $(document).height() <= $(window).scrollTop() + $(window).height()){
			$('.load-more a').trigger('click');
		}
		else if($('#masonry-container').length && $('#masonry-container').height() <= $(window).scrollTop() + $(window).height()){
			$('.load-more a').trigger('click');
		}

	});


	$(window).on({
		load : function() {
			columnHeight();
			iePosition();
	        masonryPortfolio();
	        masonryBlog();
	   		showFilterButton();

	   		if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ){
		        voxcoSkrollr.refresh($('.vc_parallax-inner'));
	    	}
	        if(($('.aside-offcanvas').outerHeight() -  $('.footer').outerHeight(true) - $('.border-top').height()) > $('.content').outerHeight()){
		 		$('.content').css('min-height',  $('.aside-offcanvas').outerHeight() - $('.footer').outerHeight(true) );
		 	}
	        $(".scrollContainer").mCustomScrollbar();
			$(".scrollContainer").mCustomScrollbar('disable');
	       	$('html, body, .js-loader').addClass('loaded')
	       	$('.js-loader').fadeOut(600);
	       	clearTimeout(loadFailed);
	      	if($('#loader').length){
				$('.plink[target!="_blank"], .prev-next-wrap a, .mainnav a[target!="_blank"], .footer-logo, a.recent-post-img, .readmore, .entry-summary h2 a, .widget a, .post-nav a').not('.home .nav-top-logo a, .home .footer-logo').click(function(e){
		       		var redirect = $(this).attr('href');
		       		if(redirect.indexOf("#") == -1){
		       			e.preventDefault();
			            $('body').fadeOut(300, function(){
			               document.location.href = redirect
			            });	
		       		}
		      	});
	      	}
	      	
		
		}
	});
	window.onpageshow = function(event) {
	    if (event.persisted) {
	        window.location.reload();
	    }
	};
 	var loadFailed = setTimeout(function() {
	    $('.js-loader').addClass('loaded').fadeOut(600);
	}, 15000);


});










