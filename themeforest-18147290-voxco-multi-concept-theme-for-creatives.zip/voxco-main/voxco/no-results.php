<?php global $VoxcoTheme_Options; ?>
<?php $VoxcoTheme_sidebar_archive = $VoxcoTheme_Options['voxco_options_sidebar_arch']; 
	
if ($VoxcoTheme_sidebar_archive == 'aside-standard'){
	$VoxcoTheme_content = 'c9';
}
else{
	$VoxcoTheme_content = 'c12';
} ?>

<article class="no-results row">
	<div class="<?php echo esc_attr($VoxcoTheme_content); ?>">
		<?php if ( is_home() && current_user_can( 'publish_posts' ) ) { ?>
			<p><?php printf( wp_kses( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'voxco' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>
		<?php } elseif ( is_search() ) { ?>
			<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'voxco' ); ?></p>
			<?php get_search_form(); ?>
		<?php } else { ?>
			<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'voxco' ); ?></p>
			<?php get_search_form(); ?>
		<?php } ?>
	</div>
	<?php 
	if ($VoxcoTheme_sidebar_archive == 'aside-standard'){ ?>
		<div class="c3"> <?php get_sidebar(); ?> </div>
	<?php } 
	else if($VoxcoTheme_sidebar_archive == 'aside-offcanvas'){ ?>
		<div class="aside-offcanvas">
			<span class="aside-close"></span>
			<?php get_sidebar(); ?>
		</div>
		<div class="aside-overlay"></div>
	<?php } ?>

</article>
	

	

