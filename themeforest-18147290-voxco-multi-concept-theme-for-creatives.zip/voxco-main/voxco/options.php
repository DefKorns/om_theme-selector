<?php
    /**
     * ReduxFramework Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */



    if ( ! class_exists( 'Redux_Framework_sample_config' ) ) {

        class Redux_Framework_sample_config {

            public $args = array();
            public $sections = array();
            public $theme;
            public $ReduxFramework;

            public function __construct() {

                if ( ! class_exists( 'ReduxFramework' ) ) {
                    return;
                }

                // This is needed. Bah WordPress bugs.  ;)
                if ( true == Redux_Helpers::isTheme( __FILE__ ) ) {
                    $this->initSettings();
                } else {
                    add_action( 'plugins_loaded', array( $this, 'initSettings' ), 10 );
                }

            }

            public function initSettings() {

                // Just for demo purposes. Not needed per say.
                $this->theme = wp_get_theme();

                // Set the default arguments
                $this->setArguments();

                // Set a few help tabs so you can see how it's done
                $this->setHelpTabs();

                // Create the sections and fields
                $this->setSections();

                if ( ! isset( $this->args['opt_name'] ) ) { // No errors please
                    return;
                }

                // If Redux is running as a plugin, this will remove the demo notice and links
                //add_action( 'redux/loaded', array( $this, 'remove_demo' ) );

                // Function to test the compiler hook and demo CSS output.
                // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
                //add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 3);

                // Change the arguments after they've been declared, but before the panel is created
                //add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );

                // Change the default value of a field after it's been set, but before it's been useds
                //add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );

                // Dynamically add a section. Can be also used to modify sections/fields
                //add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

                $this->ReduxFramework = new ReduxFramework( $this->sections, $this->args );
            }

            /**
             * This is a test function that will let you see when the compiler hook occurs.
             * It only runs if a field    set with compiler=>true is changed.
             * */
            function compiler_action( $options, $css, $changed_values ) {
                echo '<h1>The compiler hook has run!</h1>';
                echo "<pre>";
                print_r( $changed_values ); // Values that have changed since the last save
                echo "</pre>";
                //print_r($options); //Option values
                //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )

            /*
              // Demo of how to use the dynamic CSS and write your own static CSS file
              $filename = dirname(__FILE__) . '/style' . '.css';
              global $wp_filesystem;
              if( empty( $wp_filesystem ) ) {
                require_once( ABSPATH .'/wp-admin/includes/file.php' );
              WP_Filesystem();
              }

              if( $wp_filesystem ) {
                $wp_filesystem->put_contents(
                    $filename,
                    $css,
                    FS_CHMOD_FILE // predefined mode settings for WP files
                );
              }
             */
            }

            /**
             * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
             * Simply include this function in the child themes functions.php file.
             * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
             * so you must use get_template_directory_uri() if you want to use any of the built in icons
             * */
            function dynamic_section( $sections ) {
                //$sections = array();
                $sections[] = array(
                    'title'  => esc_html__( 'Section via hook', 'voxco' ),
                    'desc'   => esc_html__( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'voxco' ),
                    'icon'   => 'el-icon-paper-clip',
                    // Leave this as a blank section, no options just some intro text set above.
                    'fields' => array()
                );

                return $sections;
            }

            /**
             * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
             * */
            function change_arguments( $args ) {
                $args['dev_mode'] = false;

                return $args;
            }

            /**
             * Filter hook for filtering the default value of any given field. Very useful in development mode.
             * */
            function change_defaults( $defaults ) {
                $defaults['str_replace'] = 'Testing filter hook!';

                return $defaults;
            }

            // Remove the demo link and the notice of integrated demo from the redux-framework plugin
            function remove_demo() {

                // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
                if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                    remove_filter( 'plugin_row_meta', array(
                        ReduxFrameworkPlugin::instance(),
                        'plugin_metalinks'
                    ), null, 2 );

                    // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                    remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
                }
            }


            public function setSections() {

                

                ob_start();

                $ct          = wp_get_theme();
                $this->theme = $ct;
                $item_name   = $this->theme->get( 'Name' );
                $tags        = $this->theme->Tags;
                $screenshot  = $this->theme->get_screenshot();
                $class       = $screenshot ? 'has-screenshot' : '';

                $customize_title = sprintf( __( 'Customize &#8220;%s&#8221;', 'voxco' ), $this->theme->display( 'Name' ) );

                ?>
                <div id="current-theme" class="<?php echo esc_attr( $class ); ?>">
                    <?php if ( $screenshot ) : ?>
                        <?php if ( current_user_can( 'edit_theme_options' ) ) : ?>
                            <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize"
                               title="<?php echo esc_attr( $customize_title ); ?>">
                                <img src="<?php echo esc_url( $screenshot ); ?>"
                                     alt="<?php esc_attr_e( 'Current theme preview', 'voxco' ); ?>"/>
                            </a>
                        <?php endif; ?>
                        <img class="hide-if-customize" src="<?php echo esc_url( $screenshot ); ?>"
                             alt="<?php esc_attr_e( 'Current theme preview', 'voxco' ); ?>"/>
                    <?php endif; ?>

                    <h4><?php echo $this->theme->display( 'Name' ); ?></h4>

                    <div>
                        <ul class="theme-info">
                            <li><?php printf( __( 'By %s', 'voxco' ), $this->theme->display( 'Author' ) ); ?></li>
                            <li><?php printf( __( 'Version %s', 'voxco' ), $this->theme->display( 'Version' ) ); ?></li>
                            <li><?php echo '<strong>' . __( 'Tags', 'voxco' ) . ':</strong> '; ?><?php printf( $this->theme->display( 'Tags' ) ); ?></li>
                        </ul>
                        <p class="theme-description"><?php echo $this->theme->display( 'Description' ); ?></p>
                        <?php
                            if ( $this->theme->parent() ) {
                                printf( ' <p class="howto">' . __( 'This <a href="%1$s">child theme</a> requires its parent theme, %2$s.', 'voxco' ) . '</p>', __( 'http://codex.wordpress.org/Child_Themes', 'voxco' ), $this->theme->parent()->display( 'Name' ) );
                            }
                        ?>

                    </div>
                </div>

                <?php
                $item_info = ob_get_contents();

                ob_end_clean();

                $sampleHTML = '';
                if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
                    Redux_Functions::initWpFilesystem();

                    global $wp_filesystem;

                    $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
                }

              


                $allowed_html_array = array(
                    'a' => array(
                        'href' => array(),
                    ),
                );



                $this->sections[] = array(
                    'title'  => esc_html__( 'General Settings', 'voxco' ),
                    'icon'   => 'el-icon-wrench',
                    'fields' => array(
                           array(
                                'id' => 'voxco_options_logo', // The item ID must be unique
                                'type' => 'media', // Built-in field types include:
                                'title' => esc_html__('Logo', 'voxco'),
                                'subtitle' => esc_html__('Upload your logo', 'voxco'),
                                'default'  => array(
                                    'url'=> get_template_directory_uri().'/images/logo.png',
                                    'width' => '92',
                                    'height' => '108',
                                ),
                            ),
                            array(
                                'id' => 'voxco_options_retina_logo', // The item ID must be unique
                                'type' => 'media', // Built-in field types include:
                                'title' => esc_html__('Retina Logo', 'voxco'),
                                'subtitle' => esc_html__('Upload your logo (retina version)', 'voxco'),
                                'default'  => array(
                                    'url'=> get_template_directory_uri().'/images/logo@2x.png'
                                ),
                            ),


                            array(
                                'id' => 'voxco_options_mobile_logo', // The item ID must be unique
                                'type' => 'media', // Built-in field types include:
                                'title' => esc_html__('Mobile Logo', 'voxco'),
                                'subtitle' => esc_html__('Upload your optional mobile menu logo', 'voxco'),
                                'default'  => array(
                                    'url'=> ''
                                ),
                                
                            ),
                            array(
                                'id' => 'voxco_options_mobile_retina_logo', // The item ID must be unique
                                'type' => 'media', // Built-in field types include:
                                'title' => esc_html__('Mobile Retina Logo', 'voxco'),
                                'subtitle' => esc_html__('Upload your optional mobile menu logo (retina version)', 'voxco'),
                                'default'  => array(
                                    'url'=> ''
                                ),
                                
                            ),


                            array(
                                'id' => 'voxco_options_favicon', 
                                'type' => 'media', 
                                'title' => esc_html__('Favicon', 'voxco'),
                                'subtitle' => esc_html__('Upload your favicon ( .ico format 16px 16px )', 'voxco'),
                                'default'  => array(
                                    'url'=> get_template_directory_uri().'/images/favicon.ico'
                                ),
                            ),
     
                            array(
                                'id'       => 'voxco_options_display_preloader',
                                'type'     => 'switch',
                                'title'    => esc_html__('Display Preloader', 'voxco'),
                                'default'  => true,
                            ),   
                            array(
                                'id' => 'voxco_options_loading_logo', // The item ID must be unique
                                'type' => 'media', // Built-in field types include:
                                'title' => esc_html__('Loading Screen Logo', 'voxco'),
                                'subtitle' => esc_html__('Upload your logo to be displayed on the loading screen', 'voxco'),
                                'default'  => array(
                                    'url'=> get_template_directory_uri().'/images/loading-logo.png',
                                    'width' => '46',
                                    'height' => '46',
                                ),
                            ),
                            array(
                                'id' => 'voxco_options_retina_loading_logo', // The item ID must be unique
                                'type' => 'media', // Built-in field types include:
                                'title' => esc_html__('Loading Screen Retina Logo', 'voxco'),
                                'subtitle' => esc_html__('Upload your logo to be displayed on the loading screen (retina version)', 'voxco'),
                                'default'  => array(
                                    'url'=> get_template_directory_uri().'/images/loading-logo@2x.png'
                                ),
                            ),
                            array(
                                'id' => 'voxco_options_preloader_bg_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Preloader Background Color', 'voxco'), 
                                'default' => '#ffffff',
                            ),
                            array(
                                'id' => 'voxco_options_preloader_prog_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Preloader Spinner Color', 'voxco'), 
                                'default' => '#353535',
                            ),
                            array(
                                'id'       => 'voxco_options_load_retina_js',
                                'type'     => 'switch',
                                'title'    => esc_html__('Load Retina JS', 'voxco'),
                                'subtitle' => esc_html__('Required for retina images to be loaded', 'voxco'),
                                'default'  => true,
                            ),  
                            array(
                                'id'       => 'voxco_options_gmap_api',
                                'type'     => 'text',
                                'title'    => esc_html__('Google Maps API Key', 'voxco'),
                                'subtitle' => wp_kses( __('Required for use of the google map shortcode, a free api key may be created <a href="https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key">here</a>', 'voxco') , $allowed_html_array ),
                                'default'  => ''
                                
                            ),
                     




                    )
                );


                  $this->sections[] = array(
                    'title'  => __( 'Styling Options', 'voxco' ),
                    'icon'   => 'el-icon-brush',
                    'fields' => array(
                            array(
                                'id' => 'voxco_options_page_border_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Page Border Color', 'voxco'), 
                                'default' => '#ffffff',
                            ),
                            array(
                                'id' => 'voxco_options_main_background_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Main Background Color', 'voxco'), 
                                'default' => '#f0f0f0',
                            ),
                            array(
                                'id' => 'voxco_options_loading_background_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Loading Screen Background Color', 'voxco'), 
                                'default' => '#f0f0f0',
                            ),

                            
                            array(
                                'id'        => 'voxco_options_menu_background_color',
                                'type'      => 'color_rgba',
                                'title'     => esc_html__('Menu / Side Header Background Color', 'voxco'), 
                                'default'   => array(
                                    'color'     => '#7c7c7c',
                                    'alpha'     => 1
                                ),
  
                            ),
                            
                            
                            array(
                                'id'        => 'voxco_options_menu_popup_background_color',
                                'type'      => 'color_rgba',
                                'title'     => 'Popup Menu Background Color',
                                'desc'     => esc_html__('For off canvas style menus only', 'voxco'),
                                'default'   => array(
                                    'color'     => '#000000',
                                    'alpha'     => 0.7
                                ),
  
                            ),
                            array(
                                'id' => 'voxco_options_mobile_menu_background',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Mobile Menu Bar Color', 'voxco'), 
                                'default' => '#333333',
                            ),

                            array(
                                'id' => 'voxco_options_menu_button_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Popup Menu Button Color / Mobile Menu Button Color', 'voxco'),
                                'default' => '#ffffff',
                            ),
                            array(
                                'id' => 'voxco_options_menu_button_active_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Popup Menu Active Button Color / Mobile Menu Active Button Color', 'voxco'),
                                'default' => '',
                            ),
                            array(
                                'id'       => 'voxco_options_menu_button_style',
                                'type'     => 'select',
                                'title'    => esc_html__('Popup Menu Button Style / Mobile Menu Button Style', 'voxco'),
                                'options'  => array(
                                    'round' => 'Round',
                                    'square' => 'Square',
                                    'no-border' => 'No Border',
                                ),
                                'default'  => 'round',
                            ),
                            array(
                                'id'       => 'voxco_options_menu_link_color',
                                'type'     => 'link_color',
                                'title'    => esc_html__('Menu Link Color', 'voxco'),
                                'default'  => array(
                                    'regular'  => '#a2a2a2', 
                                    'hover'    => '#ffffff', 
                                    'active'   => '#ffffff',  
                                    'visited'  => '#a2a2a2'  
                                )
                            ),
                            array(
                                'id'       => 'voxco_options_filter_link_color',
                                'type'     => 'link_color',
                                'title'    => esc_html__('Portfolio Filter Link Color', 'voxco'),
                                'default'  => array(
                                    'regular'  => '', 
                                    'hover'    => '', 
                                    'active'   => '',  
                                    'visited'  => ''  
                                )
                            ),
                            array(
                                'id' => 'voxco_options_menu_link_background_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Active Menu Link Background Color', 'voxco'), 
                                'default' => '',
                            ),
                            array(
                                'id'       => 'voxco_options_link_color',
                                'type'     => 'link_color',
                                'title'    => esc_html__('Link Color', 'voxco'),
                                'default'  => array(
                                    'regular'  => '#444444', 
                                    'hover'    => '#a2a2a2', 
                                    'active'   => '#a2a2a2',  
                                )
                            ),
                            
                            array(
                                'id' => 'voxco_options_highlight_background',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Highlighted Text Background Color', 'voxco'), 
                                'default' => '#000000',
                            ),
                            array(
                                'id' => 'voxco_options_highlight_font',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Highlighted Text Font Color', 'voxco'), 
                                'default' => '#ffffff',
                            ), 
                            
                            array(
                                'id'        => 'voxco_options_contact_form_color',
                                'type'      => 'color_rgba',
                                'title'     => esc_html__('Contact Form 7 Default Color', 'voxco'), 
                                'default'   => array(
                                    'color'     => '#ffffff',
                                    'alpha'     => 0.6
                                ),
                                'output' => array(
                                    'border-color' => '.wpcf7 input[type="text"], .wpcf7 input[type="email"], .wpcf7 textarea, .wpcf7-submit',
                                    'color'            => '.wpcf7 input[type="text"], .wpcf7 input[type="email"], .wpcf7 textarea, .wpcf7-submit',
                                ),
                            ),
                            array(
                                'id'        => 'voxco_options_contact_form_focus_color',
                                'type'      => 'color_rgba',
                                'title'     => esc_html__('Contact Form 7 Focus Color', 'voxco'),
                                'default'   => array(
                                    'color'     => '#ffffff',
                                    'alpha'     => 1
                                ),
                                'output' => array(
                                    'background-color' => '.wpcf7-form-control-wrap:after',
                                    'border-color' => '.wpcf7-submit:hover',
                                    'color' => '.wpcf7 input[type="text"]:focus, .wpcf7 input[type="email"]:focus, .wpcf7 textarea:focus, .wpcf7-submit:hover',
                                    
                                ),

                            ),
                            array(
                                'id'       => 'voxco_options_contact_form_style',
                                'type'     => 'select',
                                'title'    => esc_html__('Contact Form 7 Style', 'voxco'),
                                'options'  => array(
                                    'minimal' => 'Minimal',
                                    'boxed' => 'Boxed',
                                ),
                                'default'  => 'minimal',
                            ),
                            array(
                                'id' => 'voxco_options_custom_css',
                                'type' => 'textarea',
                                'title' => esc_html__('Custom CSS', 'voxco'),
                                'default'  => '', 
                            ),

                    )
                );


                $this->sections[] = array(
                    'title'  => esc_html__( 'Typography', 'voxco' ),
                    'icon'   => 'el-icon-font',
                    'fields' => array(

                        array(
                            'id'          => 'body-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('Body Font Style', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'text-transform' => true,
                            'line-height' => false,
                            'output'      => array('body', '.blockquote cite'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Main Font Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#7b8289',
                                'font-style'  => '400',
                                'font-family' => 'Open Sans',
                                'font-backup' => 'Arial, Helvetica, sans-serif',
                                'google'      => true,
                                'font-size'   => '16px',

                            ),
                        ),
                        array(
                            'id'          => 'heading-one-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('H1 Style', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'text-transform' => true,
                            'line-height' => false,
                            'output'      => array('h1', '.alpha'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Heading One Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#32373c',
                                'font-style'  => '400',
                                'font-family' => 'PT Serif',
                                'font-backup' => 'Georgia, serif',
                                'google'      => true,
                                'font-size'   => '34px',
                                'letter-spacing' => '0px',
                                'text-transform' => 'none',
                            ),
                        ),
                        array(
                            'id'          => 'heading-two-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('H2 Style', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'output'      => array('h2', '.beta'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Heading Two Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#32373c',
                                'font-style'  => '400',
                                'font-family' => 'Montserrat',
                                'font-backup' => 'Arial, Helvetica, sans-serif',
                                'google'      => true,
                                'font-size'   => '16px',
                                'letter-spacing' => '0px',
                                'text-transform' => 'uppercase',
                            ),
                        ),
                        
                        //navigation caption titles
                        array(
                            'id'          => 'heading-three-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('H3 Style', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'output'      => array('h3', '.gamma'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Heading Three Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#32373c',
                                'font-style'  => '400',
                                'font-family' => 'Montserrat',
                                'font-backup' => 'Arial, Helvetica, sans-serif',
                                'google'      => true,
                                'font-size'   => '14px',
                                'letter-spacing' => '0px',
                                'text-transform' => 'uppercase',
                            ),
                        ),
                        
                        array(
                            'id'          => 'heading-four-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('H4 Style', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'output'      => array('h4', '.delta'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Heading Four Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#32373c',
                                'font-style'  => '700',
                                'font-family' => 'Montserrat',
                                'font-backup' => 'Arial, Helvetica, sans-serif',
                                'google'      => true,
                                'font-size'   => '13px',
                                'letter-spacing' => '1px',
                                'text-transform' => 'uppercase',
                            ),
                        ),
                        array(
                            'id'          => 'heading-five-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('H5 Style', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'output'      => array('h5', '.epsilon'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Heading Five Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#32373c',
                                'font-style'  => '700',
                                'font-family' => 'Montserrat',
                                'font-backup' => 'Arial, Helvetica, sans-serif',
                                'google'      => true,
                                'font-size'   => '13px',
                                'letter-spacing' => '1px',
                                'text-transform' => 'uppercase',
                            ),
                        ),
                        array(
                            'id'          => 'heading-six-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('H6 Style', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'output'      => array('h6', '.zeta', '.vc_tta-title-text', '.vc_toggle_title h4'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Heading Six Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#32373c',
                                'font-style'  => '400',
                                'font-family' => 'Montserrat',
                                'font-backup' => 'Arial, Helvetica, sans-serif',
                                'google'      => true,
                                'font-size'   => '11px',
                                'letter-spacing' => '1px',
                                'text-transform' => 'uppercase',
                            ),
                        ),
                        array(
                            'id'          => 'mega-font-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('Mega Font', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'output'      => array('.mega'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Mega font styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#fff',
                                'font-weight' => '400',
                                'font-style'  => 'italic',
                                'font-family' => 'PT Serif',
                                'font-backup' => 'Georgia, serif',
                                'google'      => true,
                                'font-size'   => '78px',
                                'letter-spacing' => '0px',
                                'text-transform' => 'none',
                            ),
                        ),
                        array(
                            'id'          => 'accent-font-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('Accent Font', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'output'      => array('.accent, .wp-caption-text'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Accent Font Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#555555',
                                'font-weight' => '400',
                                'font-style'  => 'italic',
                                'font-family' => 'PT Serif',
                                'font-backup' => 'Georgia, serif',
                                'google'      => true,
                                'font-size'   => '16px',
                                'letter-spacing' => '0',
                                'text-transform' => '',
                            ),
                        ),
                        array(
                            'id'          => 'menu-font-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('Menu Font', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'color' => false,
                            'output'      => array('.portfolio-nav', '.mainnav'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Menu Font Styles', 'voxco'),
                            'default'     => array(
                                'font-style'  => 'italic',
                                'font-weight'  => '400',
                                'font-family' => 'PT Serif',
                                'font-backup' => 'Georgia, serif',
                                'google'      => true,
                                'font-size'   => '16px',
                            ),
                        ),
                        array(
                            'id'          => 'filter-font-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('Filter Font', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'color' => false,
                            'output'      => array('.portfolio-nav'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Portfolio Filter Font Styles, leave empty to use menu font', 'voxco'),
                            'default'     => array(
                                'font-style'  => '',
                                'font-weight'  => '',
                                'font-family' => '',
                                'font-backup' => '',
                                'google'      => true,
                                'font-size'   => '',
                            ),
                        ),
                        array(
                            'id'          => 'contact-font-styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('Form Font', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => true,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => true,
                            'color' => false,
                            'output'      => array('input[type="date"]', 'input[type="datetime"]', 'input[type="datetime-local"]', 'input[type="email"]', 'input[type="month"]', 'input[type="number"]', 'input[type="password"]', 'input[type="search"]', 'input[type="tel"]', 'input[type="text"]', 'input[type="time"]', 'input[type="url"]', 'input[type="week"]', 'select[multiple]', 'select[size]', 'textarea'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Contact Form 7 Font Styles', 'voxco'),
                            'default'     => array(
                              
                                'font-style'  => 'italic',
                                'font-weight'  => '400',
                                'font-family' => 'PT Serif',
                                'font-backup' => 'Georgia, serif',
                                'google'      => true,
                                'font-size'   => '14px',
                            ),
                        ),
                        array(
                            'id'          => 'voxco_options_dropcap_styles',
                            'type'        => 'typography',
                            'title'       => esc_html__('Drop Cap Font', 'voxco'),
                            'google'      => true,
                            'font-backup' => true,
                            'letter-spacing' => false,
                            'text-align' => false,
                            'line-height' => false,
                            'text-transform' => false,
                            'color' => true,
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Dropcap Font Styles', 'voxco'),
                            'default'     => array(
                                'color'       => '#1c1c1c',
                                'font-style'  => '400',
                                'font-family' => 'Open Sans',
                                'font-backup' => 'Arial, Helvetica, sans-serif',
                                'google'      => true,
                                'font-size'   => '30px',
                            ),
                        ),



                    ),
                );
                
               $this->sections[] = array(
                    'title'  => esc_html__( 'Layout Options', 'voxco' ),
                    'icon'   => 'el-icon-th-large',
                    
                    
                    
                    'fields' => array(
                        array(
                            'id'       => 'voxco_options_site_layout',
                            'type'     => 'radio',
                            'title'    => esc_html__('Site Layout', 'voxco' ), 
                            'options'  => array(
                                'layout-standard-header' => esc_html__( 'Standard Header', 'voxco' ),
                                'layout-side-header' => esc_html__(  'Side Header', 'voxco' ),
                                
                            ),
                            'default' => 'layout-side-header'
                        ),
                        array(
                                'id'        => 'voxco_options_page_border_width',
                                'type'      => 'slider',
                                'title'     => esc_html__('Page Border Width', 'voxco'),
                                'subtitle' => esc_html__('Enter the width of border around the page (pixels)', 'voxco'),    
                                "default"   => 13,
                                "min"       => 0,
                                "step"      => 1,
                                "max"       => 60,
                                'display_value' => 'label',
                        ),
                        array(
                                'id'       => 'voxco_options_border_sidebar',
                                'type'     => 'switch',
                                'title'    => esc_html__('Border on Side Header', 'voxco'),
                                'default'  => true,
                        ),
                        array(
                            'id'       => 'voxco_options_social_header',
                            'type'     => 'switch',
                            'title'    => esc_html__('Display Social Icons in Main Menu', 'voxco'),
                            'default'  => false,
                        ),
                        array(
                                'id'             => 'voxco_options_page_padding',
                                'type'           => 'spacing',
                                'mode'           => 'padding',
                                'units'          => array('px'),
                                'units_extended' => 'false',
                                'title'          => esc_html__('Content Offset from Main Container', 'voxco'),
                                'default'            => array(
                                    'padding-top'     => '0px', 
                                    'padding-right'   => '0px', 
                                    'padding-bottom'  => '0px', 
                                    'padding-left'    => '0px',
                                    'units'          => 'px', 
                                )
                        ),

                        array(
                                'id'             => 'voxco_options_column_padding',
                                'type'           => 'spacing',
                                'mode'           => 'padding',
                                'units'          => array('px'),
                                'units_extended' => 'false',
                                'title'          => esc_html__('Default Column Padding', 'voxco'),
                                'subtitle' => esc_html__('Can be overridden on visual composer column styling options, leave empty for default visual composer styles', 'voxco'),
                                'default'            => array(
                                    'padding-top'     => '40px', 
                                    'padding-right'   => '40px', 
                                    'padding-bottom'  => '40px', 
                                    'padding-left'    => '40px',
                                    'units'          => 'px', 
                                )
                        ),
                    ),
                ); 

               $this->sections[] = array(
                    'title'  => __( 'Standard header settings', 'voxco' ),
                    'icon'   => 'el-icon-adjust-alt',
                    'subsection' => true,
                    'fields' => array(

                            array(
                                'id'       => 'voxco_options_site_width',
                                'type'     => 'text',
                                'title'    => esc_html__('Boxed Layout Max Width (Pixels)', 'voxco'),
                                'subtitle' => esc_html__('Layout width, leave empty for full width site', 'voxco'),
                                'validate' => 'numeric',
                                'msg'      => esc_html__('Must be a numerical value', 'voxco'),
                                'default'  => ''
                            ),
                     
                            array(
                                'id'       => 'voxco_options_boxed_body_background',
                                'type'     => 'background',
                                'title'    => esc_html__('Boxed Layout Body Background', 'voxco'),
                                'subtitle' => esc_html__('Body background color for boxed layout', 'voxco'),
                                
                              
                            ),

                            array(
                                'id'       => 'voxco_options_standard_menu_style',
                                'type'     => 'image_select',
                                'title'    => esc_html__('Menu Style', 'voxco'),
                                 'options'  => array(
                                    'l4'      => array(
                                        'alt'   => esc_html__('Style Four', 'voxco'),
                                        'img'  => get_template_directory_uri() . '/images/menu-layout-4.png'
                                    ),
                                    'l5'      => array(
                                        'alt'   => esc_html__('Style Five', 'voxco'),
                                        'img'  => get_template_directory_uri() . '/images/menu-layout-5.png'
                                    ),
                    
                                ),
                                'default' => 'l4'
                            ),
                            array(
                                'id'       => 'voxco_options_menu_bar_width',
                                'type'     => 'text',
                                'validate' => 'numeric',
                                'title'    => esc_html__('Menu Bar Max Width (Pixels)', 'voxco'),
                                'subtitle' => esc_html__('Leave empty for full width menu bar', 'voxco'),
                                'default'  => ''
                                
                            ),
                            array(
                                'id'       => 'voxco_options_menu_inner_width',
                                'type'     => 'text',
                                'validate' => 'numeric',
                                'title'    => esc_html__('Menu Inner Max Width (Pixels)', 'voxco'),
                                'subtitle' => esc_html__('Leave empty for full width menu inner', 'voxco'),
                                'default'  => ''
                                
                            ),

                            array(
                                'id'             => 'voxco_options_menu_outer_offset',
                                'type'           => 'spacing',
                                'mode'           => 'padding',
                                'units'          => array('px'),
                                'units_extended' => 'false',
                                'title'          => esc_html__('Menu Outer Offset', 'voxco'),
                                'bottom'         => 'false',
                                'default'            => array(
                                    'padding-top'     => '0px', 
                                    'padding-right'   => '0px', 
                                    'padding-left'    => '0px',
                                    'units'          => 'px', 
                                )
                            ),
                            
                            array(
                                'id'             => 'voxco_options_menu_padding',
                                'type'           => 'spacing',
                                'output'         => array('.layout-standard-header .nav-top-inner'),
                                'mode'           => 'padding',
                                'units'          => array('px'),
                                'units_extended' => 'false',
                                'title'          => esc_html__('Menu Inner Offset', 'voxco'),
                                'top'            => 'false',
                                'bottom'         => 'false',
                                'default'            => array(
                                    'padding-right'   => '40px', 
                                    'padding-left'    => '40px',
                                    'units'          => 'px', 
                                )
                            ),

                            array(
                                'id'       => 'voxco_options_nav_height',
                                'type'     => 'spinner',
                                'title'    => esc_html__('Menu Bar Height (Pixels)', 'voxco'),
                                'desc'      => esc_html__('Standard height for navigation bar', 'voxco'),
                                'default'   => 200,
                                'min'       => 60,
                                'step'      => 1,
                                'max'       => 400,
                                'display_value' => 'label'
                            ),
                            array(
                                'id'       => 'voxco_options_nav_scrolled_height',
                                'type'     => 'spinner',
                                'title'    => esc_html__('Fixed Menu Bar Scrolled Height (Pixels)', 'voxco'),
                                'desc'      => esc_html__('Height of fixed navigation bar after scrolling down the page', 'voxco'),
                                'default'   => 80,
                                'min'       => 60,
                                'step'      => 1,
                                'max'       => 400,
                                'display_value' => 'label'
                            ),
                            array(
                                'id'       => 'voxco_options_nav_fixed',
                                'type'     => 'switch',
                                'title'    => esc_html__('Fixed Navigation Bar', 'voxco'),
                                'default'  => false,
                            ),
                            array(
                                'id'       => 'voxco_options_nav_button_four_fixed',
                                'type'     => 'switch',
                                'title'    => esc_html__('Fixed Menu Button (Menu Four)', 'voxco'),
                                'default'  => true,
                            ),

                    ), 
                );

               $this->sections[] = array(
                    'title'  => __( 'Side Header Settings', 'voxco' ),
                    'icon'   => 'el-icon-adjust-alt',
                    'subsection' => true,
                    'fields' => array(

                            array(
                                'id'        => 'voxco_options_siderbar_width',
                                'type'      => 'slider',
                                'title'     => esc_html__('Side Header Width', 'voxco'),
                                'subtitle'  => esc_html__('Enter the width of side header (percentage)', 'voxco'),    
                                "default"   => 20,
                                "min"       => 15,
                                "step"      => 1,
                                "max"       => 60,
                                'display_value' => 'label'
                            ),
                            array(
                                'id'       => 'voxco_options_siderbar_slides',
                                'type'     => 'gallery',
                                'title'    => esc_html__('Side Header Slider Images', 'voxco'),
                                'subtitle' => esc_html__('Select default side header slider images', 'voxco'),
                                'desc'     => esc_html__('Select one image for a static background, leave empty to use a color', 'voxco'),
                                'default'  => '', 
                            ),
                            array(
                                'id'        => 'voxco_options_slider_speed',
                                'type'      => 'slider',
                                'title'     => esc_html__('Slider Speed', 'voxco'),
                                'subtitle'  => esc_html__('Enter the sidebar slider speed (pixels per second)', 'voxco'),    
                                "default"   => 70,
                                "min"       => 40,
                                "step"      => 1,
                                "max"       => 120,
                                'display_value' => 'label'
                            ),
                            array(
                                'id'       => 'voxco_options_menu_style',
                                'type'     => 'image_select',
                                'title'    => esc_html__('Menu Style', 'voxco'),
                                 'options'  => array(
                                    'l1'      => array(
                                        'alt'   => esc_html__('Style One', 'voxco'),
                                        'img'   => get_template_directory_uri() . '/images/menu-layout-1.png'
                                    ),
                                    'l2'      => array(
                                        'alt'   => esc_html__('Style Two', 'voxco'),
                                        'img'   => get_template_directory_uri() . '/images/menu-layout-2.png'
                                    ),
                                    'l3'      => array(
                                        'alt'   => esc_html__('Style Three', 'voxco'),
                                        'img'  => get_template_directory_uri() . '/images/menu-layout-3.png'
                                    ),

                                ),
                                'default' => 'l1'
                            ),
                            array(
                                'id'               => 'voxco_options_sidebar_content',
                                'type'             => 'editor',
                                'title'            => esc_html__('Side Header Content (for menu style three)', 'voxco'),
                                'subtitle'         => esc_html__('Enter the default side bar content for menu style three', 'voxco'),
                                'default'          => '<h1 class="mega">Voxco</h1>',
                                'args'   => array(
                                    'teeny'            => true,
                                    'textarea_rows'    => 10
                                )
                            ),
                            array(
                                'id' => 'voxco_options_sidebar_content_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Side Header Content Color (for menu style three)', 'voxco'), 
                                'default' => '#ffffff',
                            ),
                            array(
                                'id'       => 'voxco_options_sidebar_content_pos',
                                'type'     => 'select',
                                'title'    => esc_html__('Side Header Content Position (for menu style three)', 'voxco'),
                                'options'  => array(
                                    'cen-cen'      => esc_html__( 'Center Center', 'voxco' ),
                                    'cen-left'     => esc_html__( 'Center Left', 'voxco'),
                                    'btm-left'     => esc_html__( 'Bottom Left', 'voxco' ),
                                ),
                                'default'  => 'cen-cen',
                            ),


                    )
                );

                $this->sections[] = array(
                    'title'  => esc_html__( 'Portfolio Options', 'voxco' ),
                    'icon'   => 'el-icon-align-justify',
                    'fields' => array(
                            array(
                                'id'       => 'voxco_options_masonary_grid',
                                'type'     => 'select',
                                'title'    => esc_html__('Portfolio Grid Column Sizes', 'voxco'),
                                'desc'     => esc_html__('Select individual post widths from the edit post screen > post options', 'voxco'),
                                'options'  => array(
                                    'halfs' => 'Full / Half / Quarter / Three Quarters',
                                    'quarters' => 'Full / Third / Two Thirds',
                                ),
                                'default'  => 'halfs',
                            ),
                            array(
                                'id'       => 'voxco_options_portfolio_grid_spacing',
                                'type'     => 'text',
                                'validate' => 'numeric',
                                'title'    => esc_html__('Spacing between masonary portfolio items (pixels)', 'voxco'),
                                'default'  => '0'
                            ),
                            array(
                                'id'       => 'excluded_cats',
                                'type'     => 'checkbox',
                                'title'    => esc_html__('Portfolio categorys to exclude from prev/next post navigation', 'voxco'), 
                                'data'     => 'categories',
                                'args' => array('taxonomy' => array('portfolio_item_category')),

                            ),

                    ),
                ); 


                function voxco_opts_rev() {
                    if(shortcode_exists("rev_slider")){      
                         $slider = new RevSlider();
                         $revolution_sliders = $slider->getArrSliders();
                         $slider_options = array();
                         foreach ( $revolution_sliders as $revolution_slider  ) {
                               $alias = $revolution_slider->getAlias();
                               $title = $revolution_slider->getTitle();
                               $slider_options[ $alias ] = $title;
                         }
                        
                    }
                    else{
                        $slider_options = array('none' => esc_html__( 'No Sliders Found', 'voxco' ));
                    }
                    return $slider_options; 
                }

                $this->sections[] = array(
                    'title'  => esc_html__( 'Blog Settings', 'voxco' ),
                    'icon'   => 'el-icon-bullhorn',
                    'fields' => array(
                            

                            array(
                                'id'       => 'voxco_options_blog_grid',
                                'type'     => 'select',
                                'title'    => esc_html__('Masonary Blog Column Size', 'voxco'),
                                'options'  => array(
                                    'p12' => esc_html__('Full', 'voxco'),
                                    'p6'  => esc_html__('Halfs', 'voxco'),
                                    'p4'  => esc_html__('Thirds', 'voxco'),
                                    'p3'  => esc_html__('Quarters', 'voxco'),
                                ),
                                'default'  => 'p4',
                            ),

                            array(
                                'id'       => 'voxco_options_sticky_grid',
                                'type'     => 'select',
                                'title'    => esc_html__('Sticky Post Column Size', 'voxco'),
                                'options'  => array(
                                    'p12' => esc_html__('Full', 'voxco'),
                                    'p6'  => esc_html__('Half', 'voxco'),
                                    'p4'  => esc_html__('Third', 'voxco'),
                                    'p8'  => esc_html__('Two Thirds', 'voxco'),
                                    'p3'  => esc_html__('Quarter', 'voxco'),
                                    'p9'  => esc_html__('Three Quarters', 'voxco'),
                                ),
                                'default'  => 'p8',
                            ),

                            array(
                                'id'       => 'voxco_options_blog_grid_spacing',
                                'type'     => 'text',
                                'title'    => esc_html__('Spacing between masonary blog items (pixels)', 'voxco'),
                                'default'  => '13',
                            ),
                            array(
                                'id'       => 'voxco_options_excerpt_length',
                                'type'     => 'text',
                                'title'    => esc_html__('Automatic Excerpt Length (In Words)', 'voxco'),
                                'subtitle' => esc_html__('Can be overridden with manual excerpt', 'voxco'),
                                'validate' => 'numeric',
                                'msg'      => esc_html__('Must be a numerical value', 'voxco'),
                                'default'  => '18',
                            ),
                            array(
                                'id'       => 'voxco_options_sidebar',
                                'type'     => 'select',
                                'title'    => esc_html__('Single Post Sidebar Style', 'voxco'),
                                'options'  => array(
                                    'aside-standard' => esc_html__('Standard', 'voxco'),
                                    'aside-offcanvas' => esc_html__('Off Canvas', 'voxco'),
                                    'aside-none' => esc_html__('No Sidebar', 'voxco'),
                                ),
                                'default'  => 'aside-standard',
                            ),
                            array(
                                'id'       => 'voxco_options_sidebar_arch',
                                'type'     => 'select',
                                'title'    => esc_html__('Archive Sidebar Style', 'voxco'),
                                'options'  => array(
                                    'aside-standard' => esc_html__('Standard', 'voxco'),
                                    'aside-offcanvas' => esc_html__('Off Canvas', 'voxco'),
                                    'aside-none' => esc_html__('No Sidebar', 'voxco'),
                                ),
                                'default'  => 'aside-offcanvas',
                            ),
                            array(
                                'id' => 'voxco_options_blog_sidebar_background_color',
                                'type' => 'color',
                                'transparent' => false,
                                'output' => array('background-color' => '.aside-offcanvas'),
                                'title' => esc_html__('Off Canvas Sidebar Backround Color', 'voxco'), 
                                'default' => '#2a2a2a',
                            ),
                            array(
                                'id' => 'voxco_options_blog_sidebar_font_color',
                                'type' => 'color',
                                'transparent' => false,
                                'output' => array('color' => '.aside-offcanvas', 'border-color' => '.aside-offcanvas #searchsubmit'),
                                'title' => esc_html__('Off Canvas Sidebar Font Color', 'voxco'), 
                                'default' => '#8b8581',
                            ),
                            array(
                                'id' => 'voxco_options_blog_sidebar_button_color',
                                'type' => 'color',
                                'transparent' => false,
                                'output' => array('border-color' => '.aside-trigger'),
                                'title' => esc_html__('Off Canvas Sidebar Button Color', 'voxco'), 
                                'default' => '#ffffff',
                            ),
                            array(
                                'id' => 'voxco_options_blog_sidebar_heading_color',
                                'type' => 'color',
                                'transparent' => false,
                                'output' => array('color' => '.aside-offcanvas h6, .aside-offcanvas #searchform div', 'border-color' => '.aside-close'),
                                'title' => esc_html__('Off Canvas Sidebar Heading Color', 'voxco'), 
                                'default' => '#ffffff',
                            ),


                            array(
                                'id' => 'voxco_options_blog_excerpt_background_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Blog Excerpt Backround Color', 'voxco'), 
                                'default' => '#2a2a2a',
                            ),
                            array( 
                                'id'       => 'voxco_options_blog_excerpt_border',
                                'type'     => 'border',
                                'title'    => esc_html__('Blog Excerpt Border', 'voxco'),
                                'output'   => array('.entry-summary'),
                                'default'  => array(
                                    'border-color'  => '', 
                                    'border-style'  => '', 
                                    'border-top'    => '', 
                                    'border-right'  => '', 
                                    'border-bottom' => '', 
                                    'border-left'   => '',
                                )
                            ),
                            array(
                                'id' => 'voxco_options_blog_excerpt_heading_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Blog Excerpt Heading Color', 'voxco'), 
                                'default' => '#ffffff',
                            ),
                            array(
                                'id'       => 'voxco_options_blog_excerpt_heading_font',
                                'type'     => 'select',
                                'title'    => esc_html__('Blog Excerpt Heading Font', 'voxco'),
                                'options'  => array(
                                    'alpha' => esc_html__( 'Heading 1 font', 'voxco' ),
                                    'beta' => esc_html__( 'Heading 2 font', 'voxco' ),
                                    'gamma' => esc_html__( 'Heading 3 font', 'voxco' ),
                                    'delta' => esc_html__( 'Heading 4 font', 'voxco' ),
                                    'epsilon' => esc_html__( 'Heading 5 font', 'voxco' ),
                                    'zeta' => esc_html__( 'Heading 6 font', 'voxco' ),
                                ),
                                'default' => 'beta',
                            
                            ),
                            array(
                                'id' => 'voxco_options_blog_excerpt_font_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Blog Excerpt Font Color', 'voxco'), 
                                'default' => '#8b8581',
                            ),
                            array(
                                'id' => 'voxco_options_archive_bg',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Archive Background Color', 'voxco'), 
                                'default' => '#ffffff',
                            ),
                            array(
                                'id' => 'voxco_options_single_post_bg',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Single Post Background Color', 'voxco'), 
                                'default' => '#ffffff',
                            ),
                            array(
                                'id'       => 'voxco_options_single_post_bg_apply',
                                'type'     => 'select',
                                'title'    => esc_html__('Apply Single Post Background Color o', 'voxco'),
                                'options'  => array(
                                    'page' => esc_html__( 'Whole page', 'voxco' ),
                                    'content' => esc_html__( 'Content area', 'voxco' ),
                                ),
                                'default' => 'page',
                            
                            ),
                            
                            array(
                                'id'      => 'voxco_options_blog_header',
                                'title' => esc_html__('Blog Header Style', 'voxco'),
                                'type'    => 'select',
                                'options' => array(
                                    'yes' => esc_html__( 'Static Image / Solid Color Header', 'voxco' ),
                                    'parallax' => esc_html__( 'Parallax Image header', 'voxco' ),
                                    'rev' => esc_html__( 'Revolution Slider', 'voxco' ),
                                    'no' => esc_html__( 'No Header', 'voxco' ),
                                ),
                                'default' => 'no',
                            ),
                            array(
                                'id'      => 'voxco_options_rev',
                                'title' => esc_html__('Revolution Slider', 'voxco'),
                                'type'    => 'select',
                                'options' => voxco_opts_rev(),
                                'default'  => '', 
                                
                            ),
                            array(
                                'id'      => 'voxco_options_blog_header_height',
                                'title' => esc_html__('Blog Header Height', 'voxco'),
                                'type'    => 'select',
                                'options' => array(
                                    'h1' => esc_html__( 'Full (1:1)', 'voxco' ),
                                    'h2' => esc_html__( 'Half (2:1)', 'voxco' ),
                                    'h3' => esc_html__( 'Third (3:1)', 'voxco' ),
                                    'h4' => esc_html__( 'Quarter (4:1)', 'voxco' ),
                                    'hs' => esc_html__( 'Full Screen', 'voxco' ),
                                    'auto' => esc_html__( 'Auto', 'voxco' ),
                                ),
                                'default' => 'h2',
                            ),
                            array(
                                'id'      => 'voxco_options_blog_header_mobile_height',
                                'title' => esc_html__('Blog Header Height On Mobile', 'voxco'),
                                'type'    => 'select',
                                'options' => array(
                                    'mh1' => esc_html__( 'Full (1:1)', 'voxco' ),
                                    'mh2' => esc_html__( 'Half (2:1)', 'voxco' ),
                                    'mh3' => esc_html__( 'Third (3:1)', 'voxco' ),
                                    'mh4' => esc_html__( 'Quarter (4:1)', 'voxco' ),
                                    'mhs' => esc_html__( 'Full Screen', 'voxco' ),
                                    'auto' => esc_html__( 'Auto', 'voxco' ),
                                ),
                                'default' => 'mh2',
                            ),
                            array(
                                'id'      => 'voxco_options_blog_header_offset',
                                'title' => esc_html__('Full Screen Header Offset Size (Pixels)', 'voxco'),
                                'type'     => 'text',
                                'validate' => 'numeric',
                                'subtitle' => esc_html__('Offset Size For Full Screen Header', 'voxco'),
                                'default'  => '0'
                            ),
                            array(
                                'id'      => 'voxco_options_blog_header_width',
                                'title' => esc_html__('Blog Header Stretch', 'voxco'),
                                'type'    => 'select',
                                'options' => array(
                                    'row-boxed' => esc_html__( 'Default', 'voxco' ),
                                    'row-full-boxed' => esc_html__( 'Stretch Header', 'voxco' ),
                                    'row-full' => esc_html__( 'Stretch Header And Content', 'voxco' ),
                                ),
                                'default' => 'row-full',
                            ),
                            array(
                                'id'       => 'voxco_options_blog_header_margin',
                                'type'     => 'text',
                                'title'    => esc_html__('Blog Header Margin Bottom', 'voxco'),
                                'validate' => 'numeric',
                                'msg'      => esc_html__('Must be a numerical value', 'voxco'),
                                'default'  => '13',
                            ),
                            array(
                                'id'      => 'voxco_options_blog_title',
                                'title' => esc_html__('Blog Title', 'voxco'),
                                'type'    => 'select',
                                'options' => array(
                                    'mega' => esc_html__( 'Mega Font', 'voxco' ),
                                    'alpha' => esc_html__( 'Heading One Font', 'voxco' ),
                                    'beta' => esc_html__( 'Heading Two Font', 'voxco' ),
                                    'gamma' => esc_html__( 'Heading Three Font', 'voxco' ),
                                    'delta' => esc_html__( 'Heading Four Font', 'voxco' ),
                                    'epsilon' => esc_html__( 'Heading Five Font', 'voxco' ),
                                    'zeta' => esc_html__( 'Heading Six Font', 'voxco' ),
                                    'accent' => esc_html__( 'Accent Font', 'voxco' ),
                                    'none'   => esc_html__( 'No Title', 'voxco' ),
                                ),
                                'default' => 'alpha',
                            ),
                            array(
                                'id'      => 'voxco_options_blog_title_text',
                                'title' => esc_html__('Blog Title Text', 'voxco'),
                                'type'     => 'text',
                                'subtitle' => esc_html__('Enter the post page title', 'voxco'),
                                'default'  => 'Latest Posts'
                            ),
                            array(
                                'id' => 'voxco_options_blog_title_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Blog Title Color', 'voxco'), 
                                'default' => '#ffffff',
                            ),
                            array(
                                'id'      => 'voxco_options_blog_title_align',
                                'title' => esc_html__('Blog Title Alignment', 'voxco'),
                                'type'    => 'select',
                                'options' => array(
                                    'align-left' => esc_html__( 'Left', 'voxco' ),
                                    'align-right' => esc_html__( 'Right', 'voxco' ),
                                    'align-center' => esc_html__( 'Center', 'voxco' ),
                                ),
                                'default' => 'align-left',
                            ),
                            array(
                                'id'      => 'voxco_options_blog_title_v_align',
                                'title' => esc_html__('Blog Title Vertical Alignment', 'voxco'),
                                'type'    => 'select',
                                'options' => array(
                                    'a-center' => esc_html__( 'Center', 'voxco' ),
                                    'a-top' => esc_html__( 'Top', 'voxco' ),
                                    'a-bottom' => esc_html__( 'Bottom', 'voxco' ),
                                ),
                                'default' => 'a-center',
                            ),
                            array(
                                'id' => 'voxco_options_blog_header_image', 
                                'type' => 'media', 
                                'title' => esc_html__('Blog Header Background Image', 'voxco'),
                                'subtitle' => esc_html__('When Posts Page set to Front Page', 'voxco'),
                                'default'  => array(
                                    'url'=> ''
                                ),
                            ),
                            array(
                                'id' => 'voxco_options_blog_header_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Blog Header Background Color', 'voxco'), 
                                'default' => '#7c7c7c',
                            ),

                    ),
                );


            $this->sections[] = array(
                'title' => esc_html__('Social Networks', 'voxco'),
                'icon'   => 'el-icon-link',
                'fields' => array(
                    
                  
                    array(
                        'id' => 'voxco_options_twitter',
                        'type' => 'text',
                        'title' => esc_html__('Twitter Link', 'voxco'), 
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'),
                        'default' => 'http://www.twitter.com'
                    ),
                    array(
                        'id' => 'voxco_options_facebook',
                        'type' => 'text',
                        'title' => esc_html__('Facebook Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => 'http://www.facebook.com'
                    ),
                    array(
                        'id' => 'voxco_options_dribbble',
                        'type' => 'text',
                        'title' => esc_html__('Dribbble Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => 'http://www.dribbble.com'
                    ),
                    array(
                        'id' => 'voxco_options_github',
                        'type' => 'text',
                        'title' => esc_html__('Github Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_youtube',
                        'type' => 'text',
                        'title' => esc_html__('Youtube Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_vimeo',
                        'type' => 'text',
                        'title' => esc_html__('Vimeo Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_instagram',
                        'type' => 'text',
                        'title' => esc_html__('Instagram Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_pinterest',
                        'type' => 'text',
                        'title' => esc_html__('Pinterest Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_wordpress',
                        'type' => 'text',
                        'title' => esc_html__('WordPress Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_google',
                        'type' => 'text',
                        'title' => esc_html__('Google Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_flickr',
                        'type' => 'text',
                        'title' => esc_html__('Flickr Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_linkedin',
                        'type' => 'text',
                        'title' => esc_html__('Linkedin Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_dropbox',
                        'type' => 'text',
                        'title' => esc_html__('Dropbox Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_tumblr',
                        'type' => 'text',
                        'title' => esc_html__('Tumblr Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),
                    array(
                        'id' => 'voxco_options_behance',
                        'type' => 'text',
                        'title' => esc_html__('Behance Link', 'voxco'),
                        'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                        'default' => ''
                    ),


                  
                )
            );
            

                $this->sections[] = array(
                    'title'  => esc_html__( 'Footer Options', 'voxco' ),
                    'icon'   => 'el-icon-align-justify',
                    'fields' => array(
                   
                            array(
                                'id' => 'voxco_options_footer_bg',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Footer Background Color', 'voxco'), 
                                'default' => '#eeeeee',
                            ),
                            array(
                                'id' => 'voxco_options_footer_text',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Footer Text Color', 'voxco'), 
                                'default' => '#4e525b',
                            ),
                            array(
                                'id' => 'voxco_options_footer_link_color',
                                'type' => 'color',
                                'transparent' => false,
                                'title' => esc_html__('Footer Link Color', 'voxco'), 
                                'default' => '#444444',
                            ),
                             
                            array(
                                'id' => 'footer_logo', // The item ID must be unique
                                'type' => 'media', // Built-in field types include:
                                'title' => esc_html__('Footer Logo', 'voxco'),
                                'subtitle' => esc_html__('Upload your logo', 'voxco'),
                                'default'  => array(
                                    'url'=> get_template_directory_uri().'/images/footer-logo.png'
                                ),
                            ),
                             array(
                                'id' => 'footer_retina_logo', // The item ID must be unique
                                'type' => 'media', // Built-in field types include:
                                'title' => esc_html__('Footer Retina Logo', 'voxco'),
                                'subtitle' => esc_html__('Upload your logo (retina version)', 'voxco'),
                                'default'  => array(
                                    'url'=> get_template_directory_uri().'/images/footer-logo@2x.png'
                                ),
                            ),
                            array(
                                'id'       => 'voxco_options_social_footer',
                                'type'     => 'switch',
                                'title'    => esc_html__('Display Social Network Icons In Footer', 'voxco'),
                                'default'  => true,
                            ),
                            array(
                                'id'       => 'voxco_options_footer_width',
                                'type'     => 'switch',
                                'title'    => esc_html__('Full Width Footer', 'voxco'),
                                'subtitle' => esc_html__('Stretch footer to full width. (Boxed layout only)', 'voxco'),
                                'default'  => false,
                            ), 
                            array(
                                'id' => 'footer_copyright',
                                'type' => 'text',
                                'title' => esc_html__('Footer Copyright', 'voxco'),
                                'sub_desc' => esc_html__('Leave field empty to remove icon', 'voxco'), 
                                'default' => esc_html__('Copyright 2017, Example Corporation', 'voxco'), 
                            ),

                    ),
                ); 
                

                 $this->sections[] = array(
                    'title'  => esc_html__( 'Responsive Options', 'voxco' ),
                    'icon'   => 'el-icon-resize-small ',
                    'fields' => array(
                        array(
                                'id'        => 'voxco_options_mobile_page_border_width',
                                'type'      => 'slider',
                                'title'     => esc_html__('Page Border Width', 'voxco'),
                                'subtitle'  => esc_html__('Enter the width of border around the page (pixels)', 'voxco'),    
                                "default"   => 10,
                                "min"       => 0,
                                "step"      => 1,
                                "max"       => 60,
                                'display_value' => 'label',
                                
                        ),
                        array(
                                'id'             => 'voxco_options_mobile_page_padding',
                                'type'           => 'spacing',
                                'mode'           => 'padding',
                                'units'          => array('px'),
                                'units_extended' => 'false',
                                'title'          => esc_html__('Content offset from main container', 'voxco'),
                                'default'            => array(
                                    'padding-top'     => '0px', 
                                    'padding-right'   => '0px', 
                                    'padding-bottom'  => '0px', 
                                    'padding-left'    => '0px',
                                    'units'          => 'px', 
                                )
                        ),
                        array(
                                'id'             => 'voxco_options_mobile_column_padding',
                                'type'           => 'spacing',
                                'mode'           => 'padding',
                                'units'          => array('px'),
                                'units_extended' => 'false',
                                'title'          => esc_html__('Default Column Padding', 'voxco'),
                                'subtitle'       => esc_html__('Can be overridden on vusual composer column styling options, leave empty for default visual composer styles', 'voxco'),
                                'default'            => array(
                                    'padding-top'     => '40px', 
                                    'padding-right'   => '40px', 
                                    'padding-bottom'  => '40px', 
                                    'padding-left'    => '40px',
                                    'units'          => 'px', 
                                )
                        ),
                        array(
                                'id'             => 'voxco_options_mobile_menu_offset',
                                'type'           => 'spacing',
                                'mode'           => 'padding',
                                'units'          => array('px'),
                                'units_extended' => 'false',
                                'title'          => esc_html__('Menu Outer Offset', 'voxco'),
                                'bottom'         => 'false',
                                'default'            => array(
                                    'padding-top'     => '0px', 
                                    'padding-right'   => '0px', 
                                    'padding-left'    => '0px',
                                    'units'          => 'px', 
                                )
                        ),
                        array(
                                'id'       => 'voxco_options_mobile_nav_height',
                                'type'     => 'spinner',
                                'title'    => esc_html__('Standard Header Menu Bar Height (Pixels)', 'voxco'),
                                'desc'      => esc_html__('Height for navigation bar on mobile (Layout Standard Header menus only)', 'voxco'),
                                'default'   => 200,
                                'min'       => 60,
                                'step'      => 1,
                                'max'       => 400,
                                'display_value' => 'label'
                        ),

                        array(
                               'id' => 'section_body_font_start',
                               'type' => 'section',
                               'title' => esc_html__('Body Font', 'voxco'),
                               'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_body_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '16'
                                
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_body_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '0'
                                
                        ),
                        array(
                            'id'     => 'section_body_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),



                        array(
                            'id' => 'section_h_one_font_start',
                            'type' => 'section',
                            'title' => esc_html__('H1 Font', 'voxco'),
                            'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_one_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '34'
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_one_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '0'
                                
                        ),
                        array(
                            'id'     => 'section_h_one_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),



                        array(
                            'id' => 'section_h_two_font_start',
                            'type' => 'section',
                            'title' => esc_html__('H2 Font', 'voxco'),
                            'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_two_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '16'
                                
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_two_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '0'
                                
                        ),
                        array(
                            'id'     => 'section_h_two_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),


                        array(
                            'id' => 'section_h_three_font_start',
                            'type' => 'section',
                            'title' => esc_html__('H3 Font', 'voxco'),
                            'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_three_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '15'
                                
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_three_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '0'
                                
                        ),
                        array(
                            'id'     => 'section_h_three_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),


                        
                        array(
                            'id' => 'section_h_four_font_start',
                            'type' => 'section',
                            'title' => esc_html__('H4 Font', 'voxco'),
                            'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_four_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '14'
                                
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_four_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '1'
                                
                        ),
                        array(
                            'id'     => 'section_h_four_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),


                        array(
                            'id' => 'section_h_five_font_start',
                            'type' => 'section',
                            'title' => esc_html__('H5 Font', 'voxco'),
                            'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_five_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '13'
                                
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_five_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '1'
                                
                        ),
                        array(
                            'id'     => 'section_h_five_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),


                        array(
                            'id' => 'section_h_six_font_start',
                            'type' => 'section',
                            'title' => esc_html__('H6 Font', 'voxco'),
                            'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_six_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '11'
                                
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_h_six_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '1'
                                
                        ),
                        array(
                            'id'     => 'section_h_six_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),



                        array(
                            'id' => 'section_mega_font_start',
                            'type' => 'section',
                            'title' => esc_html__('Mega Font', 'voxco'),
                            'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_mega_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '34'
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_mega_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '0'
                        ),
                        array(
                            'id'     => 'section_mega_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),

                        array(
                            'id' => 'section_accent_font_start',
                            'type' => 'section',
                            'title' => esc_html__('Accent Font', 'voxco'),
                            'indent' => true, 
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_accent_font',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Font Size (Pixels)', 'voxco'),
                            'default'  => '16'
                        ),
                        array(
                            'id'       => 'voxco_options_mobile_accent_font_spacing',
                            'type'     => 'text',
                            'validate' => 'numeric',
                            'title'    => esc_html__('Letter Spacing (Pixels)', 'voxco'),
                            'default'  => '0'
                        ),
                        array(
                            'id'     => 'section_accent_font_end',
                            'type'   => 'section',
                            'indent' => false,
                        ),

               

                    ),
                ); 


                $this->sections[] = array(
                    'title'  => esc_html__( 'Import / Export', 'voxco' ),
                    'desc'   => esc_html__( 'Import and Export your Redux Framework settings from file, text or URL.', 'voxco' ),
                    'icon'   => 'el-icon-refresh',
                    'fields' => array(
                        array(
                            'id'         => 'opt-import-export',
                            'type'       => 'import_export',
                            'title'      => 'Import Export',
                            'subtitle'   => 'Save and restore your Redux options',
                            'full_width' => false,
                        ),
                    ),
                );

                $this->sections[] = array(
                    'type' => 'divide',
                );

                $this->sections[] = array(
                    'icon'   => 'el-icon-info-circle',
                    'title'  => esc_html__( 'Theme Information', 'voxco' ),
                    'fields' => array(
                        array(
                            'id'      => 'opt-raw-info',
                            'type'    => 'raw',
                            'content' => $item_info,
                        )
                    ),
                );


            }

            public function setHelpTabs() {

            // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
              /*  $this->args['help_tabs'][] = array(
                    'id'      => 'redux-help-tab-1',
                    'title'   => __( 'Theme Information 1', 'voxco' ),
                    'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'voxco' )
                );

                $this->args['help_tabs'][] = array(
                    'id'      => 'redux-help-tab-2',
                    'title'   => __( 'Theme Information 2', 'voxco' ),
                    'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'voxco' )
                );

                // Set the help sidebar
                $this->args['help_sidebar'] = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'voxco' );*/
            }

            /**
             * All the possible arguments for Redux.
             * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
             * */
            public function setArguments() {

                $theme = wp_get_theme(); // For use with some settings. Not necessary.

                $this->args = array(
                    // TYPICAL -> Change these values as you need/desire
                    'opt_name'             => 'VoxcoTheme_Options',
                    // This is where your data is stored in the database and also becomes your global variable name.
                    'display_name'         => $theme->get( 'Name' ),
                    // Name that appears at the top of your panel
                    'display_version'      => $theme->get( 'Version' ),
                    // Version that appears at the top of your panel
                    'menu_type'            => 'menu',
                    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                    'allow_sub_menu'       => true,
                    // Show the sections below the admin menu item or not
                    'menu_title'           => __( 'Theme Options', 'voxco' ),
                    'page_title'           => __( 'Theme Options', 'voxco' ),
                    // You will need to generate a Google API key to use this feature.
                    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                    'google_api_key'       => 'AIzaSyBC06MPjQ3ZfCuYAPEcW6y0XSWfEMK3wPs',
                    // Set it you want google fonts to update weekly. A google_api_key value is required.
                    'google_update_weekly' => false,
                    // Must be defined to add google fonts to the typography module
                    'async_typography'     => false,
                    // Use a asynchronous font on the front end or font string
                    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
                    'admin_bar'            => true,

                    'show_options_object' => false,

                    // Show the panel pages on the admin bar
                    'admin_bar_icon'     => 'dashicons-portfolio',
                    // Choose an icon for the admin bar menu
                    'admin_bar_priority' => 50,
                    // Choose an priority for the admin bar menu
                    'global_variable'      => '',
                    // Set a different name for your global variable other than the opt_name
                    'dev_mode'             => false,
                    // Show the time the page took to load, etc
                    'update_notice'        => false,
                    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
                    'customizer'           => true,
                    // Enable basic customizer support
                    'open_expanded'     => false,                    // Allow you to start the panel in an expanded way initially.
                    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

                    // OPTIONAL -> Give you extra features
                    'page_priority'        => null,
                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                    'page_parent'          => 'themes.php',
                    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                    'page_permissions'     => 'manage_options',
                    // Permissions needed to access the options panel.
                    'menu_icon'            => '',
                    // Specify a custom URL to an icon
                    'last_tab'             => '',
                    // Force your panel to always open to a specific tab (by id)
                    'page_icon'            => 'icon-themes',
                    // Icon displayed in the admin panel next to your menu_title
                    'page_slug'            => '_options',
                    // Page slug used to denote the panel
                    'save_defaults'        => true,
                    // On load save the defaults to DB before user clicks save or not
                    'default_show'         => false,
                    // If true, shows the default value next to each field that is not the default value.
                    'default_mark'         => '',
                    // What to print by the field's title if the value shown is default. Suggested: *
                    'show_import_export'   => true,
                    // Shows the Import/Export panel when not used as a field.

                    // CAREFUL -> These options are for advanced use only
                    'transient_time'       => 60 * MINUTE_IN_SECONDS,
                    'output'               => true,
                    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                    'output_tag'           => true,
                    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

                    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                    'database'             => '',
                    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                    'system_info'          => false,
                    // REMOVE

                    // HINTS
                    'hints'                => array(
                        'icon'          => 'icon-question-sign',
                        'icon_position' => 'right',
                        'icon_color'    => 'lightgray',
                        'icon_size'     => 'normal',
                        'tip_style'     => array(
                            'color'   => 'light',
                            'shadow'  => true,
                            'rounded' => false,
                            'style'   => '',
                        ),
                        'tip_position'  => array(
                            'my' => 'top left',
                            'at' => 'bottom right',
                        ),
                        'tip_effect'    => array(
                            'show' => array(
                                'effect'   => 'slide',
                                'duration' => '500',
                                'event'    => 'mouseover',
                            ),
                            'hide' => array(
                                'effect'   => 'slide',
                                'duration' => '500',
                                'event'    => 'click mouseleave',
                            ),
                        ),
                    )
                );

                
   

            }

            public function validate_callback_function( $field, $value, $existing_value ) {
                $error = true;
                $value = 'just testing';

                /*
              do your validation

              if(something) {
                $value = $value;
              } elseif(something else) {
                $error = true;
                $value = $existing_value;
                
              }
             */

                $return['value'] = $value;
                $field['msg']    = 'your custom error message';
                if ( $error == true ) {
                    $return['error'] = $field;
                }

                return $return;
            }

            public function class_field_callback( $field, $value ) {
                print_r( $field );
                echo '<br/>CLASS CALLBACK';
                print_r( $value );
            }

        }

        global $reduxConfig;
        $reduxConfig = new Redux_Framework_sample_config();
    } else {
        echo "The class named Redux_Framework_sample_config has already been called. <strong>Developers, you need to prefix this class with your company name or you'll run into problems!</strong>";
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ):
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    endif;

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ):
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error = true;
            $value = 'just testing';

            /*
          do your validation

          if(something) {
            $value = $value;
          } elseif(something else) {
            $error = true;
            $value = $existing_value;
            
          }
         */

            $return['value'] = $value;
            $field['msg']    = 'your custom error message';
            if ( $error == true ) {
                $return['error'] = $field;
            }

            return $return;
        }
    endif;
