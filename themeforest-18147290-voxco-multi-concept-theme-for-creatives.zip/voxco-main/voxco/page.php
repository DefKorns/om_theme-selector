<?php
/**
* The template for displaying all pages.
*/
get_header(); 

while ( have_posts() ) : the_post(); 
	the_content(); 
	wp_link_pages( array(
		'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'voxco' ),
		'after'  => '</div>',
	) );
	if ( comments_open() || '0' != get_comments_number() ){
		echo "<div class='row-default'>";
		comments_template( '', true );
		echo "</div>";
	}

endwhile; 

get_footer();