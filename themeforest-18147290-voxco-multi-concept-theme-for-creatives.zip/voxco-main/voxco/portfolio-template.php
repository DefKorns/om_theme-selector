<?php
/**
 * Template Name: Portfolio
 * Template to display portfolio posts
 */
?>


<?php get_header(); ?>


	
<?php 

	$voxco_site_layout = $VoxcoTheme_Options['voxco_options_site_layout'];
	$VoxcoTheme_portfolio_cats = get_post_meta( get_the_ID(), '_cmb_portfolio_categories',true );
	$VoxcoTheme_portfolio_filters = get_post_meta( get_the_ID(), '_cmb_portfolio_filter',true );
	$VoxcoTheme_caption_background = get_post_meta( get_the_ID(), '_cmb_caption_background',true );
	$VoxcoTheme_caption_heading = get_post_meta( get_the_ID(), '_cmb_caption_heading',true );
	$VoxcoTheme_caption_heading_font = get_post_meta( get_the_ID(), '_cmb_caption_heading_font',true );
	$VoxcoTheme_caption_categories_font = get_post_meta( get_the_ID(), '_cmb_caption_categories_font',true );
	$VoxcoTheme_caption_categories = get_post_meta( get_the_ID(), '_cmb_caption_categories',true );
	$VoxcoTheme_caption_v_align = get_post_meta( get_the_ID(), '_cmb_caption_v_align',true );
	$VoxcoTheme_caption_h_align = get_post_meta( get_the_ID(), '_cmb_caption_h_align',true );
	$VoxcoTheme_caption_ch_align = get_post_meta( get_the_ID(), '_cmb_caption_ch_align',true );
	$VoxcoTheme_caption_animation_style = get_post_meta( get_the_ID(), '_cmb_caption_animation_style',true );

	if(empty($VoxcoTheme_caption_animation_style)){
		$VoxcoTheme_caption_animation_style = 'hover-slide-up';
	}
	if(empty($VoxcoTheme_caption_ch_align)){
		$VoxcoTheme_caption_ch_align = 'caption-ch-top-right';
	}


	$VoxcoTheme_cat_slugs_list = '';
	$VoxcoTheme_cat_slugs= array();
	if($VoxcoTheme_portfolio_cats){
		foreach ($VoxcoTheme_portfolio_cats as $cat) {
			$cat_object = get_term_by( 'id', absint( $cat ), 'portfolio_item_category' );
			$cat_name = $cat_object->name;
			$cat_slug = $cat_object->slug;
			$VoxcoTheme_cat_slugs[] = $cat_slug;
		}
		$VoxcoTheme_cat_slugs_list = join( " ,", $VoxcoTheme_cat_slugs );
	}

	?>
	


				

			<?php while ( have_posts() ) : the_post(); ?>
				<?php the_content(); ?>
			<?php endwhile; // end of the loop. ?>
		
			<?php 
			if ($VoxcoTheme_portfolio_filters == 'filter-above'){ ?>
				<div class="filter-above">
					<?php voxco_filters(); ?>
				</div>
			<?php } ?>		

			<ul class="portfolioinner <?php echo esc_attr($VoxcoTheme_caption_animation_style) .' '. esc_attr($VoxcoTheme_caption_v_align) .' '. esc_attr($VoxcoTheme_caption_h_align) .' '. esc_attr($VoxcoTheme_caption_ch_align);?>">	

			<?php

			if ( get_query_var('paged') ) {
			    $paged = get_query_var('paged');
			} else if ( get_query_var('page') ) {
			    $paged = get_query_var('page');
			} else {
			    $paged = 1;
			}

		    $voxco_custom_post = array( 
		    	'post_type' => 'portfolios',
		    	'portfolio_item_category' => $VoxcoTheme_cat_slugs_list,
		    	'numberposts' => '-1',
		    	'suppress_filters' => false,
		    	'orderby' => 'date',
	    		'order' => 'DESC',
		    	'paged' => $paged, 
		    );
		    $voxco_loop = new WP_Query( $voxco_custom_post );
		    ?>
		    <?php while ( $voxco_loop->have_posts() ) : $voxco_loop->the_post();

		    	$terms = get_the_terms( $post->ID, 'portfolio_item_category' );
		    	$portfolio_links = array();
				$portfolio_links_class = array();
				if ( $terms && ! is_wp_error( $terms ) ){ 
					foreach ( $terms as $term ) {
						$portfolio_links_class[] = preg_replace('/\s+/', '', $term->slug);
						$portfolio_links[] = trim($term->name);
					}
				}	
				$portfolio_item_category = join( " ", $portfolio_links_class );
				$portfolio_category_list = join( " / ", $portfolio_links );

		    	$large_image_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
		 		$thumbnail_width = get_post_meta( $post->ID, '_cmb_thumbnail_width', true ); 
		 		$thumbnal_style = get_post_meta( $post->ID, '_cmb_thumb_style', true );
		 		$thumbnal_content = get_post_meta( $post->ID, '_cmb_thumbnail_content', true );
		 		$thumbnal_link = get_post_meta( $post->ID, '_cmb_thumb_link', true ); 

		 		$VoxcoTheme_caption_background_single = get_post_meta( $post->ID, '_cmb_caption_background_single',true );
				if($VoxcoTheme_caption_background_single){
					$VoxcoTheme_caption_background_color = $VoxcoTheme_caption_background_single;
				}
				else{
					$VoxcoTheme_caption_background_color = $VoxcoTheme_caption_background;
				}
				$VoxcoTheme_caption_heading_single = get_post_meta( $post->ID, '_cmb_caption_heading_single',true );
				if($VoxcoTheme_caption_heading_single){
					$VoxcoTheme_caption_heading_color = $VoxcoTheme_caption_heading_single;
				}
				else{
					$VoxcoTheme_caption_heading_color = $VoxcoTheme_caption_heading; 
				}
				$VoxcoTheme_caption_categories_single = get_post_meta( $post->ID, '_cmb_caption_categories_single',true );
				if($VoxcoTheme_caption_categories_single){
					$VoxcoTheme_caption_categories_color = $VoxcoTheme_caption_categories_single;
				}
				else{
					$VoxcoTheme_caption_categories_color = $VoxcoTheme_caption_categories;
				}


				$VoxcoTheme_caption_single_v_align = get_post_meta( $post->ID, '_cmb_caption_single_v_align',true );
				$VoxcoTheme_caption_single_h_align = get_post_meta( $post->ID, '_cmb_caption_single_h_align',true );
				$VoxcoTheme_caption_single_ch_align = get_post_meta( $post->ID, '_cmb_caption_single_ch_align',true );


				if ( has_post_thumbnail() ) { 
					echo '<li class="item all ' . esc_attr($portfolio_item_category) . ' ' .  esc_attr($thumbnail_width) . ' ' . esc_attr($thumbnal_style) . ' ' . esc_attr($VoxcoTheme_caption_single_v_align) . ' ' .  esc_attr($VoxcoTheme_caption_single_h_align) . ' ' . esc_attr($VoxcoTheme_caption_single_ch_align) . '">';
					echo '<figure>' . get_the_post_thumbnail($post->ID) ;
				} 
				else{
					echo '<li class="item all no-thumbnail ' . esc_attr($portfolio_item_category) .' '.  esc_attr($thumbnail_width) . ' ' . esc_attr($thumbnal_style) . ' ' . esc_attr($VoxcoTheme_caption_single_v_align) . ' ' .  esc_attr($VoxcoTheme_caption_single_h_align) . ' ' . esc_attr($VoxcoTheme_caption_single_ch_align) . '">';
				}
				?>
			 	<figcaption style="background:<?php echo esc_attr($VoxcoTheme_caption_background_color); ?>;">
			 		<?php $voxco_link = get_post_meta( get_the_ID(), '_cmb_custom_url',true );
			 			if(!$voxco_link){
			 				$voxco_link = get_permalink(get_the_ID());
			 			}
			 			if($thumbnal_link != 'no'){
			 				echo '<a class="plink" target="'. get_post_meta( get_the_ID(), '_cmb_custom_url_target',true ) .'" href="' . esc_url($voxco_link) .'" ></a>';
			 			} 		 			
			 		?>
			 		
			 		<div class="caption-inner">
			 		<?php if($thumbnal_style == 'text-on'){

			 			$allowed_html_array = array(
						    'a' => array(
							    'href' => array(),
							    'title' => array()
							),
							'em' => array(),
							'strong' => array(),
							'span' => array(
								'style' => array()
							),
						);

			 			echo '<div style="color:'. esc_attr($VoxcoTheme_caption_heading_color) .';"><h2 class="'. esc_attr(get_post_meta( $post->ID, '_cmb_text_on_image_font',true )) .'">'. wp_kses($thumbnal_content, $allowed_html_array) . '</h2></div>';
			 		} else{ ?>
			 			<span class="crossH" style="background:<?php echo esc_attr($VoxcoTheme_caption_categories_color); ?>;"></span>
			 			<span class="crossV" style="background:<?php echo esc_attr($VoxcoTheme_caption_categories_color); ?>;"></span>
			 			<div>
			 				<span class="<?php echo esc_attr($VoxcoTheme_caption_categories_font); ?>" style="color:<?php echo esc_attr($VoxcoTheme_caption_categories_color); ?>;"><?php echo esc_html($portfolio_category_list); ?></span>
			 				<h2 class="<?php echo esc_attr($VoxcoTheme_caption_heading_font); ?>" style="color:<?php echo esc_attr($VoxcoTheme_caption_heading_color); ?>;"><?php echo get_the_title();?></h2>
			 			</div>
			 		<?php } ?>	

			 		</div>	
			 	</figcaption>	
			 	<?php if ( has_post_thumbnail() ) { 	
			 		echo '</figure>';	
			 	}?>
		 		</li>	
		    

		    <?php endwhile; ?>
			</ul>
		
	<div class="load-more">
		<span class="spinner"></span>
		<?php next_posts_link( esc_html__( 'Older Posts', 'voxco' ), $voxco_loop->max_num_pages ); ?>
		
	</div>	
		

	




<?php get_footer(); ?>