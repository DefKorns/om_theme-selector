<?php get_header(); ?>


		<?php $VoxcoTheme_sidebar_archive = $VoxcoTheme_Options['voxco_options_sidebar_arch']; 
		if ($VoxcoTheme_sidebar_archive == 'aside-standard'){
			$VoxcoTheme_content = 'c9';
		}
		else{
			$VoxcoTheme_content = '';
		}
		
		if($VoxcoTheme_sidebar_archive == 'aside-offcanvas'){
			echo '<span class="aside-trigger '.$VoxcoTheme_Options['voxco_options_menu_button_style'].'"><span></span></span>';	
		} ?>
		
		
			
		<?php  if ( have_posts() ) { ?> 
				
			<div class="row">

				<div id="masonry-container" class="<?php echo esc_attr($VoxcoTheme_content); ?>">
					<?php 
						while ( have_posts() ) : the_post();
							get_template_part( 'content');
						endwhile;
						?>
				</div>
				
				<?php 
				if ($VoxcoTheme_sidebar_archive == 'aside-standard'){ ?>
						<div class="c3"> <?php get_sidebar(); ?> </div>
				<?php } 
				else if($VoxcoTheme_sidebar_archive == 'aside-offcanvas'){ ?>
					<div class="aside-offcanvas">
						<span class="aside-close"></span>
						<?php get_sidebar(); ?>
					</div>
					<div class="aside-overlay"></div>
				<?php } ?>
				<div class="load-more">
					<span class="spinner"></span>
					<?php next_posts_link( esc_html__( 'Older Posts', 'voxco' ) ); ?>
				</div>	
				
			</div>	




			<?php } 
			else { 
			 ?>
				<?php get_template_part( 'no-results', 'search' ); ?>
					
			<?php } ?>
			
		
		
		
		


<?php

get_footer();
