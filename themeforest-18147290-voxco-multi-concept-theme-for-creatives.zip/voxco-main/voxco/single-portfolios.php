<?php get_header(); ?>
	
	<?php while ( have_posts() ) : the_post(); 
			
		$VoxcoTheme_portfolio_header_style = get_post_meta( $post->ID, '_cmb_header_slider_style', true );
		$VoxcoTheme_portfolio_title = get_post_meta( get_the_ID(), '_cmb_portfolio_post_title', 1 ); 
		$VoxcoTheme_share_background = get_post_meta( get_the_ID(), '_cmb_share_background', 1 ); 
		$VoxcoTheme_share_icon = get_post_meta( get_the_ID(), '_cmb_share_icon', 1 ); 
		$VoxcoTheme_prevnext_background = get_post_meta( get_the_ID(), '_cmb_prev_next_background', 1 ); 
		$voxco_menu_layout = $VoxcoTheme_Options['voxco_options_menu_style'];
		$voxco_site_layout = $VoxcoTheme_Options['voxco_options_site_layout'];
		$voxco_excluded_cats = $VoxcoTheme_Options['excluded_cats']; ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >

			<?php the_content(); ?>
			<?php if($voxco_menu_layout != 'l3' || $voxco_site_layout == 'layout-standard-header'){ ?>
				<div class="row portfolio-single-nav">
						
					<?php
					if(! empty($voxco_excluded_cats)){
						$next_post = get_adjacent_post(false,array_keys($voxco_excluded_cats, 1),true, 'portfolio_item_category');
						$prev_post = get_adjacent_post(false, array_keys($voxco_excluded_cats, 1) ,false, 'portfolio_item_category');
					} 
					else{
						$next_post = get_adjacent_post(false,'',true);
						$prev_post = get_adjacent_post(false,'',false);
					}

					
					if($prev_post){
						$prev_image = '';
						
						$prev_image_id = get_post_thumbnail_id($prev_post->ID);
						$prev_image_url = wp_get_attachment_image_src($prev_image_id , 'full');
						$VoxcoTheme_prev_nav_background = get_post_meta( $prev_post->ID, '_cmb_portfolio_nav_background', 1 ); 
								
						if($VoxcoTheme_prev_nav_background){
							$prev_image = $VoxcoTheme_prev_nav_background;
						}
						else{
							$prev_image = $prev_image_url[0];
						}
						if($prev_post && $next_post ){ 
							echo '<div class="c4" style="background-image:url('. esc_url($prev_image) .');">';
						}
						else if ($prev_post && !$next_post) {
							echo '<div class="c8" style="background-image:url('. esc_url($prev_image) .');">';
						}
						echo '<div class="prev-next-wrap" style="background:' . esc_attr($VoxcoTheme_prevnext_background) .'">';
						echo '<a href="'.esc_url(get_the_permalink($prev_post)).'">';
						echo '<div class="prev-next-project">';
							
						echo '<span class="accent">'. esc_html__('Previous Project', 'voxco') .'</span>';
						echo '<h3>'. get_the_title($prev_post) .'</h3>';
						echo '</div>';
						echo '<span class="prev-next-icon right"></span>';
						echo '</a></div></div>';

					} 
					
					if($next_post){
						$next_img = '';
						$next_image_id = get_post_thumbnail_id($next_post->ID);
						$next_image_url = wp_get_attachment_image_src($next_image_id, 'full');
						$VoxcoTheme_next_nav_background = get_post_meta( $next_post->ID, '_cmb_portfolio_nav_background', 1 ); 


						if($VoxcoTheme_next_nav_background){
							$next_image = $VoxcoTheme_next_nav_background;
						}
						else{
							$next_image = $next_image_url[0];
						}
									
						if($next_post && $prev_post){ 
							echo '<div class="c4 end" style="background-image:url('. esc_url($next_image) .');">';
						}
						else if($next_post && !$prev_post){
							echo '<div class="c8 end" style="background-image:url('. esc_url($next_image) .');">';
						}
						echo '<div class="prev-next-wrap" style="background:' . esc_attr($VoxcoTheme_prevnext_background) .'">';
						echo '<a href="'.esc_url(get_the_permalink($next_post)).'">';
						echo '<div class="prev-next-project">';
						echo '<span class="accent">'. esc_html__('Next Project', 'voxco') .'</span>';
						echo '<h3>'. get_the_title($next_post).'</h3>';
						echo '</div>';
						echo '<span class="prev-next-icon"></span>';
						echo '</a></div></div>';
									
					} ?> 

					<div class="c4 portfolio-share" style="background-color:<?php echo esc_attr($VoxcoTheme_share_background); ?>;">
						<div class="portfolio-meta"> 
						    <div class="share" style="color:<?php echo esc_attr($VoxcoTheme_share_icon); ?>;">
						        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink($post->ID); ?>"  target="_blank"><i class="fa fa-facebook"></i></a>
						        <a href="https://plus.google.com/share?url=<?php echo get_permalink($post->ID); ?>" target="_blank"><i class="fa fa-google-plus"></i></a>
						        <a href="https://twitter.com/home?status=<?php echo get_permalink($post->ID); ?>" target="_blank"><i class="fa fa-twitter"></i></a>
						        <?php 
						        $image_id = get_post_thumbnail_id($post->ID);
						        $image_url = wp_get_attachment_image_src($image_id);
						        ?>
						        <a href="https://pinterest.com/pin/create/button/?url=<?php echo get_permalink($post->ID); ?>&media=<?php echo esc_url($image_url[0]); ?>&description=" target="_blank"><i class="fa fa-pinterest"></i></a>
					        </div>
						</div>
					</div>
		
							
				</div>
	<?php  } ?>
	</article>

	<?php endwhile; ?>

<?php get_footer(); ?>

