<?php get_header(); ?>

	<?php while ( have_posts() ) : the_post();
	
		$VoxcoTheme_sidebar = $VoxcoTheme_Options['voxco_options_sidebar'];
		if($VoxcoTheme_sidebar == 'aside-offcanvas'){
			echo '<span class="aside-trigger '.$VoxcoTheme_Options['voxco_options_menu_button_style'].'"><span></span></span>';	
		} ?>

		<article class="row">
			<?php get_template_part('content'); ?>
		</article>

	<?php endwhile; ?>

<?php get_footer(); ?>



